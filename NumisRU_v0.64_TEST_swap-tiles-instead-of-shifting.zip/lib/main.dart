import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:country_flags/country_flags.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const AmikScOfflineApp());
    return;
  }
  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      if (Supabase.instance.client.auth.currentSession == null) {
        await Supabase.instance.client.auth.signInAnonymously();
      }
    } catch (_) {}
    runApp(const NumisRuApp());
  } catch (_) {
    runApp(const AmikScOfflineApp());
  }
}

ThemeData _appTheme() => ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174B63)),
  useMaterial3: true,
  cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6)),
);

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const HomeShell());
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [CatalogPage(), CollectionPage(), WishlistPage(), PortfolioPage(), ProfilePage()];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i) => setState(() => _index = i), destinations: _destinations));
}

class AmikScOfflineApp extends StatelessWidget {
  const AmikScOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const OfflineHomeShell());
}

class OfflineHomeShell extends StatefulWidget {
  const OfflineHomeShell({super.key});
  @override
  State<OfflineHomeShell> createState() => _OfflineHomeShellState();
}

class _OfflineHomeShellState extends State<OfflineHomeShell> {
  int _index = 0;

  static const _destinations = <NavigationDestination>[
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const ContinentHomePage(),
      const _OfflinePlaceholderPage(title: 'Коллекция', icon: Icons.collections_bookmark_outlined,
          message: 'Раздел коллекции будет подключён на следующем этапе.'),
      const _OfflinePlaceholderPage(title: 'Избранное', icon: Icons.bookmark_border,
          message: 'Избранное будет доступно после подключения сохранения монет.'),
      const _OfflinePlaceholderPage(title: 'Статистика', icon: Icons.insights_outlined,
          message: 'Статистика коллекции появится, когда будет доступен учёт собранных монет.'),
      const _OfflinePlaceholderPage(title: 'Профиль', icon: Icons.person_outline,
          message: 'Профиль будет подключён на следующем этапе.'),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: _destinations,
      ),
    );
  }
}

class _OfflinePlaceholderPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String message;
  const _OfflinePlaceholderPage({required this.title, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 52, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(message, textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}

class _Region {
  final String name;
  final IconData icon;
  final List<String> countries;
  const _Region(this.name, this.icon, this.countries);
}

// Country/territory names are a first-pass grouping for navigation. The uCoin catalog
// includes current countries as well as historical issuers and territories; this list
// will be refined step-by-step in later versions.
const List<_Region> _regions = [
  _Region('Европа', Icons.account_balance, [
    'Австрия','Албания','Андорра','Беларусь','Бельгия','Болгария','Босния и Герцеговина','Ватикан','Великобритания','Венгрия','Германия','Греция','Дания','Ирландия','Исландия','Испания','Италия','Кипр','Косово','Латвия','Литва','Лихтенштейн','Люксембург','Мальта','Молдова','Монако','Нидерланды','Норвегия','Польша','Португалия','Россия','Румыния','Сан-Марино','Северная Македония','Сербия','Словакия','Словения','Турция','Украина','Финляндия','Франция','Хорватия','Черногория','Чехия','Швейцария','Швеция','Эстония'
  ]),
  _Region('Азия', Icons.temple_buddhist, [
    'Азербайджан','Армения','Афганистан','Бангладеш','Бахрейн','Бруней','Бутан','Вьетнам','Грузия','Израиль','Индия','Индонезия','Иордания','Ирак','Иран','Йемен','Казахстан','Камбоджа','Катар','Кипр','Китай','КНДР','Кувейт','Кыргызстан','Лаос','Ливан','Малайзия','Мальдивы','Монголия','Мьянма','Непал','ОАЭ','Оман','Пакистан','Палестина','Саудовская Аравия','Сингапур','Сирия','Таджикистан','Таиланд','Тайвань','Тимор-Лесте','Туркменистан','Турция','Узбекистан','Филиппины','Шри-Ланка','Южная Корея','Япония'
  ]),
  _Region('Африка', Icons.wb_sunny_outlined, [
    'Алжир','Ангола','Бенин','Ботсвана','Буркина-Фасо','Бурунди','Габон','Гамбия','Гана','Гвинея','Гвинея-Бисау','Демократическая Республика Конго','Джибути','Египет','Замбия','Западная Сахара','Зимбабве','Кабо-Верде','Камерун','Кения','Коморы','Кот-д’Ивуар','Лесото','Либерия','Ливия','Маврикий','Мавритания','Мадагаскар','Малави','Мали','Марокко','Мозамбик','Намибия','Нигер','Нигерия','Республика Конго','Руанда','Сан-Томе и Принсипи','Сейшелы','Сенегал','Сомали','Судан','Сьерра-Леоне','Танзания','Того','Тунис','Уганда','Центральноафриканская Республика','Чад','Экваториальная Гвинея','Эритрея','Эсватини','Эфиопия','ЮАР','Южный Судан'
  ]),
  _Region('Северная Америка', Icons.landscape_outlined, [
    'Антигуа и Барбуда','Багамы','Барбадос','Белиз','Гаити','Гватемала','Гондурас','Гренада','Доминика','Доминиканская Республика','Канада','Коста-Рика','Куба','Мексика','Никарагуа','Панама','Сальвадор','Сент-Винсент и Гренадины','Сент-Китс и Невис','Сент-Люсия','США','Тринидад и Тобаго','Ямайка'
  ]),
  _Region('Южная Америка', Icons.public, [
    'Аргентина','Боливия','Бразилия','Венесуэла','Гайана','Колумбия','Парагвай','Перу','Суринам','Уругвай','Чили','Эквадор','Французская Гвиана'
  ]),
  _Region('Австралия и Океания', Icons.sailing, [
    'Австралия','Вануату','Кирибати','Маршалловы Острова','Микронезия','Науру','Новая Зеландия','Палау','Папуа — Новая Гвинея','Самоа','Соломоновы Острова','Тонга','Тувалу','Фиджи','Французская Полинезия','Американское Самоа','Гуам','Новая Каледония','Острова Кука'
  ]),
  _Region('Исчезнувшие страны', Icons.history_edu, [
    'Австро-Венгрия','Византийская империя','ГДР','Западная Германия','Османская империя','Пруссия','Римская империя','Российская империя','РСФСР','Советский Союз','Югославия','Чехословакия','Королевство Италия','Королевство Пруссия','Веймарская республика'
  ]),
  _Region('Непризнанные территории', Icons.public_off, [
    'Абхазия','Арцах / Нагорный Карабах','Косово','Приднестровье','Северный Кипр','Сомалиленд','Тайвань','Южная Осетия','Западная Сахара','Себорга'
  ]),
  _Region('Мой каталог', Icons.star_border, []),
];

const String _myCatalogCountriesKey = 'my_catalog_countries_v1';
String _catalogCountriesKey(String name) => 'my_catalog_countries_v2_${Uri.encodeComponent(name)}';
const String _myCatalogNameKey = 'my_catalog_name_v1';
const String _defaultMyCatalogName = 'Мой каталог';
const String _myCatalogNamesKey = 'my_catalog_names_v2';
const String _tileOrderKey = 'home_tile_order_v1';
const String _standardTileColorKey = 'home_standard_tile_color_v1';
const String _customTileColorKey = 'home_custom_tile_color_v1';
const String _addCatalogTileColorKey = 'home_add_catalog_tile_color_v1';
const String _legacyHomeTileColorKey = 'home_tile_color_v1';
const List<int> _homeTileColorOptions = [0xFFF5F5F5, 0xFFE8F1F5, 0xFFF1EBDD, 0xFFE8F0E6, 0xFFF2E8EF, 0xFFECE9F7, 0xFFFFF3D9];

class ContinentHomePage extends StatefulWidget {
  const ContinentHomePage({super.key});
  @override
  State<ContinentHomePage> createState() => _ContinentHomePageState();
}

class _ContinentHomePageState extends State<ContinentHomePage> {
  String _myCatalogName = _defaultMyCatalogName;
  List<String> _myCountries = [];
  List<String> _catalogNames = [_defaultMyCatalogName];
  Map<String, List<String>> _catalogCountries = {}; 
  Timer? _holdTimer;
  bool _renameDialogOpened = false;
  bool _catalogSelectionMode = false;
  bool _holdActivated = false;
  final Set<String> _selectedCatalogs = <String>{};
  List<String> _tileOrder = <String>[];
  bool _currentDragMoved = false;
  final ScrollController _homeScrollController = ScrollController();
  int? _standardTileColorValue;
  int? _customTileColorValue;
  int? _addCatalogTileColorValue;

  @override
  void initState() {
    super.initState();
    _loadCustomData();
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _homeScrollController.dispose();
    super.dispose();
  }

  Future<void> _loadCustomData() async {
    final prefs = await SharedPreferences.getInstance();
    final myCatalogName = prefs.getString(_myCatalogNameKey) ?? _defaultMyCatalogName;
    final catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? [myCatalogName];
    final savedTileOrder = prefs.getStringList(_tileOrderKey) ?? <String>[];
    final savedStandardTileColor = prefs.getInt(_standardTileColorKey) ?? prefs.getInt(_legacyHomeTileColorKey);
    final savedCustomTileColor = prefs.getInt(_customTileColorKey);
    final savedAddCatalogTileColor = prefs.getInt(_addCatalogTileColorKey);
    if (prefs.containsKey(_legacyHomeTileColorKey) && !prefs.containsKey(_standardTileColorKey)) {
      await prefs.setInt(_standardTileColorKey, savedStandardTileColor ?? _homeTileColorOptions.first);
      await prefs.remove(_legacyHomeTileColorKey);
    }
    // Migrate the old shared list into the original catalog only once.
    final legacy = prefs.getStringList(_myCatalogCountriesKey);
    if (legacy != null && prefs.getStringList(_catalogCountriesKey(_defaultMyCatalogName)) == null) {
      await prefs.setStringList(_catalogCountriesKey(_defaultMyCatalogName), legacy);
      await prefs.remove(_myCatalogCountriesKey);
    }
    final catalogCountries = <String, List<String>>{
      for (final name in catalogNames)
        name: prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[],
    };
    if (!mounted) return;
    setState(() {
      _myCatalogName = myCatalogName;
      _catalogNames = catalogNames;
      _tileOrder = savedTileOrder;
      _standardTileColorValue = savedStandardTileColor;
      _customTileColorValue = savedCustomTileColor;
      _addCatalogTileColorValue = savedAddCatalogTileColor;
      _catalogCountries = catalogCountries;
      _myCountries = _catalogCountries[_myCatalogName] ?? <String>[];
    });
  }

  Future<void> _moveTile(String draggedName, String targetName) async {
    if (draggedName == targetName || draggedName == '__add_catalog__') return;
    final tiles = [..._regions.where((r) => r.name != 'Мой каталог'), ..._catalogNames.map((name) => _Region(name, Icons.star_border, [])), _Region('__add_catalog__', Icons.add, [])];
    final names = tiles.map((r) => r.name).toList();
    final order = <String>[];
    for (final name in _tileOrder) { if (names.contains(name) && !order.contains(name)) order.add(name); }
    for (final name in names) { if (!order.contains(name)) order.add(name); }
    final from = order.indexOf(draggedName);
    if (from < 0 || !order.contains(targetName)) return;
    // Swap the dragged tile with the target tile instead of shifting the tiles
    // between their old and new positions. The add-catalog tile stays pinned
    // to the bottom, so dropping onto it swaps with the last movable tile.
    var to = order.indexOf(targetName);
    if (to < 0) return;
    if (targetName == '__add_catalog__') {
      to = order.length - 2;
      if (to < 0 || from == to) return;
    }
    final displacedName = order[to];
    order[to] = draggedName;
    order[from] = displacedName;
    order.remove('__add_catalog__');
    order.add('__add_catalog__');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_tileOrderKey, order);
    if (mounted) setState(() => _tileOrder = order);
  }

  Future<void> _renameCatalog(String oldName) async {
    final controller = TextEditingController(text: oldName);
    final newName = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Переименовать плитку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Название плитки'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    controller.dispose();
    if (newName == null || newName.trim().isEmpty || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    final renamed = newName.trim();
    if (renamed != oldName && _catalogNames.contains(renamed)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Каталог с таким названием уже существует')));
      return;
    }
    final names = List<String>.from(_catalogNames);
    final index = names.indexOf(oldName);
    if (index >= 0) names[index] = renamed;
    if (index < 0) return;
    final countries = prefs.getStringList(_catalogCountriesKey(oldName)) ?? <String>[];
    await prefs.setStringList(_catalogCountriesKey(renamed), countries);
    await prefs.remove(_catalogCountriesKey(oldName));
    await prefs.setString(_myCatalogNameKey, renamed);
    await prefs.setStringList(_myCatalogNamesKey, names);
    if (mounted) setState(() { if (_myCatalogName == oldName) _myCatalogName = renamed; _catalogNames = names; _catalogCountries.remove(oldName); _catalogCountries[renamed] = countries; _myCountries = _catalogCountries[_myCatalogName] ?? <String>[]; });
  }

  void _startHoldSelection(String catalogName) {
    _holdTimer?.cancel();
    _renameDialogOpened = false;
    _holdActivated = false;
    _holdTimer = Timer(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      _holdActivated = true;
      setState(() {
        _catalogSelectionMode = true;
        _selectedCatalogs.add(catalogName);
      });
    });
  }

  void _cancelHold() => _holdTimer?.cancel();

  void _toggleCatalogSelection(String name) {
    setState(() {
      if (_selectedCatalogs.contains(name)) {
        _selectedCatalogs.remove(name);
      } else {
        _selectedCatalogs.add(name);
      }
      if (_selectedCatalogs.isEmpty) _catalogSelectionMode = false;
    });
  }

  Future<void> _deleteSelectedCatalogs() async {
    final selected = _catalogNames.where(_selectedCatalogs.contains).toList();
    if (selected.isEmpty) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Удалить выбранные каталоги?'),
      content: Text('Будут удалены ${selected.length} плиток и списки стран внутри них. Это действие нельзя отменить.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить'))],
    ));
    if (ok != true) return;
    final prefs = await SharedPreferences.getInstance();
    final names = List<String>.from(_catalogNames)..removeWhere(_selectedCatalogs.contains);
    for (final name in selected) { await prefs.remove(_catalogCountriesKey(name)); }
    await prefs.setStringList(_myCatalogNamesKey, names);
    if (_selectedCatalogs.contains(_myCatalogName)) {
      _myCatalogName = names.isNotEmpty ? names.first : _defaultMyCatalogName;
      await prefs.setString(_myCatalogNameKey, _myCatalogName);
    }
    if (mounted) setState(() {
      for (final name in selected) _catalogCountries.remove(name);
      _catalogNames = names;
      _myCountries = _catalogCountries[_myCatalogName] ?? <String>[];
      _selectedCatalogs.clear();
      _catalogSelectionMode = false;
    });
  }

  Future<void> _addCatalog() async {
    final controller = TextEditingController(text: 'Мой каталог ${_catalogNames.length + 1}');
    final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(title: const Text('Новый каталог'), content: TextField(controller: controller, autofocus: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Название плитки')), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Добавить'))]));
    controller.dispose();
    if (name == null || name.trim().isEmpty) return;
    var uniqueName = name.trim();
    if (_catalogNames.contains(uniqueName)) {
      var suffix = 2;
      while (_catalogNames.contains('$uniqueName ($suffix)')) { suffix++; }
      uniqueName = '$uniqueName ($suffix)';
    }
    final names = [..._catalogNames, uniqueName];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_myCatalogNamesKey, names);
    await prefs.setStringList(_catalogCountriesKey(uniqueName), <String>[]);
    if (mounted) {
      setState(() { _catalogNames = names; _catalogCountries[uniqueName] = <String>[]; });
      // Keep the newly-created tile in view instead of rebuilding the grid at the top.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _homeScrollController.hasClients) {
          _homeScrollController.animateTo(
            _homeScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
          );
        }
      });
    }
  }

  Future<void> _deleteCatalog(String name) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Удалить каталог?'),
      content: Text('Плитка «$name» и список стран внутри неё будут удалены. Это действие нельзя отменить.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить'))],
    ));
    if (ok != true) return;
    final names = List<String>.from(_catalogNames)..remove(name);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_myCatalogNamesKey, names);
    await prefs.remove(_catalogCountriesKey(name));
    if (_myCatalogName == name) {
      _myCatalogName = names.isNotEmpty ? names.first : _defaultMyCatalogName;
      await prefs.setString(_myCatalogNameKey, _myCatalogName);
    }
    if (mounted) setState(() { _catalogNames = names; _catalogCountries.remove(name); _myCountries = _catalogCountries[_myCatalogName] ?? <String>[]; });
  }

  Future<void> _openRegion(_Region region) async {
    final isCatalog = _catalogNames.contains(region.name) || region.name == 'Мой каталог';
    final catalogName = isCatalog ? region.name : null;
    final customRegion = isCatalog
        ? _Region(region.name, region.icon, List<String>.from(_catalogCountries[region.name] ?? <String>[]))
        : region;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => CountryListPage(
        region: customRegion,
        isMyCatalog: isCatalog,
        catalogName: catalogName,
      ),
    ));
    await _loadCustomData();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Row(mainAxisSize: MainAxisSize.min, children: [Text('АМиК SC'), SizedBox(width: 8), Text('v0.64 TEST', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500))]), centerTitle: false, actions: [IconButton(tooltip: 'Настройки', icon: const Icon(Icons.settings), onPressed: () async { await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AppSettingsPage())); await _loadCustomData(); })]),
    body: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (_catalogSelectionMode) {
          setState(() {
            _selectedCatalogs.clear();
            _catalogSelectionMode = false;
          });
        }
      },
      child: Column(children: [
      Expanded(child: GridView.builder(
        controller: _homeScrollController,
        key: const ValueKey<String>('home-catalog-grid'),
        padding: const EdgeInsets.all(8), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemCount: _regions.length - 1 + _catalogNames.length + 1,
        itemBuilder: (context, index) {
          final regionsWithCatalogs = [..._regions.where((r) => r.name != 'Мой каталог'), ..._catalogNames.map((name) => _Region(name, Icons.star_border, [])), _Region('__add_catalog__', Icons.add, [])];
          if (_tileOrder.isNotEmpty) {
            regionsWithCatalogs.sort((a, b) {
              final ai = _tileOrder.indexOf(a.name); final bi = _tileOrder.indexOf(b.name);
              if (ai < 0 && bi < 0) return 0; if (ai < 0) return 1; if (bi < 0) return -1; return ai.compareTo(bi);
            });
          }
          // The add-catalog tile must always be last, regardless of saved drag order.
          final addTile = regionsWithCatalogs.firstWhere((r) => r.name == '__add_catalog__');
          regionsWithCatalogs.removeWhere((r) => r.name == '__add_catalog__');
          regionsWithCatalogs.add(addTile);
          final region = regionsWithCatalogs[index];
          final isAddCatalog = region.name == '__add_catalog__';
          final isMyCatalog = _catalogNames.contains(region.name);
          final title = isMyCatalog ? region.name : isAddCatalog ? 'Добавить каталог' : region.name;
          final count = isMyCatalog ? (_catalogCountries[region.name]?.length ?? 0) : region.countries.length;
          final isSelected = _selectedCatalogs.contains(region.name);
          final tileBaseColorValue = isAddCatalog ? _addCatalogTileColorValue : isMyCatalog ? _customTileColorValue : _standardTileColorValue;
          final tileBaseColor = tileBaseColorValue == null ? null : Color(tileBaseColorValue);
          return KeyedSubtree(key: ValueKey<String>(region.name), child: DragTarget<String>(
            onWillAcceptWithDetails: (details) {
              if (details.data == region.name) return false;
              return true;
            },
            onAcceptWithDetails: (details) => _moveTile(details.data, region.name),
            builder: (context, candidates, rejected) => LongPressDraggable<String>(
              data: region.name,
              delay: const Duration(milliseconds: 500),
              maxSimultaneousDrags: 1,
              onDragStarted: () { _currentDragMoved = false; _holdTimer?.cancel(); },
              onDragUpdate: (details) {
                if (details.delta.distance > 2) _currentDragMoved = true;
              },
              onDragEnd: (details) {
                if (isMyCatalog && !_currentDragMoved && mounted) {
                  _holdActivated = false;
                  setState(() { _catalogSelectionMode = true; _selectedCatalogs.add(region.name); });
                }
              },
              feedback: Material(color: Colors.transparent, child: SizedBox(width: (MediaQuery.of(context).size.width - 20) / 2, height: ((MediaQuery.of(context).size.width - 20) / 2) / 1.55, child: Card(elevation: 8, color: tileBaseColor, child: Padding(padding: const EdgeInsets.fromLTRB(28, 10, 10, 10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(region.icon, size: 30), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), if (!isAddCatalog) Text('$count стран')]))))),
              childWhenDragging: Opacity(opacity: 0.25, child: Card(child: const SizedBox.expand())),
              child: Card(clipBehavior: Clip.antiAlias, color: candidates.isNotEmpty ? Theme.of(context).colorScheme.primaryContainer : isSelected ? Theme.of(context).colorScheme.secondaryContainer : tileBaseColor, child: Stack(children: [
            Positioned.fill(child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onDoubleTap: isMyCatalog && !_catalogSelectionMode ? () => _renameCatalog(region.name) : null,
              onTap: () {
                _cancelHold();
                if (isMyCatalog && _holdActivated) { _holdActivated = false; return; }
                if (_catalogSelectionMode) {
                  if (isMyCatalog) {
                    // In selection mode, taps on custom catalog tiles toggle only that tile.
                    // Keep selection mode active even when the last selected tile is unchecked.
                    _toggleCatalogSelection(region.name);
                  } else {
                    // Tapping anywhere outside custom catalog tiles clears all selections
                    // and exits selection mode.
                    setState(() {
                      _selectedCatalogs.clear();
                      _catalogSelectionMode = false;
                    });
                  }
                  return;
                }
                if (isAddCatalog) { _addCatalog(); return; }
                _openRegion(region);
              },
              child: Padding(padding: const EdgeInsets.fromLTRB(28, 10, 10, 10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(region.icon, size: 30, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8),
                Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                if (!isAddCatalog) Text('$count стран', style: Theme.of(context).textTheme.labelSmall),
                if (isSelected) const Padding(padding: EdgeInsets.only(top: 4), child: Icon(Icons.check_circle, size: 20)),
              ])),
            )),
            if (isMyCatalog) Positioned(top: 0, right: 0, child: IconButton(
              padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 30),
              visualDensity: VisualDensity.compact, tooltip: 'Удалить каталог',
              icon: Icon(Icons.close, size: 16, color: Theme.of(context).colorScheme.error),
              onPressed: () { if (_catalogSelectionMode && isSelected) { _deleteSelectedCatalogs(); } else { _deleteCatalog(region.name); } },
            )),
          ])),
            ),
          ));
        }))
    ]),
    ),
  );
}

// ISO 3166-1 alpha-2 codes used to render actual country flag artwork.
const Map<String, String> _countryIsoCodes = {
  'Албания':'AL', 'Андорра':'AD', 'Австрия':'AT', 'Беларусь':'BY', 'Белоруссия':'BY',
  'Бельгия':'BE', 'Болгария':'BG', 'Босния и Герцеговина':'BA', 'Ватикан':'VA',
  'Великобритания':'GB', 'Венгрия':'HU', 'Германия':'DE', 'Греция':'GR', 'Дания':'DK',
  'Ирландия':'IE', 'Исландия':'IS', 'Испания':'ES', 'Италия':'IT', 'Кипр':'CY',
  'Косово':'XK', 'Латвия':'LV', 'Литва':'LT', 'Лихтенштейн':'LI', 'Люксембург':'LU',
  'Мальта':'MT', 'Молдова':'MD', 'Монако':'MC', 'Нидерланды':'NL', 'Норвегия':'NO',
  'Польша':'PL', 'Португалия':'PT', 'Россия':'RU', 'Румыния':'RO', 'Сан-Марино':'SM',
  'Северная Македония':'MK', 'Сербия':'RS', 'Словакия':'SK', 'Словения':'SI',
  'Турция':'TR', 'Украина':'UA', 'Финляндия':'FI', 'Франция':'FR', 'Хорватия':'HR',
  'Черногория':'ME', 'Чехия':'CZ', 'Швейцария':'CH', 'Швеция':'SE', 'Эстония':'EE',
  'Азербайджан':'AZ', 'Армения':'AM', 'Афганистан':'AF', 'Бангладеш':'BD', 'Бахрейн':'BH',
  'Бруней':'BN', 'Бутан':'BT', 'Вьетнам':'VN', 'Грузия':'GE', 'Израиль':'IL', 'Индия':'IN',
  'Индонезия':'ID', 'Иордания':'JO', 'Ирак':'IQ', 'Иран':'IR', 'Йемен':'YE', 'Казахстан':'KZ',
  'Камбоджа':'KH', 'Катар':'QA', 'Китай':'CN', 'КНДР':'KP', 'Кувейт':'KW', 'Кыргызстан':'KG',
  'Лаос':'LA', 'Ливан':'LB', 'Малайзия':'MY', 'Мальдивы':'MV', 'Монголия':'MN', 'Мьянма':'MM',
  'Непал':'NP', 'ОАЭ':'AE', 'Оман':'OM', 'Пакистан':'PK', 'Палестина':'PS',
  'Саудовская Аравия':'SA', 'Сингапур':'SG', 'Сирия':'SY', 'Таджикистан':'TJ', 'Таиланд':'TH',
  'Тайвань':'TW', 'Тимор-Лесте':'TL', 'Туркменистан':'TM', 'Узбекистан':'UZ',
  'Филиппины':'PH', 'Шри-Ланка':'LK', 'Южная Корея':'KR', 'Япония':'JP',
  'Алжир':'DZ', 'Ангола':'AO', 'Бенин':'BJ', 'Ботсвана':'BW', 'Буркина-Фасо':'BF',
  'Бурунди':'BI', 'Габон':'GA', 'Гамбия':'GM', 'Гана':'GH', 'Гвинея':'GN',
  'Гвинея-Бисау':'GW', 'Джибути':'DJ', 'Египет':'EG', 'Замбия':'ZM', 'Зимбабве':'ZW',
  'Кабо-Верде':'CV', 'Камерун':'CM', 'Кения':'KE', 'Коморы':'KM', 'Лесото':'LS',
  'Либерия':'LR', 'Ливия':'LY', 'Маврикий':'MU', 'Мавритания':'MR', 'Мадагаскар':'MG',
  'Малави':'MW', 'Мали':'ML', 'Марокко':'MA', 'Мозамбик':'MZ', 'Намибия':'NA',
  'Нигер':'NE', 'Нигерия':'NG', 'Руанда':'RW', 'Сейшелы':'SC', 'Сенегал':'SN',
  'Сомали':'SO', 'Судан':'SD', 'Сьерра-Леоне':'SL', 'Танзания':'TZ', 'Того':'TG',
  'Тунис':'TN', 'Уганда':'UG', 'Чад':'TD', 'Эритрея':'ER', 'Эсватини':'SZ',
  'Эфиопия':'ET', 'ЮАР':'ZA', 'Южный Судан':'SS',
  'Антигуа и Барбуда':'AG', 'Багамы':'BS', 'Барбадос':'BB', 'Белиз':'BZ', 'Гаити':'HT',
  'Гватемала':'GT', 'Гондурас':'HN', 'Гренада':'GD', 'Доминика':'DM',
  'Доминиканская Республика':'DO', 'Канада':'CA', 'Коста-Рика':'CR', 'Куба':'CU',
  'Мексика':'MX', 'Никарагуа':'NI', 'Панама':'PA', 'Сальвадор':'SV', 'США':'US',
  'Тринидад и Тобаго':'TT', 'Ямайка':'JM', 'Аргентина':'AR', 'Боливия':'BO',
  'Бразилия':'BR', 'Венесуэла':'VE', 'Гайана':'GY', 'Колумбия':'CO', 'Парагвай':'PY',
  'Перу':'PE', 'Суринам':'SR', 'Уругвай':'UY', 'Чили':'CL', 'Эквадор':'EC',
  'Австралия':'AU', 'Вануату':'VU', 'Кирибати':'KI', 'Маршалловы Острова':'MH',
  'Микронезия':'FM', 'Науру':'NR', 'Новая Зеландия':'NZ', 'Палау':'PW',
  'Папуа — Новая Гвинея':'PG', 'Самоа':'WS', 'Соломоновы Острова':'SB', 'Тонга':'TO',
  'Тувалу':'TV', 'Фиджи':'FJ', 'Гуам':'GU', 'Новая Каледония':'NC', 'Острова Кука':'CK',
  'Абхазия':'GE',
};

Widget _countryFlag(String country) {
  final code = _countryIsoCodes[country];
  if (code == null) return const SizedBox(width: 36, height: 24, child: Icon(Icons.flag_outlined));
  return ClipRRect(
    borderRadius: BorderRadius.circular(3),
    child: CountryFlag.fromCountryCode(
      code,
      theme: const ImageTheme(width: 36, height: 24),
    ),
  );
}

class CountryListPage extends StatefulWidget {
  final _Region region;
  final bool isMyCatalog;
  final String? catalogName;
  const CountryListPage({super.key, required this.region, this.isMyCatalog = false, this.catalogName});
  @override
  State<CountryListPage> createState() => _CountryListPageState();
}

class _CountryListPageState extends State<CountryListPage> {
  String query = '';
  late List<String> _myCountries;
  List<String> _catalogNames = [_defaultMyCatalogName];
  Set<String> _allCatalogCountries = {};
  Map<String, List<String>> _countryCatalogMembership = {};
  OverlayEntry? _membershipOverlay;
  Timer? _membershipHideTimer;
  Timer? _membershipPressTimer;
  bool _membershipPressActivated = false;

  @override
  void initState() {
    super.initState();
    _myCountries = List<String>.from(widget.region.countries);
    _loadMyCountries();
  }

  Future<void> _loadMyCountries() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _myCountries = prefs.getStringList(_catalogCountriesKey(widget.catalogName ?? _defaultMyCatalogName)) ?? [];
      _catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? [_defaultMyCatalogName];
      _countryCatalogMembership = {
        for (final country in widget.region.countries)
          country: _catalogNames.where((n) => (prefs.getStringList(_catalogCountriesKey(n)) ?? <String>[]).contains(country)).toList(),
      };
      _allCatalogCountries = _countryCatalogMembership.entries.where((e) => e.value.isNotEmpty).map((e) => e.key).toSet();
    });
  }

  void _showMembershipOverlay(String country, BuildContext anchorContext) {
    _membershipHideTimer?.cancel();
    _membershipPressTimer?.cancel();
    _membershipOverlay?.remove();
    _membershipOverlay = null;
    final catalogs = _countryCatalogMembership[country] ?? <String>[];
    if (catalogs.isEmpty) return;
    final box = anchorContext.findRenderObject() as RenderBox?;
    final overlay = Overlay.of(context);
    if (box == null || !box.hasSize) return;
    final origin = box.localToGlobal(Offset.zero);
    final screen = MediaQuery.of(context).size;
    final left = (origin.dx - 210).clamp(8.0, screen.width - 240.0);
    final top = (origin.dy - 8).clamp(8.0, screen.height - 180.0);
    _membershipOverlay = OverlayEntry(builder: (context) => Positioned(
      left: left,
      top: top,
      child: Material(
        color: Colors.transparent,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 230, maxHeight: screen.height * 0.45),
          child: Card(
            elevation: 10,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('«$country» добавлена в:', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Flexible(child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final name in catalogs) Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text('• $name'))]))),
              ]),
            ),
          ),
        ),
      ),
    ));
    overlay.insert(_membershipOverlay!);
  }

  void _finishMembershipPress() {
    _membershipHideTimer?.cancel();
    _membershipHideTimer = Timer(const Duration(seconds: 2), _hideMembershipOverlay);
  }

  void _hideMembershipOverlay() {
    _membershipOverlay?.remove();
    _membershipOverlay = null;
  }

  Future<void> _toggleMyCountry(String country) async {
    final prefs = await SharedPreferences.getInstance();
    String? targetName = widget.catalogName;
    var removeMembership = false;
    if (!widget.isMyCatalog) {
      _catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? _catalogNames;
      final currentMembership = _catalogNames.where((name) => (prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[]).contains(country)).toSet();
      final action = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
        title: Text('Добавить «$country» в каталог'),
        content: SizedBox(width: double.maxFinite, child: ListView(shrinkWrap: true, children: [
          for (final name in _catalogNames) ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(name),
            trailing: currentMembership.contains(name)
                ? IconButton(tooltip: 'Исключить страну из $name', icon: const Icon(Icons.delete_outline), onPressed: () => Navigator.pop(ctx, 'remove|$name'))
                : const Icon(Icons.add_circle_outline),
            onTap: currentMembership.contains(name) ? null : () => Navigator.pop(ctx, 'add|$name'),
            subtitle: currentMembership.contains(name) ? const Text('Страна уже добавлена') : null,
          ),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, '__cancel__'), child: const Text('Закрыть'))],
      ));
      if (action == null || action == '__cancel__') return;
      final parts = action.split('|');
      if (parts.length != 2) return;
      removeMembership = parts[0] == 'remove';
      targetName = parts[1];
    }
    final key = _catalogCountriesKey(targetName ?? _defaultMyCatalogName);
    final list = prefs.getStringList(key) ?? <String>[];
    if (widget.isMyCatalog || removeMembership || list.contains(country)) {
      list.remove(country);
    } else {
      list.add(country);
    }
    await prefs.setStringList(key, list);
    final refreshedMembership = <String>[];
    for (final name in _catalogNames) {
      if ((prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[]).contains(country)) refreshedMembership.add(name);
    }
    if (!mounted) return;
    setState(() {
      if (widget.isMyCatalog) _myCountries = list;
      _countryCatalogMembership[country] = refreshedMembership;
      if (refreshedMembership.isEmpty) { _allCatalogCountries.remove(country); } else { _allCatalogCountries.add(country); }
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(widget.isMyCatalog || removeMembership || !list.contains(country) ? 'Страна удалена из «${targetName ?? _defaultMyCatalogName}»' : 'Страна добавлена в «$targetName»'),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  void dispose() {
    _membershipHideTimer?.cancel();
    _membershipPressTimer?.cancel();
    _hideMembershipOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sourceCountries = widget.isMyCatalog ? _myCountries : widget.region.countries;
    final countries = sourceCountries.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList()
      ..sort((a,b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(appBar: AppBar(title: Text(widget.region.name)), body: Column(children: [
      if (widget.isMyCatalog) Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () async { final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Очистить Мой каталог?'), content: const Text('Все страны будут удалены из этого списка.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Убрать все'))])); if (ok == true) { final prefs = await SharedPreferences.getInstance(); await prefs.setStringList(_catalogCountriesKey(widget.catalogName ?? _defaultMyCatalogName), []); if (mounted) setState(() => _myCountries = []); } }, icon: const Icon(Icons.delete_sweep_outlined), label: const Text('Убрать все страны')))),
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SearchBar(leading: const Icon(Icons.search), hintText: 'Поиск страны или территории', onChanged: (v) => setState(() => query = v),)),
      Expanded(
        child: countries.isEmpty
            ? Center(child: Text(widget.isMyCatalog ? 'Список пуст. Откройте часть света и нажмите + у нужных стран.' : 'Ничего не найдено', textAlign: TextAlign.center))
            : ListView.separated(
                itemCount: countries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final country = countries[index];
                  final isAdded = _allCatalogCountries.contains(country);
                  return ListTile(
                    leading: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: country == 'Австрия' ? () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AustriaInfoPage())) : null,
                      child: Padding(padding: const EdgeInsets.all(4), child: _countryFlag(country)),
                    ),
                    title: Text(country),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Builder(builder: (iconContext) => GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: isAdded && !widget.isMyCatalog ? (_) {
                          _membershipPressActivated = false;
                          _membershipPressTimer?.cancel();
                          _membershipPressTimer = Timer(const Duration(milliseconds: 500), () {
                            if (!mounted) return;
                            _membershipPressActivated = true;
                            _showMembershipOverlay(country, iconContext);
                          });
                        } : null,
                        onTapUp: isAdded && !widget.isMyCatalog ? (_) {
                          _membershipPressTimer?.cancel();
                          if (_membershipPressActivated) _finishMembershipPress();
                        } : null,
                        onTapCancel: isAdded && !widget.isMyCatalog ? () {
                          _membershipPressTimer?.cancel();
                          if (_membershipPressActivated) _finishMembershipPress();
                        } : null,
                        onTap: () {
                          if (_membershipPressActivated) { _membershipPressActivated = false; return; }
                          _toggleMyCountry(country);
                        },
                        child: SizedBox(width: 48, height: 48, child: Center(child: Icon(
                          widget.isMyCatalog ? Icons.remove_circle_outline : isAdded ? Icons.check_circle : Icons.add_circle_outline,
                          color: isAdded && !widget.isMyCatalog ? Theme.of(context).colorScheme.primary : null,
                        ))),
                      )),
                      const Icon(Icons.chevron_right),
                    ]),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => country == 'Австрия' ? const AustriaPeriodsPage() : UcoinCountryPage(country: country))),
                  );
                },
              ),
      ),
    ]));
  }
}



const List<_AustriaPeriod> _austriaPeriods = [
  _AustriaPeriod('Европейский союз (Евро)', '2002 - 2026', 311),
  _AustriaPeriod('ЭКЮ', '1979 - 1998', 759),
  _AustriaPeriod('Вторая Республика', '1946 - 2001', 0),
  _AustriaPeriod('Первая Республика (Шиллинг)', '1925 - 1938', 0),
  _AustriaPeriod('Первая Республика (Крона)', '1923 - 1924', 0),
  _AustriaPeriod('Австро-венгерская крона', '1892 - 1918', 0),
  _AustriaPeriod('Австро-венгерский гульден', '1857 - 1892', 0),
  _AustriaPeriod('Австрийская империя', '1806 - 1857', 0),
  _AustriaPeriod('Священная Римская империя (Крейцер)', '1741 - 1806', 0),
  _AustriaPeriod('Священная Римская империя (Талер)', '1741 - 1805', 0),
  _AustriaPeriod('Священная Римская империя', '1705 - 1740', 0),
  _AustriaPeriod('Священная Римская империя', '1658 - 1704', 0),
  _AustriaPeriod('Священная Римская империя', '1608 - 1657', 0),
  _AustriaPeriod('Священная Римская империя', '1520 - 1607', 0),
];
class _AustriaPeriod { final String name, years; final int ucoinId; const _AustriaPeriod(this.name, this.years, this.ucoinId); }

class AustriaPeriodsPage extends StatefulWidget {
  const AustriaPeriodsPage({super.key});
  @override State<AustriaPeriodsPage> createState() => _AustriaPeriodsPageState();
}

class _AustriaPeriodsPageState extends State<AustriaPeriodsPage> {
  Map<String, int> _ownedByPeriod = {};
  int _category = 0;
  final _categoryNames = const ['Регулярный чекан', 'Юбилейные монеты', 'Коллекционные монеты'];
  @override void initState() { super.initState(); _loadPeriodCounts(); }
  Future<void> _loadPeriodCounts() async {
    final prefs = await SharedPreferences.getInstance();
    final result = <String, int>{};
    for (final period in _austriaPeriods) {
      final key = 'austria_coin_counts_v2_${period.years}_${period.name}';
      final raw = prefs.getString(key);
      if (raw == null) { result[key] = 0; continue; }
      try {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        result[key] = data.values.where((value) => value is num && value > 0).length;
      } catch (_) { result[key] = 0; }
    }
    if (mounted) setState(() => _ownedByPeriod = result);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Австрия — периоды')),
    body: ListView(padding: const EdgeInsets.all(8), children: [
      Padding(padding: const EdgeInsets.all(4), child: Wrap(spacing: 6, runSpacing: 6, children: [for (var i=0; i<_categoryNames.length; i++) ChoiceChip(label: Text(_categoryNames[i]), selected: _category == i, onSelected: (_) => setState(() => _category = i))])),
      Padding(padding: const EdgeInsets.all(8), child: Text(_category == 0 ? 'Регулярный чекан · ${_categoryNames[_category]}' : _categoryNames[_category], style: const TextStyle(fontSize: 13))),
      if (_category == 1 || _category == 2) Card(child: ListTile(leading: const Icon(Icons.open_in_new), title: Text(_categoryNames[_category]), subtitle: const Text('Откройте соответствующий раздел каталога uCoin'), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => UcoinCountryPage(country: 'Австрия'))))),
      if (_category == 0) for (final p in _austriaPeriods.where((p) => p.ucoinId == 311)) Card(child: ListTile(
        title: Text(p.name),
        subtitle: Text(p.years),
        leading: IconButton(tooltip: 'Сохранить каталог для работы офлайн', icon: const Icon(Icons.download_for_offline_outlined), onPressed: () async {
          try { final dir = await _saveAustriaPeriod(p); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Каталог сохранён: $dir'))); }
          catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e'))); }
        }),
        trailing: Text(p.name == 'Европейский союз (Евро)' ? '${_austriaEuroCoinsByYear().length}/${_ownedByPeriod['austria_coin_counts_v2_${p.years}_${p.name}'] ?? 0}' : '0/0', style: const TextStyle(fontWeight: FontWeight.w700)),
        onTap: () async { await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AustriaCoinsPage(period: p))); await _loadPeriodCounts(); },
      )),
      const Padding(padding: EdgeInsets.all(8), child: Text('Источник периодов: ru.ucoin.net/catalog/?country=austria', style: TextStyle(fontSize: 12, color: Colors.black54))),
    ]));
}

// The left period counter is derived from the actual in-app list below, not a hard-coded example.

const _euroDenominations = <_AustriaCoin>[
  _AustriaCoin('1 евроцент', '', 'KM# 3082', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евроцента', '', 'KM# 3083', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('5 евроцентов', '', 'KM# 3084', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('10 евроцентов', '', 'KM# 3085 / 3139', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('20 евроцентов', '', 'KM# 3086 / 3140', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('50 евроцентов', '', 'KM# 3087 / 3141', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('1 евро', '', 'KM# 3088 / 3142', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евро', '', 'KM# 3089 / 3143', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
];
List<_AustriaCoin> _austriaEuroCoinsByYear() => [
  for (var year = 2002; year <= 2026; year++)
    for (final denomination in _euroDenominations)
      _AustriaCoin(denomination.denomination, '$year', denomination.km, denomination.url),
];
int _euroDenominationOrder(String value) { const order=['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро']; final i=order.indexOf(value); return i < 0 ? order.length : i; }
List<String> _austriaEuroDenominations() => const ['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро'];
class _AustriaCoin { final String denomination, years, km, url; const _AustriaCoin(this.denomination,this.years,this.km,this.url); String? get reverseImageUrl { switch (denomination) { case '1 евроцент': return 'https://i.ucoin.net/coin/49/394/49394453-2/austria-1-euro-cent-2012.jpg'; case '1 евро': return 'https://i.ucoin.net/coin/66/799/66799270-2/austria-1-euro-2011.jpg'; default: return null; } } }

Future<String> _saveAustriaPeriod(_AustriaPeriod p) async {
  final prefs = await SharedPreferences.getInstance();
  final chosen = prefs.getString('catalog_save_directory_v1');
  Directory base;
  if (chosen != null && chosen.isNotEmpty) { base = Directory(chosen); if (!await base.exists()) await base.create(recursive: true); }
  else { base = await getApplicationDocumentsDirectory(); }
  final safe = '${p.name}_${p.years}'.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё0-9_-]+'), '_');
  final out = Directory('${base.path}/Австрия_$safe'); await out.create(recursive: true);
  final coins = p.name == 'Европейский союз (Евро)' ? _austriaEuroCoinsByYear().map((c) => {'номинал':c.denomination,'год выпуска':c.years,'каталожный номер':c.km,'источник':c.url}).toList() : <Map<String,String>>[];
  final data = {'страна':'Австрия','период':p.name,'годы':p.years,'источник':'https://ru.ucoin.net/catalog/?country=austria${p.ucoinId > 0 ? '&period=${p.ucoinId}' : ''}','монеты':coins,'примечание': coins.isEmpty ? 'Список монет этого исторического периода пока не загружен в приложение.' : 'Каждая комбинация номинала и года вынесена в отдельную строку. Сверяйте фактический выпуск конкретного года с данными uCoin.'};
  await File('${out.path}/catalog.json').writeAsString(const JsonEncoder.withIndent('  ').convert(data), flush:true);
  await File('${out.path}/README.txt').writeAsString('Австрия — ${p.name} (${p.years})\nКаталог монет в catalog.json.\nИсточник: ${data['источник']}\n', flush:true);
  return out.path;
}

class AustriaCoinsPage extends StatefulWidget { final _AustriaPeriod period; const AustriaCoinsPage({super.key, required this.period}); @override State<AustriaCoinsPage> createState()=>_AustriaCoinsPageState(); }
class _AustriaCoinsPageState extends State<AustriaCoinsPage> {
  Map<String,int> counts = {};
  bool sortByYear = false;
  bool saveReverseImages = false;
  String? selectedDenomination;
  int? selectedYear;
  String get storageKey => 'austria_coin_counts_v2_${widget.period.years}_${widget.period.name}';
  @override void initState(){ super.initState(); _load(); _loadImageSetting(); }
  String get imageSettingKey => 'save_reverse_images_v1_${widget.period.years}_${widget.period.name}';
  String get imageFolderKey => '${widget.period.years}_${widget.period.name}'.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё0-9_-]+'), '_');
  Future<void> _loadImageSetting() async { final p=await SharedPreferences.getInstance(); if(mounted)setState(()=>saveReverseImages=p.getBool(imageSettingKey)??false); }
  Future<Directory> _reverseImageDirectory() async { final base=await getApplicationSupportDirectory(); final d=Directory('${base.path}/coin_images/${imageFolderKey}'); await d.create(recursive:true); return d; }
  Future<void> _deleteReverseImages() async { final d=await _reverseImageDirectory(); if(await d.exists()) await d.delete(recursive:true); if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Сохранённые изображения этого подраздела удалены'))); }
  Future<void> _setSaveReverseImages(bool value) async { final p=await SharedPreferences.getInstance(); await p.setBool(imageSettingKey,value); if(mounted)setState(()=>saveReverseImages=value); if(value) await _cacheReverseImages(_austriaEuroCoinsByYear()); }
  Future<void> _cacheReverseImages(List<_AustriaCoin> list) async { final dir=await _reverseImageDirectory(); for(final c in list) { final url=c.reverseImageUrl; if(url==null) continue; final file=File('${dir.path}/${c.denomination}_${c.years}.jpg'.replaceAll(' ', '_')); if(await file.exists()) continue; try { final response=await http.get(Uri.parse(url)).timeout(const Duration(seconds:12)); final type=response.headers['content-type']??''; if(response.statusCode==200 && type.startsWith('image/')) await file.writeAsBytes(response.bodyBytes,flush:true); } catch(_) {} } }
  Future<void> _openImageSettingCacheIfEnabled(List<_AustriaCoin> list) async { if(saveReverseImages) await _cacheReverseImages(list); }
  Widget _coinImage(_AustriaCoin c) { return FutureBuilder<File?>(future: _localCoinImage(c), builder:(context,snapshot) { final file=snapshot.data; final url=c.reverseImageUrl; if(file!=null) return Image.file(file,width:54,height:54,fit:BoxFit.contain); if(url!=null) return Image.network(url,width:54,height:54,fit:BoxFit.contain,errorBuilder:(_,__,___)=>_coinFallback()); return _coinFallback(); }); }
  Widget _coinFallback()=>Container(width:54,height:54,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,shape:BoxShape.circle),child:const Icon(Icons.monetization_on_outlined,size:30));
  Future<File?> _localCoinImage(_AustriaCoin c) async { final d=await _reverseImageDirectory(); final f=File('${d.path}/${c.denomination}_${c.years}.jpg'.replaceAll(' ', '_')); return await f.exists()?f:null; }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString(storageKey); if(raw!=null){try{final m=jsonDecode(raw) as Map<String,dynamic>; if(mounted)setState(()=>counts=m.map((k,v)=>MapEntry(k,(v as num).toInt())));}catch(_){}} }
  Future<void> _change(String key,int delta) async { final next=(counts[key]??0)+delta; if(next<0)return; final updated=Map<String,int>.from(counts); updated[key]=next; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _setCount(String key, int value) async { final updated=Map<String,int>.from(counts); updated[key]=value < 0 ? 0 : value; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _editCount(String key) async {
    final controller=TextEditingController(text:'${counts[key]??0}');
    final value=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Количество монет'),content:TextField(controller:controller,keyboardType:TextInputType.number,autofocus:true,decoration:const InputDecoration(labelText:'В наличии',border:OutlineInputBorder()),),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Отмена')),FilledButton(onPressed:(){final n=int.tryParse(controller.text.trim()); if(n!=null && n>=0) Navigator.pop(ctx,n);},child:const Text('Сохранить'))]));
    controller.dispose(); if(value!=null) await _setCount(key,value);
  }
  Future<void> _confirmResetPeriod() async {
    final confirmed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Сбросить количество?'),content:Text('Количество монет периода «${widget.period.name}» будет установлено в 0. Другие периоды не изменятся.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:Theme.of(ctx).colorScheme.error),child:const Text('Сбросить'))]));
    if(confirmed!=true)return;
    final prefs=await SharedPreferences.getInstance();
    final zeroed=<String,int>{for(final key in counts.keys) key:0};
    await prefs.setString(storageKey,jsonEncode(zeroed));
    if(mounted){setState(()=>counts=zeroed); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Количество монет этого периода сброшено')));}
  }
  Widget _roundCounterButton(IconData icon, VoidCallback? onPressed, {required bool outwardLeft}) {
    return SizedBox(
      width: 38,
      height: 46,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onPressed,
        child: Padding(
          padding: EdgeInsets.only(
            left: outwardLeft ? 8 : 0,
            right: outwardLeft ? 0 : 8,
          ),
          child: Center(
            child: Material(
              color: onPressed == null
                  ? Colors.black12
                  : Theme.of(context).colorScheme.primary,
              shape: const CircleBorder(),
              child: SizedBox(
                width: 30,
                height: 30,
                child: Icon(
                  icon,
                  size: 18,
                  color: onPressed == null ? Colors.black38 : Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  @override Widget build(BuildContext context) {
    final euro=widget.period.ucoinId==311; final coins=euro?_austriaEuroCoinsByYear():<_AustriaCoin>[];
    if (euro) {
      _openImageSettingCacheIfEnabled(coins);
      if (selectedDenomination != null) coins.removeWhere((c) => c.denomination != selectedDenomination);
      if (selectedYear != null) coins.removeWhere((c) => c.years != '$selectedYear');
      coins.sort((a,b) {
        final ya=int.tryParse(a.years)??0, yb=int.tryParse(b.years)??0;
        if (sortByYear) { final byYear=ya.compareTo(yb); return byYear != 0 ? byYear : _euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination)); }
        final byDenomination=_euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination));
        return byDenomination != 0 ? byDenomination : ya.compareTo(yb);
      });
    }
    return Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisSize:MainAxisSize.min,children:[const Text('Австрия',style:TextStyle(fontSize:18)),Text('${widget.period.name} (${widget.period.years})',style:const TextStyle(fontSize:13,fontWeight:FontWeight.normal))])),body:ListView(padding:const EdgeInsets.all(8),children:[
      if(euro) Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Row(children:[ChoiceChip(label:const Text('По номиналу'),selected:!sortByYear,onSelected:(_)=>setState(()=>sortByYear=false)),const SizedBox(width:6),ChoiceChip(label:const Text('По годам'),selected:sortByYear,onSelected:(_)=>setState(()=>sortByYear=true)),const Spacer(),IconButton(tooltip:'Сбросить все фильтры',visualDensity:VisualDensity.compact,padding:EdgeInsets.zero,constraints:const BoxConstraints.tightFor(width:32,height:40),icon:const Icon(Icons.filter_alt_off,size:20),onPressed:()=>setState((){selectedDenomination=null;selectedYear=null;}))]),const SizedBox(height:6),sortByYear ? DropdownButtonFormField<int>(value:selectedYear,decoration:const InputDecoration(labelText:'Год',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все годы'),items:[const DropdownMenuItem<int>(value:null,child:Text('Все годы')),...List.generate(25,(i)=>2002+i).map((y)=>DropdownMenuItem<int>(value:y,child:Text('$y')))],onChanged:(v)=>setState(()=>selectedYear=v)) : DropdownButtonFormField<String>(value:selectedDenomination,decoration:const InputDecoration(labelText:'Номинал',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все номиналы'),items:[const DropdownMenuItem<String>(value:null,child:Text('Все номиналы')),..._austriaEuroDenominations().map((d)=>DropdownMenuItem<String>(value:d,child:Text(d)))],onChanged:(v)=>setState(()=>selectedDenomination=v))])),
      if(!euro) const Padding(padding:EdgeInsets.symmetric(vertical:16),child:Text('Для этого исторического периода полный список монет пока не загружен. Откройте uCoin по ссылке ниже, чтобы просмотреть актуальный каталог.')),
      if(euro) Row(children:[IconButton(tooltip:saveReverseImages?'Не сохранять изображения автоматически':'Сохранять изображения этого подраздела',icon:Icon(saveReverseImages?Icons.image:Icons.image_outlined),onPressed:()=>_setSaveReverseImages(!saveReverseImages)),IconButton(tooltip:'Удалить сохранённые изображения этого подраздела',icon:const Icon(Icons.delete_outline),onPressed:_deleteReverseImages),const Spacer(),IconButton(tooltip:'Сбросить количество монет этого периода',icon:const Icon(Icons.delete_sweep_outlined),onPressed:_confirmResetPeriod)]),
      for(final c in coins) Card(clipBehavior:Clip.antiAlias,child:ListTile(contentPadding:const EdgeInsets.only(left:0,right:8),minLeadingWidth:54,horizontalTitleGap:8,
        leading: SizedBox(width:54,height:54,child:ClipRRect(borderRadius:BorderRadius.circular(27),child:_coinImage(c))),
        title:Text('${c.denomination} ${c.years}'),subtitle:null,isThreeLine:false,
        trailing:SizedBox(height:30,child:Row(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.center,children:[_roundCounterButton(Icons.remove, (counts['${c.denomination}_${c.years}']??0)>0?()=>_change('${c.denomination}_${c.years}',-1):null, outwardLeft:true),SizedBox(width:30,height:30,child:Material(color:Colors.transparent,child:InkWell(onTap:()=>_editCount('${c.denomination}_${c.years}'),borderRadius:BorderRadius.circular(6),child:Center(child:FittedBox(fit:BoxFit.scaleDown,child:Text('${counts['${c.denomination}_${c.years}']??0}',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:22,height:1.0))))))),_roundCounterButton(Icons.add,()=>_change('${c.denomination}_${c.years}',1), outwardLeft:false)])),
        onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))),
      )),
      Card(child:ListTile(leading:const Icon(Icons.open_in_new),title:const Text('Полный каталог на uCoin'),subtitle:Text('Австрия · ${widget.period.name} · ${widget.period.years}'),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))))),
      const Padding(padding:EdgeInsets.all(8),child:Text('Изображения загружаются из сети. Количество монет сохраняется на устройстве.',style:TextStyle(fontSize:12,color:Colors.black54))),
    ]));
  }
}

class _ContinuousColorPalettePainter extends CustomPainter {
  const _ContinuousColorPalettePainter({required this.saturation, required this.markerX, required this.markerY});
  final double saturation;
  final double markerX;
  final double markerY;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final huePaint = Paint()..shader = const LinearGradient(colors: [
      Color(0xFFFF0000), Color(0xFFFFFF00), Color(0xFF00FF00),
      Color(0xFF00FFFF), Color(0xFF0000FF), Color(0xFFFF00FF), Color(0xFFFF0000),
    ]).createShader(rect);
    canvas.drawRect(rect, huePaint);
    if (saturation < 1) {
      canvas.drawRect(rect, Paint()..color = Colors.white.withOpacity(1 - saturation));
    }
    final shadePaint = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black]).createShader(rect);
    canvas.drawRect(rect, shadePaint);
    final point = Offset(markerX.clamp(0.0, size.width), markerY.clamp(0.0, size.height));
    canvas.drawCircle(point, 9, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 3);
    canvas.drawCircle(point, 9, Paint()..color = Colors.black..style = PaintingStyle.stroke..strokeWidth = 1);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), Paint()..color = Colors.black26..style = PaintingStyle.stroke..strokeWidth = 1);
  }

  @override
  bool shouldRepaint(covariant _ContinuousColorPalettePainter oldDelegate) => saturation != oldDelegate.saturation || markerX != oldDelegate.markerX || markerY != oldDelegate.markerY;
}

class _AnyTileColorDialog extends StatefulWidget {
  const _AnyTileColorDialog({required this.initialColor});
  final Color initialColor;
  @override
  State<_AnyTileColorDialog> createState() => _AnyTileColorDialogState();
}

class _AnyTileColorDialogState extends State<_AnyTileColorDialog> {
  late double hue;
  late double smoothSaturation;
  late double gridSaturation;
  late double value;
  bool useClassicGrid = false;
  List<int> recentColors = [];
  static const String _recentColorsKey = 'any_color_palette_recent_v1';
  static const String _smoothSaturationKey = 'any_color_palette_smooth_saturation_v1';
  static const String _gridSaturationKey = 'any_color_palette_grid_saturation_v1';

  @override
  void initState() {
    super.initState();
    final hsv = HSVColor.fromColor(widget.initialColor);
    hue = hsv.hue;
    smoothSaturation = hsv.saturation;
    gridSaturation = hsv.saturation;
    value = hsv.value;
    SharedPreferences.getInstance().then((prefs) {
      if (!mounted) return;
      setState(() {
        recentColors = prefs.getStringList(_recentColorsKey)
            ?.map((e) => int.tryParse(e)).whereType<int>().take(16).toList() ?? [];
        smoothSaturation = (prefs.getDouble(_smoothSaturationKey) ?? smoothSaturation).clamp(0.0, 1.0).toDouble();
        gridSaturation = (prefs.getDouble(_gridSaturationKey) ?? gridSaturation).clamp(0.0, 1.0).toDouble();
      });
    });
  }

  double get saturation => useClassicGrid ? gridSaturation : smoothSaturation;
  Color get selectedColor => HSVColor.fromAHSV(1, hue, saturation, value).toColor();

  void _selectRecent(int colorValue) {
    final hsv = HSVColor.fromColor(Color(colorValue));
    setState(() {
      hue = hsv.hue;
      value = hsv.value;
      if (useClassicGrid) { gridSaturation = hsv.saturation; } else { smoothSaturation = hsv.saturation; }
    });
  }

  Future<void> _confirmColor() async {
    final colorValue = selectedColor.value;
    final updated = <int>[colorValue, ...recentColors.where((c) => c != colorValue)].take(16).toList();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_recentColorsKey, updated.map((c) => c.toString()).toList());
    await prefs.setDouble(_smoothSaturationKey, smoothSaturation);
    await prefs.setDouble(_gridSaturationKey, gridSaturation);
    if (mounted) Navigator.of(context).pop(Color(colorValue));
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Палитра любого цвета'),
    content: SizedBox(
      width: 360,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(height: 42, decoration: BoxDecoration(color: selectedColor, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.black26))),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: ChoiceChip(label: const Text('Плавная'), selected: !useClassicGrid, onSelected: (_) => setState(() => useClassicGrid = false))),
          const SizedBox(width: 8),
          Expanded(child: ChoiceChip(label: const Text('Сетка'), selected: useClassicGrid, onSelected: (_) => setState(() => useClassicGrid = true))),
        ]),
        if (recentColors.isNotEmpty) ...[
          Row(children: [
            const Expanded(child: Align(alignment: Alignment.centerLeft, child: Text('16 последних выбранных цветов'))),
            TextButton(onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove(_recentColorsKey);
              if (mounted) setState(() => recentColors.clear());
            }, child: const Text('Очистить все')),
          ]),
          const SizedBox(height: 5),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final colorValue in recentColors)
              GestureDetector(
                onTap: () => _selectRecent(colorValue),
                onDoubleTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  final updated = recentColors.where((c) => c != colorValue).toList();
                  await prefs.setStringList(_recentColorsKey, updated.map((c) => c.toString()).toList());
                  if (mounted) setState(() => recentColors = updated);
                },
                child: Container(width: 27, height: 27, decoration: BoxDecoration(color: Color(colorValue), borderRadius: BorderRadius.circular(6), border: Border.all(color: colorValue == selectedColor.value ? Colors.black : Colors.black26, width: colorValue == selectedColor.value ? 2 : 1))),
              ),
          ]),
          const SizedBox(height: 4),
        ],
        if (!useClassicGrid) ...[
          const Align(alignment: Alignment.centerLeft, child: Text('Слева направо — оттенок, вверх — ярче, вниз — темнее')),
          const SizedBox(height: 8),
          SizedBox(
            height: 190,
            width: double.infinity,
            child: LayoutBuilder(builder: (context, constraints) {
              void updateFromPosition(Offset local) {
                setState(() {
                  hue = (local.dx / constraints.maxWidth * 360).clamp(0.0, 359.99);
                  value = (1 - local.dy / constraints.maxHeight).clamp(0.05, 1.0);
                });
              }
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapDown: (details) => updateFromPosition(details.localPosition),
                onPanDown: (details) => updateFromPosition(details.localPosition),
                onPanUpdate: (details) => updateFromPosition(details.localPosition),
                child: CustomPaint(
                  painter: _ContinuousColorPalettePainter(saturation: saturation, markerX: hue / 360 * constraints.maxWidth, markerY: (1 - value) * constraints.maxHeight),
                  child: const SizedBox.expand(),
                ),
              );
            }),
          ),
        ] else ...[
          const Align(alignment: Alignment.centerLeft, child: Text('Набор цветов')),
          const SizedBox(height: 6),
          SizedBox(height: 330, child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: 12 * 11,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 12, crossAxisSpacing: 3, mainAxisSpacing: 3, childAspectRatio: 1.0),
            itemBuilder: (context, index) {
              final column = index % 12;
              final row = index ~/ 12;
              final cellHue = column * 30.0;
              final cellSaturation = 1.0 - row / 10.0;
              final cellColor = HSVColor.fromAHSV(1, cellHue, cellSaturation, value).toColor();
              final selected = (hue - cellHue).abs() < 15 && (saturation - cellSaturation).abs() < 0.07;
              return InkWell(
                onTap: () => setState(() { hue = cellHue; gridSaturation = cellSaturation; }),
                borderRadius: BorderRadius.circular(4),
                child: Container(decoration: BoxDecoration(color: cellColor, borderRadius: BorderRadius.circular(4), border: Border.all(color: selected ? Colors.black : Colors.black12, width: selected ? 2.5 : 0.6))),
              );
            },
          )),
        ],
        const SizedBox(height: 8),
        // Keep the saturation control directly beneath the palette and above the dialog actions.
        SizedBox(
          height: 58,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Насыщенность'),
            Expanded(child: Slider(
              min: 0, max: 1, divisions: 100, value: saturation, activeColor: selectedColor,
              onChanged: (v) => setState(() { if (useClassicGrid) { gridSaturation = v; } else { smoothSaturation = v; } }),
            )),
          ]),
        ),
        Text('#${selectedColor.value.toRadixString(16).substring(2).toUpperCase()}'),
      ]),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Отмена')),
      FilledButton(onPressed: _confirmColor, child: const Text('Выбрать')),
    ],
  );
}

class AppSettingsPage extends StatefulWidget {
  const AppSettingsPage({super.key});
  @override
  State<AppSettingsPage> createState() => _AppSettingsPageState();
}

class _AppSettingsPageState extends State<AppSettingsPage> {
  String? path;
  bool saveInfoImages = true;
  int? standardTileColor;
  int? customTileColor;
  int? addCatalogTileColor;
  int? addCatalogCustomColor;
  int? standardCustomColor;
  int? userCustomColor;
  String colorTabTitle = 'Цвет';
  String storageTabTitle = 'Хранение данных';
  int selectedTab = 0;
  DateTime? _lastTabTap;
  static const _colorTabKey = 'settings_tab_color_title_v1';
  static const _storageTabKey = 'settings_tab_storage_title_v1';
  static const _standardCustomColorKey = 'home_standard_custom_color_v1';
  static const _userCustomColorKey = 'home_user_custom_color_v1';
  static const _addCatalogCustomColorKey = 'home_add_catalog_custom_color_v1';
  static const List<int> _extraColors = [
    0xFFE3F2FD, 0xFFBBDEFB, 0xFFD7CCC8, 0xFFFFE0B2, 0xFFFFCDD2,
    0xFFF8BBD0, 0xFFE1BEE7, 0xFFD1C4E9, 0xFFC5CAE9, 0xFFC8E6C9,
    0xFFDCEDC8, 0xFFF0F4C3, 0xFFFFF9C4, 0xFFB2DFDB, 0xFFB2EBF2,
    0xFFCFD8DC, 0xFFEEEEEE, 0xFFB0BEC5, 0xFFD7E3FC, 0xFFFCE4EC,
  ];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        path = p.getString('catalog_save_directory_v1');
        saveInfoImages = p.getBool('save_country_info_images_v1') ?? true;
        standardTileColor = p.getInt(_standardTileColorKey) ?? p.getInt(_legacyHomeTileColorKey);
        customTileColor = p.getInt(_customTileColorKey);
        addCatalogTileColor = p.getInt(_addCatalogTileColorKey);
        addCatalogCustomColor = p.getInt(_addCatalogCustomColorKey);
        standardCustomColor = p.getInt(_standardCustomColorKey);
        userCustomColor = p.getInt(_userCustomColorKey);
        colorTabTitle = p.getString(_colorTabKey) ?? 'Цвет';
        storageTabTitle = p.getString(_storageTabKey) ?? 'Хранение данных';
      });
    });
  }

  Future<void> _renameTab(bool colorTab) async {
    final controller = TextEditingController(text: colorTab ? colorTabTitle : storageTabTitle);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Переименовать вкладку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          decoration: const InputDecoration(labelText: 'Название'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    final name = result?.trim();
    if (name == null || name.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    if (colorTab) {
      await prefs.setString(_colorTabKey, name);
    } else {
      await prefs.setString(_storageTabKey, name);
    }
    if (mounted) setState(() {
      if (colorTab) { colorTabTitle = name; } else { storageTabTitle = name; }
    });
  }

  void _handleTabTap(int index) {
    final now = DateTime.now();
    final isDoubleTap = _lastTabTap != null &&
        now.difference(_lastTabTap!) < const Duration(milliseconds: 450) &&
        selectedTab == index;
    _lastTabTap = now;
    if (isDoubleTap) {
      _lastTabTap = null;
      _renameTab(index == 0);
    } else {
      setState(() => selectedTab = index);
    }
  }

  Widget _colorPalette({
    required String title,
    required int? selected,
    required int? customSelected,
    required Future<void> Function(int?, {bool custom}) onSelect,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          InkWell(
            onTap: () => onSelect(null, custom: false),
            borderRadius: BorderRadius.circular(24),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                shape: BoxShape.circle,
                border: Border.all(color: selected == null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == null ? 3 : 1),
              ),
              child: const Icon(Icons.palette_outlined, size: 20),
            ),
          ),
          for (final value in [..._homeTileColorOptions, ..._extraColors])
            InkWell(
              onTap: () => onSelect(value, custom: false),
              borderRadius: BorderRadius.circular(24),
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: Color(value), shape: BoxShape.circle,
                  border: Border.all(color: selected == value && customSelected == null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == value && customSelected == null ? 3 : 1),
                ),
              ),
            ),
          if (customSelected != null)
            InkWell(
              onTap: () => onSelect(customSelected, custom: true),
              borderRadius: BorderRadius.circular(24),
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(color: Color(customSelected), shape: BoxShape.circle, border: Border.all(color: selected == customSelected && customSelected != null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == customSelected ? 3 : 1)),
                child: const Icon(Icons.check, size: 18, color: Colors.black54),
              ),
            ),
          InkWell(
            onTap: () async {
              final picked = await showDialog<Color>(
                context: context,
                builder: (_) => _AnyTileColorDialog(initialColor: Color(selected ?? _homeTileColorOptions.first)),
              );
              if (picked != null) await onSelect(picked.value, custom: true);
            },
            borderRadius: BorderRadius.circular(24),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const SweepGradient(colors: [Colors.red, Colors.yellow, Colors.green, Colors.cyan, Colors.blue, Colors.purple, Colors.red]),
                border: Border.all(color: Theme.of(context).colorScheme.outline, width: 1.5),
              ),
              child: const Icon(Icons.colorize, size: 20, color: Colors.white),
            ),
          ),
        ],
      ),
      const SizedBox(height: 6),
      const Text('Первый круг — цвет по умолчанию. Радужный круг открывает отдельное окно выбора оттенка, насыщенности и яркости. Пользовательский цвет хранится отдельно от палитры.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ],
  );

  Future<void> _setTileColor({required int target, required int? value, required bool custom}) async {
    final prefs = await SharedPreferences.getInstance();
    final baseKey = target == 0 ? _standardTileColorKey : target == 1 ? _customTileColorKey : _addCatalogTileColorKey;
    final customKey = target == 0 ? _standardCustomColorKey : target == 1 ? _userCustomColorKey : _addCatalogCustomColorKey;
    if (value == null && !custom) {
      await prefs.remove(baseKey);
      await prefs.remove(customKey);
      if (target == 0) await prefs.remove(_legacyHomeTileColorKey);
    } else {
      await prefs.setInt(baseKey, value!);
      if (custom) {
        await prefs.setInt(customKey, value);
      } else {
        await prefs.remove(customKey);
      }
      if (target == 0) await prefs.remove(_legacyHomeTileColorKey);
    }
    if (mounted) setState(() {
      if (target == 0) {
        standardTileColor = value;
        standardCustomColor = custom ? value : null;
      } else if (target == 1) {
        customTileColor = value;
        userCustomColor = custom ? value : null;
      } else {
        addCatalogTileColor = value;
        addCatalogCustomColor = custom ? value : null;
      }
    });
  }

  Widget _colorSettings() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      _colorPalette(
        title: 'Стандартные плитки',
        selected: standardTileColor,
        customSelected: standardCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 0, value: value, custom: custom),
      ),
      const SizedBox(height: 24),
      _colorPalette(
        title: 'Пользовательские плитки «Мой каталог»',
        selected: customTileColor,
        customSelected: userCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 1, value: value, custom: custom),
      ),
      const SizedBox(height: 24),
      _colorPalette(
        title: 'Плитка «Добавить каталог»',
        selected: addCatalogTileColor,
        customSelected: addCatalogCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 2, value: value, custom: custom),
      ),
    ],
  );

  Widget _storageSettings() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Сохранять флаги, гербы и фото стран'),
        subtitle: const Text('При включении изображения загружаются в память приложения при открытии страницы с интернетом и доступны офлайн.'),
        value: saveInfoImages,
        onChanged: (v) async {
          final p = await SharedPreferences.getInstance();
          await p.setBool('save_country_info_images_v1', v);
          if (mounted) setState(() => saveInfoImages = v);
        },
      ),
      const Divider(height: 32),
      const Text('Папка для сохранения офлайн-каталогов', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(path ?? 'По умолчанию: папка документов приложения'),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: () async {
          final selected = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Выберите папку для каталогов');
          if (selected != null) {
            final p = await SharedPreferences.getInstance();
            await p.setString('catalog_save_directory_v1', selected);
            if (mounted) setState(() => path = selected);
          }
        },
        icon: const Icon(Icons.folder_open),
        label: const Text('Выбрать папку'),
      ),
      TextButton.icon(
        onPressed: () async {
          final p = await SharedPreferences.getInstance();
          await p.remove('catalog_save_directory_v1');
          if (mounted) setState(() => path = null);
        },
        icon: const Icon(Icons.restart_alt),
        label: const Text('Папка по умолчанию'),
      ),
      const Divider(height: 32),
      const Text('Пока полностью подготовлен офлайн-шаблон для евро Австрии. Для остальных исторических периодов структура и ссылки на uCoin доступны, но полные списки и изображения нужно загрузить отдельно.', style: TextStyle(color: Colors.black54)),
    ],
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Настройки'),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Row(children: [
          Expanded(child: GestureDetector(
            onTap: () => _handleTabTap(0),
            onDoubleTap: () => _renameTab(true),
            child: Container(height: 48, alignment: Alignment.center, decoration: BoxDecoration(border: Border(bottom: BorderSide(color: selectedTab == 0 ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3))),
              child: Text(colorTabTitle, style: TextStyle(fontWeight: selectedTab == 0 ? FontWeight.bold : FontWeight.normal, color: selectedTab == 0 ? Theme.of(context).colorScheme.primary : null))),
          )),
          Expanded(child: GestureDetector(
            onTap: () => _handleTabTap(1),
            onDoubleTap: () => _renameTab(false),
            child: Container(height: 48, alignment: Alignment.center, decoration: BoxDecoration(border: Border(bottom: BorderSide(color: selectedTab == 1 ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3))),
              child: Text(storageTabTitle, style: TextStyle(fontWeight: selectedTab == 1 ? FontWeight.bold : FontWeight.normal, color: selectedTab == 1 ? Theme.of(context).colorScheme.primary : null))),
          )),
        ]),
      ),
    ),
    body: IndexedStack(index: selectedTab, children: [_colorSettings(), _storageSettings()]),
  );
}

// Country facts for Austria: the short description is loaded from Wikipedia's REST API.
class AustriaInfoPage extends StatefulWidget {
  const AustriaInfoPage({super.key});
  @override
  State<AustriaInfoPage> createState() => _AustriaInfoPageState();
}

class _AustriaInfoPageState extends State<AustriaInfoPage> {
  String? _summary;
  String? _wikiImage;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadWikipedia();
  }

  Future<void> _loadWikipedia() async {
    try {
      final uri = Uri.https('ru.wikipedia.org', '/api/rest_v1/page/summary/Австрия');
      final response = await http.get(uri, headers: {'User-Agent': 'AMiK-SC/0.19 (country information app)'}).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw Exception('Wikipedia ответила кодом ${response.statusCode}');
      final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _summary = data['extract'] as String?;
        final thumbnail = data['thumbnail'];
        if (thumbnail is Map<String, dynamic>) _wikiImage = thumbnail['source'] as String?;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Не удалось загрузить описание из Википедии. Проверьте подключение к интернету.'; });
    }
  }

  Widget _fact(String label, String value, {String? subtitle}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 13, color: Colors.black54)),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      if (subtitle != null) Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );

  Widget _imagePanel(String title, String url, {double height = 150}) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, height: height, child: Image.network(url, fit: BoxFit.contain,
        loadingBuilder: (context, child, progress) => progress == null ? child : const Center(child: CircularProgressIndicator(strokeWidth: 2)),
        errorBuilder: (_, __, ___) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.broken_image_outlined, size: 30), const SizedBox(height: 6), const Text('Изображение недоступно'), TextButton(onPressed: () { (context as Element).markNeedsBuild(); }, child: const Text('Повторить'))])))),
    ])),
  );

  @override
  Widget build(BuildContext context) {
    const wikiUrl = 'https://ru.wikipedia.org/wiki/Австрия';
    return Scaffold(
      appBar: AppBar(title: const Text('Австрия')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Австрийская Республика', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _fact('Официальное название', 'Австрийская Республика (Republik Österreich)'),
          _fact('Столица', 'Вена'),
          _fact('Площадь страны', '83 879 км²', subtitle: '113-е место в мире по данным статьи Википедии'),
          _fact('Население', 'Около 9,2 млн человек', subtitle: 'Место в мире зависит от года оценки и источника'),
          _fact('Дата независимости', '27 июля 1955 года (Государственный договор)'),
          _fact('Официальный язык', 'Немецкий; в отдельных регионах признаны языки меньшинств'),
          _fact('Валюта', 'Евро (EUR)'),
          _fact('Интернет-домен', '.at'),
          _fact('Телефонный код', '+43'),
          _fact('Часовой пояс', 'UTC+1 зимой, UTC+2 летом'),
        ]))),
        if (_loading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
        if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_error!, style: const TextStyle(color: Colors.deepOrange))),
        if (_summary != null) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Описание из Википедии', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), Text(_summary!),
        ]))),
        _imagePanel('Расположение страны в Европе', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_in_European_Union.svg?width=960', height: 190),
        _imagePanel('Флаг Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Flag_of_Austria.svg?width=600', height: 110),
        _imagePanel('Герб Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_Bundesadler.png?width=500', height: 180),
        Card(child: ListTile(leading: const Icon(Icons.open_in_new), title: const Text('Открыть статью в Википедии'), subtitle: const Text('Подробная информация и источники'), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WikipediaArticlePage(url: wikiUrl))))),
        const Padding(padding: EdgeInsets.all(8), child: Text('Рейтинговые места приведены по данным статьи Википедии и могут меняться с обновлением статистики.', style: TextStyle(fontSize: 12, color: Colors.black54))),
      ]),
    );
  }
}

class WikipediaArticlePage extends StatefulWidget {
  final String url;
  const WikipediaArticlePage({super.key, required this.url});
  @override
  State<WikipediaArticlePage> createState() => _WikipediaArticlePageState();
}
class _WikipediaArticlePageState extends State<WikipediaArticlePage> {
  late final WebViewController _controller = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..loadRequest(Uri.parse(widget.url));
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Википедия')), body: WebViewWidget(controller: _controller));
}

// Loads the live uCoin catalog inside the app. uCoin remains the source of truth;
// the app does not copy or cache catalog entries locally.
class UcoinCountryPage extends StatefulWidget {
  final String country;
  const UcoinCountryPage({super.key, required this.country});

  @override
  State<UcoinCountryPage> createState() => _UcoinCountryPageState();
}

class _UcoinCountryPageState extends State<UcoinCountryPage> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _failed = false;

  static const Map<String, String> _slugs = {
    'Австрия': 'austria', 'Албания': 'albania', 'Андорра': 'andorra',
    'Беларусь': 'belarus', 'Бельгия': 'belgium', 'Болгария': 'bulgaria',
    'Босния и Герцеговина': 'bosnia_and_herzegovina', 'Ватикан': 'vatican',
    'Великобритания': 'united_kingdom', 'Венгрия': 'hungary', 'Германия': 'germany',
    'Греция': 'greece', 'Дания': 'denmark', 'Ирландия': 'ireland',
    'Исландия': 'iceland', 'Испания': 'spain', 'Италия': 'italy', 'Кипр': 'cyprus',
    'Косово': 'kosovo', 'Латвия': 'latvia', 'Литва': 'lithuania',
    'Лихтенштейн': 'liechtenstein', 'Люксембург': 'luxembourg', 'Мальта': 'malta',
    'Молдова': 'moldova', 'Монако': 'monaco', 'Нидерланды': 'netherlands',
    'Норвегия': 'norway', 'Польша': 'poland', 'Португалия': 'portugal',
    'Россия': 'russia', 'Румыния': 'romania', 'Сан-Марино': 'san_marino',
    'Северная Македония': 'north_macedonia', 'Сербия': 'serbia',
    'Словакия': 'slovakia', 'Словения': 'slovenia', 'Турция': 'turkey',
    'Украина': 'ukraine', 'Финляндия': 'finland', 'Франция': 'france',
    'Хорватия': 'croatia', 'Черногория': 'montenegro', 'Чехия': 'czech_republic',
    'Швейцария': 'switzerland', 'Швеция': 'sweden', 'Эстония': 'estonia',
  };

  @override
  void initState() {
    super.initState();
    final slug = _slugs[widget.country];
    final uri = slug == null
        ? Uri.https('ru.ucoin.net', '/catalog/', {'country': widget.country})
        : Uri.https('ru.ucoin.net', '/catalog/', {'country': slug});
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; _failed = false; }); },
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() { _loading = false; _failed = true; });
          }
        },
      ))
      ..loadRequest(uri);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.country),
      actions: [IconButton(tooltip: 'Обновить', icon: const Icon(Icons.refresh), onPressed: () => _controller.reload())],
    ),
    body: Stack(children: [
      WebViewWidget(controller: _controller),
      if (_loading) const LinearProgressIndicator(),
      if (_failed) Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off, size: 48),
          const SizedBox(height: 12),
          const Text('Не удалось загрузить каталог uCoin. Проверьте интернет и попробуйте снова.', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh), label: const Text('Повторить')),
        ]),
      )),
    ]),
  );
}
