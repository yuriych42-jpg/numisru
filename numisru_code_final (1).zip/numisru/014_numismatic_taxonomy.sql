-- NumisRU v1.8: справочник периодов, правителей, монетных дворов и типов.
-- Выполнять после 013_multi_source_catalog.sql.

create table if not exists public.numis_period_groups (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name_ru text not null,
  start_year int,
  end_year int,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.numis_rulers (
  id uuid primary key default gen_random_uuid(),
  period_group_id uuid references public.numis_period_groups(id) on delete set null,
  name_ru text not null,
  start_year int,
  end_year int,
  title_ru text,
  notes_ru text,
  created_at timestamptz not null default now()
);

create table if not exists public.catalog_item_rulers (
  catalog_item_id uuid not null references public.catalog_items(id) on delete cascade,
  ruler_id uuid not null references public.numis_rulers(id) on delete cascade,
  primary key (catalog_item_id, ruler_id)
);

alter table public.catalog_items
  add column if not exists mint_mark_id uuid references public.mint_marks(id);

alter table public.catalog_items
  add column if not exists period_group_id uuid references public.numis_period_groups(id);

create index if not exists idx_catalog_items_mint_mark on public.catalog_items(mint_mark_id);
create index if not exists idx_catalog_items_period_group on public.catalog_items(period_group_id);
create index if not exists idx_catalog_item_rulers_ruler on public.catalog_item_rulers(ruler_id);

alter table public.numis_period_groups enable row level security;
alter table public.numis_rulers enable row level security;
alter table public.catalog_item_rulers enable row level security;

grant select on public.numis_period_groups to authenticated;
grant select on public.numis_rulers to authenticated;
grant select on public.catalog_item_rulers to authenticated;

drop policy if exists "taxonomy groups readable" on public.numis_period_groups;
create policy "taxonomy groups readable" on public.numis_period_groups
  for select to authenticated using (true);

drop policy if exists "taxonomy rulers readable" on public.numis_rulers;
create policy "taxonomy rulers readable" on public.numis_rulers
  for select to authenticated using (true);

drop policy if exists "catalog item rulers readable" on public.catalog_item_rulers;
create policy "catalog item rulers readable" on public.catalog_item_rulers
  for select to authenticated using (true);

-- Единая функция для фильтрации каталога по историческому периоду,
-- правителю и монетному двору. Все параметры необязательные.
create or replace function public.search_catalog_taxonomy(
  p_period_group_id uuid default null,
  p_ruler_id uuid default null,
  p_mint_mark_id uuid default null,
  p_year_from int default null,
  p_year_to int default null,
  p_limit int default 100
)
returns table (
  id uuid,
  official_name_ru text,
  catalog_number text,
  year int,
  period_group text,
  ruler_name text,
  mint_mark text
)
language sql
stable
security invoker
as $$
  select distinct
    ci.id,
    ci.official_name_ru,
    ci.catalog_number,
    ci.year,
    pg.name_ru,
    r.name_ru,
    mm.name_ru
  from public.catalog_items ci
  left join public.numis_period_groups pg on pg.id = ci.period_group_id
  left join public.catalog_item_rulers cir on cir.catalog_item_id = ci.id
  left join public.numis_rulers r on r.id = cir.ruler_id
  left join public.mint_marks mm on mm.id = ci.mint_mark_id
  where ci.item_kind = 'coin'
    and (p_period_group_id is null or ci.period_group_id = p_period_group_id)
    and (p_ruler_id is null or cir.ruler_id = p_ruler_id)
    and (p_mint_mark_id is null or ci.mint_mark_id = p_mint_mark_id)
    and (p_year_from is null or ci.year >= p_year_from)
    and (p_year_to is null or ci.year <= p_year_to)
  order by ci.year desc nulls last, ci.official_name_ru
  limit greatest(1, least(coalesce(p_limit, 100), 500));
$$;

grant execute on function public.search_catalog_taxonomy(uuid, uuid, uuid, int, int, int) to authenticated;

-- Заполняем только нейтральные крупные группы. Конкретных правителей и
-- исторические соответствия добавляем отдельными проверенными импортами.
insert into public.numis_period_groups(code, name_ru, start_year, end_year, sort_order)
values
  ('imperial_russia', 'Российская империя', null, 1917, 10),
  ('rsfsr', 'РСФСР', 1917, 1922, 20),
  ('ussr', 'СССР', 1922, 1991, 30),
  ('modern_russia', 'Российская Федерация', 1992, null, 40)
on conflict (code) do update set name_ru = excluded.name_ru,
  start_year = excluded.start_year,
  end_year = excluded.end_year,
  sort_order = excluded.sort_order;
