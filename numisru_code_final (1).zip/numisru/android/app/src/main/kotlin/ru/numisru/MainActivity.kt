package ru.numisru
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
