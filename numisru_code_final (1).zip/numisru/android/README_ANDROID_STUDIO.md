# NumisRU — Android Studio

1. Установите Flutter SDK и Android Studio с Android SDK.
2. Откройте папку проекта `numisru` в Android Studio.
3. Убедитесь, что Flutter plugin установлен.
4. В `android/local.properties` укажите путь к Flutter SDK, например:
   `flutter.sdk=/PATH/TO/flutter`
5. Запустите `flutter pub get`.
6. Для запуска задайте параметры:
   `flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY`
7. APK:
   `flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY`

Не помещайте service_role/secret key в приложение.
