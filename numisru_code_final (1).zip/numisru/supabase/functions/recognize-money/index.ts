import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type'};
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok',{headers:cors});
  try {
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('Нет авторизации');
    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {global:{headers:{Authorization:auth}}});
    const {data:{user}} = await supabase.auth.getUser(); if (!user) throw new Error('Нет пользователя');
    const body = await req.json(); const mode = body.mode ?? 'auto';
    const signed = async (path:string|null) => path ? (await supabase.storage.from('collection-photos').createSignedUrl(path,900)).data?.signedUrl : null;
    const front = await signed(body.front_path ?? null), back = await signed(body.back_path ?? null);
    const prompt = `Ты нумизматический классификатор. Определи объект на фото: российская монета или банкнота. Режим: ${mode}. Верни ТОЛЬКО JSON: {"item_kind":"coin|banknote","country":string,"issuer":string,"denomination":string,"year":number|null,"modification_year":number|null,"metal":string|null,"catalog_number":string|null,"confidence":number,"notes":string}. Не утверждай подлинность. Если данных недостаточно, снижай confidence.`;
    const key=Deno.env.get('OPENAI_API_KEY'); if(!key) throw new Error('OPENAI_API_KEY не настроен');
    const content:any[]=[{type:'input_text',text:prompt}]; if(front) content.push({type:'input_image',image_url:front}); if(back) content.push({type:'input_image',image_url:back});
    const oa=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-5.6-luna',input:[{role:'user',content}]} )});
    if(!oa.ok) throw new Error(`OpenAI ${oa.status}: ${await oa.text()}`); const od=await oa.json();
    const text=od.output?.flatMap((x:any)=>x.content??[]).find((x:any)=>x.type==='output_text')?.text ?? '{}';
    const clean=text.replace(/^```json\s*/,'').replace(/\s*```$/,''); const identified=JSON.parse(clean);
    let candidates:any[]=[];
    if(identified.item_kind==='banknote'){
      const {data,error}=await supabase.rpc('match_banknote_candidates',{p_denomination:identified.denomination,p_year:identified.year,p_modification_year:identified.modification_year,p_catalog_number:identified.catalog_number,p_name:identified.denomination}); if(error) throw error; candidates=data??[];
    } else {
      const {data,error}=await supabase.rpc('match_recognition_candidates',{p_country:identified.country,p_issuer:identified.issuer,p_denomination:identified.denomination,p_year:identified.year,p_metal:identified.metal,p_catalog_number:identified.catalog_number,p_name:identified.denomination}); if(error) throw error; candidates=data??[];
    }
    return new Response(JSON.stringify({identified,candidates}),{headers:{...cors,'Content-Type':'application/json'}});
  } catch(e){return new Response(JSON.stringify({error:String(e)}),{status:400,headers:{...cors,'Content-Type':'application/json'}});}
});
