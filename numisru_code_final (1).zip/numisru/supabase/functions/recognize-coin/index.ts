import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const openaiKey = Deno.env.get('OPENAI_API_KEY')!;
    const admin = createClient(supabaseUrl, serviceKey);
    const auth = req.headers.get('Authorization');
    if (!auth) throw new Error('Authorization required');
    const token = auth.replace('Bearer ', '');
    const { data: { user } } = await admin.auth.getUser(token);
    if (!user) throw new Error('Invalid session');

    const body = await req.json();
    const attemptId = body.attempt_id as string;
    const obversePath = body.obverse_path as string | undefined;
    const reversePath = body.reverse_path as string | undefined;
    if (!attemptId || (!obversePath && !reversePath)) throw new Error('Photo is required');

    await admin.from('recognition_attempts').update({ status: 'processing' }).eq('id', attemptId).eq('user_id', user.id);

    const imageInputs: any[] = [];
    for (const path of [obversePath, reversePath]) {
      if (!path) continue;
      if (!path.startsWith(`${user.id}/`)) throw new Error('Invalid storage path');
      const { data, error } = await admin.storage.from('collection-photos').createSignedUrl(path, 600);
      if (error || !data?.signedUrl) throw new Error('Cannot create image URL');
      imageInputs.push({ type: 'input_image', image_url: data.signedUrl });
    }

    const prompt = `Ты профессиональный нумизмат. Определи монету по фотографиям. Не выдумывай точные данные, если их нельзя увидеть. Верни только JSON без markdown:\n{\n  "country":"", "issuer":"", "denomination":"", "year": null, "catalog_number":"", "metal":"", "confidence":0.0, "notes":"", "search_terms":[]\n}\nЕсли это российская памятная/инвестиционная монета Банка России, постарайся определить каталожный номер. Confidence 0..1.`;
    const content = [{ type: 'input_text', text: prompt }, ...imageInputs];
    const aiRes = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${openaiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'gpt-5.6-luna', input: [{ role: 'user', content }] })
    });
    if (!aiRes.ok) throw new Error(`Vision service error ${aiRes.status}`);
    const ai = await aiRes.json();
    const text = ai.output_text ?? '';
    const match = text.match(/\{[\s\S]*\}/);
    const identified = match ? JSON.parse(match[0]) : { notes: text, confidence: 0 };

    const { data: candidates, error: matchError } = await admin.rpc('match_recognition_candidates', {
      p_catalog_number: identified.catalog_number || null,
      p_year: identified.year || null,
      p_denomination: identified.denomination || null,
      p_metal: identified.metal || null,
      p_country: identified.country || null,
      p_issuer: identified.issuer || null,
    });
    if (matchError) throw new Error(`Catalog matching error: ${matchError.message}`);

    const result = { identified, candidates: candidates ?? [] };
    await admin.from('recognition_attempts').update({ status: 'completed', result_json: result, completed_at: new Date().toISOString() }).eq('id', attemptId).eq('user_id', user.id);
    return new Response(JSON.stringify(result), { headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch (e) {
    console.error(e);
    return new Response(JSON.stringify({ error: String(e) }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
});
