-- NumisRU v2.2: official Bank of Russia banknote media.
-- Adds external CBR image metadata without mirroring copyrighted images by default.

alter table public.catalog_item_photos
  add column if not exists alt_text_ru text;

create index if not exists catalog_item_photos_source_idx
  on public.catalog_item_photos(catalog_item_id, photo_type, sort_order);

-- Keep official media as external references by default. storage_path is a
-- logical placeholder because the base schema requires it to be non-null.
-- The importer can optionally mirror files into Supabase Storage after the
-- license/usage terms are reviewed.

create or replace function public.banknote_media(p_catalog_item_id uuid)
returns table (
  id uuid, photo_type public.photo_type, source_url text,
  storage_path text, alt_text_ru text, sort_order int, is_primary boolean
)
language sql stable security definer set search_path = public
as $$
  select p.id, p.photo_type, p.source_url, p.storage_path, p.alt_text_ru,
         p.sort_order, p.is_primary
  from public.catalog_item_photos p
  join public.catalog_items ci on ci.id = p.catalog_item_id
  where p.catalog_item_id = p_catalog_item_id
    and ci.item_kind = 'banknote'
  order by p.sort_order, p.photo_type::text;
$$;
grant execute on function public.banknote_media(uuid) to authenticated;
