-- NumisRU v1.0: attempts and results of coin recognition.
create table if not exists public.recognition_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  obverse_storage_path text,
  reverse_storage_path text,
  status text not null default 'pending' check (status in ('pending','processing','completed','failed')),
  result_json jsonb,
  error_text text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

alter table public.recognition_attempts enable row level security;
grant select, insert, update on public.recognition_attempts to authenticated;

create policy "recognition own select" on public.recognition_attempts
for select to authenticated using (user_id = auth.uid());
create policy "recognition own insert" on public.recognition_attempts
for insert to authenticated with check (user_id = auth.uid());
create policy "recognition own update" on public.recognition_attempts
for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
