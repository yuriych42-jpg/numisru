#!/usr/bin/env python3
"""Import official Bank of Russia banknote images and authenticity features.

The script scrapes the official CBR banknote pages, matches each year tab to a
catalog item by source_external_id (e.g. 100R-2026), and produces SQL that
stores the official image URLs and feature descriptions. By default it does
NOT download/mirror images. This keeps the catalog lightweight and lets the
operator review CBR usage terms before copying media into Storage.

Usage:
  python cbr_banknote_media_importer.py --output 017_cbr_banknote_media_generated.sql
  python cbr_banknote_media_importer.py --dry-run

Requires: requests, beautifulsoup4
"""
from __future__ import annotations
import argparse, html, re, time
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

BASE = 'https://www.cbr.ru/cash_circulation/banknotes/'
DENOMS = [5, 10, 50, 100, 200, 500, 1000, 2000, 5000]
HEADERS = {'User-Agent': 'NumisRU official catalog importer/2.2'}


def norm(s: str | None) -> str:
    return re.sub(r'\\s+', ' ', html.unescape(s or '')).strip()


def parse_year(href: str, text: str) -> int | None:
    m = re.search(r'(?:19|20)\\d{2}', href + ' ' + text)
    return int(m.group()) if m else None


def control_method(label: str) -> str:
    s = label.lower()
    if 'просвет' in s: return 'light'
    if 'луп' in s: return 'magnifier'
    if 'угл' in s: return 'angle'
    if 'ощуп' in s or 'рельеф' in s: return 'touch'
    if 'ультрафиолет' in s or 'ув-' in s: return 'uv'
    if 'ик-' in s or 'ик-диапазон' in s: return 'ir'
    return 'other'


def fetch(url: str) -> BeautifulSoup:
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return BeautifulSoup(r.text, 'html.parser')


def page_for(denom: int) -> str:
    return urljoin(BASE, f'{denom}rub/')


def collect_page(denom: int):
    url = page_for(denom)
    soup = fetch(url)
    tabs = []
    # CBR uses links containing year tabs. The current page may also have
    # query parameters such as ?tab.current=y2026.
    for a in soup.find_all('a', href=True):
        y = parse_year(a['href'], a.get_text(' ', strip=True))
        if y and y not in [x[0] for x in tabs]:
            tabs.append((y, urljoin(url, a['href'])))
    # Fallback: current page only.
    if not tabs:
        tabs = [(None, url)]

    out = []
    for year, tab_url in tabs:
        try:
            ps = fetch(tab_url)
        except Exception as e:
            print(f'WARN {tab_url}: {e}')
            continue
        current_year = year
        title = norm(ps.find('h2').get_text(' ', strip=True)) if ps.find('h2') else ''
        if not current_year:
            current_year = parse_year('', title)
        if not current_year:
            current_year = parse_year(tab_url, '')
        if not current_year:
            continue
        ext = f'{denom}R-{current_year}'
        images = []
        seen = set()
        for img in ps.find_all('img', src=True):
            src = urljoin(tab_url, img['src'])
            if 'cbr.ru' not in src or src in seen:
                continue
            seen.add(src)
            alt = norm(img.get('alt'))
            images.append((src, alt))
        # The first two banknote images on the CBR page are normally obverse
        # and reverse. Additional images are authenticity close-ups.
        media = []
        if images:
            media.append(('obverse', images[0]))
        if len(images) > 1:
            media.append(('reverse', images[1]))
        # Authenticity features: use headings following the feature section.
        features = []
        current_method = 'other'
        for node in ps.find_all(['h3','h4','h5','p']):
            txt = norm(node.get_text(' ', strip=True))
            if not txt:
                continue
            cm = control_method(txt)
            if txt.startswith('Признаки подлинности, контролируемые') or txt in ('Для незрячих и слабовидящих людей',):
                current_method = cm
                continue
            # Feature names tend to be heading elements. Their following text
            # is captured until the next heading.
            if node.name in ('h3','h4','h5') and len(txt) < 180:
                desc = ''
                nxt = node.find_next_sibling()
                if nxt:
                    desc = norm(nxt.get_text(' ', strip=True))
                if desc:
                    features.append((current_method, txt, desc, url))
        out.append((ext, tab_url, media, features))
        time.sleep(0.2)
    return out


def sqlq(s: str | None) -> str:
    if s is None: return 'null'
    return "'" + s.replace("'", "''") + "'"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='017_cbr_banknote_media_generated.sql')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    rows = []
    for d in DENOMS:
        try:
            rows.extend(collect_page(d))
        except Exception as e:
            print(f'WARN denomination {d}: {e}')

    print(f'Collected {len(rows)} banknote year pages')
    if args.dry_run:
        for ext, url, media, features in rows:
            print(ext, url, 'images=', len(media), 'features=', len(features))
        return

    lines = [
        '-- Generated by cbr_banknote_media_importer.py',
        '-- Official source: Bank of Russia banknote catalogue.',
        'begin;'
    ]
    for ext, page_url, media, features in rows:
        for ptype, (img_url, alt) in media:
            lines.append(f"""insert into public.catalog_item_photos(catalog_item_id,storage_path,photo_type,sort_order,is_primary,source_url,alt_text_ru)
select ci.id, {sqlq('external/cbr/banknotes/' + ext + '/' + ptype + '.jpg')}, {sqlq(ptype)}::public.photo_type,
       {10 if ptype == 'obverse' else 20}, {str(ptype == 'obverse').lower()}, {sqlq(img_url)}, {sqlq(alt or ext + ' ' + ptype)}
from public.catalog_items ci
join public.catalog_sources cs on cs.id=ci.source_id
where cs.code='cbr_ru_banknotes' and ci.source_external_id={sqlq(ext)}
and not exists (select 1 from public.catalog_item_photos p where p.catalog_item_id=ci.id and p.photo_type={sqlq(ptype)}::public.photo_type and p.source_url={sqlq(img_url)});""")
        for idx, (method, name, desc, src) in enumerate(features, start=100):
            lines.append(f"""insert into public.banknote_security_features(catalog_item_id,control_method,name_ru,description_ru,is_primary,sort_order,source_url)
select ci.id,{sqlq(method)},{sqlq(name)},{sqlq(desc)},false,{idx},{sqlq(src)}
from public.catalog_items ci join public.catalog_sources cs on cs.id=ci.source_id
where cs.code='cbr_ru_banknotes' and ci.source_external_id={sqlq(ext)}
and not exists (select 1 from public.banknote_security_features f where f.catalog_item_id=ci.id and f.name_ru={sqlq(name)});""")
    lines.append('commit;')
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    print('Wrote', args.output)

if __name__ == '__main__':
    main()
