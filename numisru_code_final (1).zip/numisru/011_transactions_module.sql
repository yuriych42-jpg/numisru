-- NumisRU v1.5 — transactions / deals module
-- Run after 010_price_history_and_portfolio.sql.

alter table public.transactions
  add column if not exists collection_item_id uuid,
  add column if not exists transaction_type text,
  add column if not exists transaction_date date default current_date,
  add column if not exists quantity integer default 1,
  add column if not exists unit_price numeric(14,2),
  add column if not exists total_price numeric(14,2),
  add column if not exists counterparty text,
  add column if not exists notes text;

-- If the base schema already has these columns, these statements are harmless.
create index if not exists idx_transactions_user_date
  on public.transactions(user_id, transaction_date desc);
create index if not exists idx_transactions_item_date
  on public.transactions(collection_item_id, transaction_date desc);

alter table public.transactions enable row level security;

grant select, insert, update, delete on public.transactions to authenticated;

drop policy if exists "transactions_select_own" on public.transactions;
drop policy if exists "transactions_insert_own" on public.transactions;
drop policy if exists "transactions_update_own" on public.transactions;
drop policy if exists "transactions_delete_own" on public.transactions;

create policy "transactions_select_own"
on public.transactions for select to authenticated
using (user_id = auth.uid());

create policy "transactions_insert_own"
on public.transactions for insert to authenticated
with check (user_id = auth.uid());

create policy "transactions_update_own"
on public.transactions for update to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

create policy "transactions_delete_own"
on public.transactions for delete to authenticated
using (user_id = auth.uid());

-- Summary for the current anonymous/authenticated user.
create or replace function public.transaction_summary()
returns table(
  purchase_total numeric,
  sale_total numeric,
  exchange_count bigint,
  transaction_count bigint,
  realized_profit numeric
)
language sql
security invoker
set search_path = public
as $$
  select
    coalesce(sum(case when transaction_type = 'purchase' then coalesce(total_price,0) else 0 end),0),
    coalesce(sum(case when transaction_type = 'sale' then coalesce(total_price,0) else 0 end),0),
    count(*) filter (where transaction_type = 'exchange'),
    count(*),
    coalesce(sum(case when transaction_type = 'sale' then coalesce(total_price,0) else 0 end),0)
      - coalesce(sum(case when transaction_type = 'purchase' then coalesce(total_price,0) else 0 end),0)
  from public.transactions
  where user_id = auth.uid();
$$;

grant execute on function public.transaction_summary() to authenticated;
