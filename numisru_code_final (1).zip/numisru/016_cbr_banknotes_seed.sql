-- NumisRU v2.1: initial official Bank of Russia banknote catalog seed.
-- Source: Bank of Russia banknotes catalogue. Run after 015_banknotes.sql.

alter table public.catalog_items
  add column if not exists denomination_text_ru text;

update public.catalog_sources
set base_url = 'https://www.cbr.ru/cash_circulation/banknotes/'
where code = 'cbr_ru_banknotes';

-- Helper: create/update a banknote catalog item. The seed intentionally keeps
-- uncertain historical details empty rather than inventing numismatic data.
do $$
declare
  src uuid;
  r record;
  item_id uuid;
begin
  select id into src from public.catalog_sources where code='cbr_ru_banknotes';
  if src is null then raise exception 'cbr_ru_banknotes source is missing'; end if;

  for r in select * from (values
    ('5R-1997','5 ₽',1997,null,137,61,'хлопковая бумага','зелёный','2 буквы + 7 цифр','Монумент «Тысячелетие России» и Софийский собор в Великом Новгороде','Крепостная стена Новгородского кремля','https://www.cbr.ru/cash_circulation/banknotes/5rub/'),
    ('10R-1997','10 ₽',1997,null,150,65,'хлопковая бумага','жёлто-коричневый',null,'Красноярская часовня Параскевы Пятницы','Красноярская ГЭС','https://www.cbr.ru/cash_circulation/banknotes/10rub/'),
    ('10R-2001','10 ₽',2001,2001,150,65,'хлопковая бумага','жёлто-коричневый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/10rub/'),
    ('10R-2004','10 ₽',2004,2004,150,65,'хлопковая бумага','жёлто-коричневый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/10rub/'),
    ('50R-1997','50 ₽',1997,null,150,65,'хлопковая бумага','сине-зелёный',null,'Скульптура на фоне Петропавловской крепости','Ростральные колонны','https://www.cbr.ru/cash_circulation/banknotes/50rub/'),
    ('50R-2001','50 ₽',2001,2001,150,65,'хлопковая бумага','сине-зелёный',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/50rub/'),
    ('50R-2004','50 ₽',2004,2004,150,65,'хлопковая бумага','сине-зелёный',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/50rub/'),
    ('100R-1997','100 ₽',1997,null,150,65,'хлопковая бумага','красно-коричневый',null,'Квадрига на портике Большого театра','Большой театр','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2001','100 ₽',2001,2001,150,65,'хлопковая бумага','красно-коричневый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2004','100 ₽',2004,2004,150,65,'хлопковая бумага','красно-коричневый','2 буквы + 7 цифр',null,null,'https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2014','100 ₽',2014,2014,150,65,'хлопковая бумага','красный',null,'Севастополь','Херсонес Таврический','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2015','100 ₽',2015,2015,150,65,'хлопковая бумага','красный',null,'Крым','Ласточкино гнездо','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2018','100 ₽',2018,2018,150,65,'хлопковая бумага','красный',null,'Чемпионат мира по футболу 2018','Футбол','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2022','100 ₽',2022,2022,150,65,'хлопковая бумага','оливковый, оранжевый','2 буквы + 9 цифр','Спасская башня Московского Кремля','Ржевский мемориал Советскому Солдату','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('100R-2026','100 ₽',2026,2026,150,65,'хлопковая бумага','оливковый, оранжевый','2 буквы + 9 цифр','Спасская башня Московского Кремля','Карта Центрального федерального округа','https://www.cbr.ru/cash_circulation/banknotes/100rub/'),
    ('200R-2017','200 ₽',2017,2017,150,65,'хлопковая бумага','зелёный', '2 буквы + 9 цифр','Памятник затопленным кораблям','Херсонес Таврический','https://www.cbr.ru/cash_circulation/banknotes/200rub/'),
    ('500R-1997','500 ₽',1997,null,150,65,'хлопковая бумага','сине-фиолетовый',null,'Памятник Петру I','Соловецкий монастырь','https://www.cbr.ru/cash_circulation/banknotes/500rub/'),
    ('500R-2001','500 ₽',2001,2001,150,65,'хлопковая бумага','сине-фиолетовый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/500rub/'),
    ('500R-2004','500 ₽',2004,2004,150,65,'хлопковая бумага','сине-фиолетовый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/500rub/'),
    ('500R-2010','500 ₽',2010,2010,150,65,'хлопковая бумага','сине-фиолетовый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/500rub/'),
    ('1000R-1997','1000 ₽',1997,null,157,69,'хлопковая бумага','зелёный',null,'Памятник Ярославу Мудрому','Церковь Иоанна Предтечи в Ярославле','https://www.cbr.ru/cash_circulation/banknotes/1000rub/'),
    ('1000R-2004','1000 ₽',2004,2004,157,69,'хлопковая бумага','зелёный',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/1000rub/'),
    ('1000R-2010','1000 ₽',2010,2010,157,69,'хлопковая бумага','зелёный',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/1000rub/'),
    ('1000R-2025','1000 ₽',2025,2025,157,69,'хлопковая бумага','зелёный, бирюзовый', '2 буквы + 9 цифр','Нижегородский кремль','Нижегородская ярмарка','https://www.cbr.ru/cash_circulation/banknotes/1000rub/'),
    ('2000R-2017','2000 ₽',2017,2017,157,69,'хлопковая бумага','синий', '2 буквы + 9 цифр','Русский мост во Владивостоке','Космодром Восточный','https://www.cbr.ru/cash_circulation/banknotes/2000rub/'),
    ('5000R-1997','5000 ₽',1997,null,157,69,'хлопковая бумага','красно-коричневый',null,'Памятник Н. Н. Муравьёву-Амурскому','Амурский мост','https://www.cbr.ru/cash_circulation/banknotes/5000rub/'),
    ('5000R-2010','5000 ₽',2010,2010,157,69,'хлопковая бумага','красно-коричневый',null,null,null,'https://www.cbr.ru/cash_circulation/banknotes/5000rub/'),
    ('5000R-2023','5000 ₽',2023,2023,157,69,'хлопковая бумага','красно-коричневый', '2 буквы + 9 цифр','Памятник Н. Н. Муравьёву-Амурскому','Амурский мост','https://www.cbr.ru/cash_circulation/banknotes/5000rub/')
  ) as v(ext_id,denom,yr,modyr,w,h,material,colors,serial,front_desc,back_desc,url)
  loop
    insert into public.catalog_items(
      source_id,source_external_id,item_kind,year,official_name_ru,
      denomination_text_ru,banknote_modification_year,banknote_size_width_mm,
      banknote_size_height_mm,banknote_material,banknote_colors,
      banknote_serial_format,banknote_front_description_ru,banknote_back_description_ru,
      official_url,source_updated_at
    ) values (
      src,r.ext_id,'banknote'::public.item_kind,r.yr,
      'Банкнота Банка России номиналом '||r.denom||' выпуска '||r.yr||' года',
      r.denom,r.modyr,r.w,r.h,r.material,r.colors,r.serial,r.front_desc,r.back_desc,
      r.url,now()
    )
    on conflict (source_id,source_external_id) do update set
      year=excluded.year,official_name_ru=excluded.official_name_ru,
      denomination_text_ru=excluded.denomination_text_ru,
      banknote_modification_year=excluded.banknote_modification_year,
      banknote_size_width_mm=excluded.banknote_size_width_mm,
      banknote_size_height_mm=excluded.banknote_size_height_mm,
      banknote_material=excluded.banknote_material,banknote_colors=excluded.banknote_colors,
      banknote_serial_format=excluded.banknote_serial_format,
      banknote_front_description_ru=excluded.banknote_front_description_ru,
      banknote_back_description_ru=excluded.banknote_back_description_ru,
      official_url=excluded.official_url,source_updated_at=excluded.source_updated_at
    returning id into item_id;

    -- Add a compact set of official-source authenticity guidance for the
    -- denominations where the CBR page exposes the feature explicitly.
    if r.ext_id in ('5R-1997','100R-2026','1000R-2025','2000R-2017','5000R-2023') then
      insert into public.banknote_security_features(catalog_item_id,control_method,name_ru,description_ru,is_primary,sort_order,source_url)
      select item_id,'light','Проверка на просвет','Водяные знаки и защитная нить проверяются при просмотре банкноты на просвет согласно официальному описанию Банка России.',true,10,r.url
      where not exists (select 1 from public.banknote_security_features f where f.catalog_item_id=item_id and f.name_ru='Проверка на просвет');
      insert into public.banknote_security_features(catalog_item_id,control_method,name_ru,description_ru,is_primary,sort_order,source_url)
      select item_id,'touch','Рельефные элементы','Часть защитных элементов определяется на ощупь; конкретный набор зависит от выпуска.',false,20,r.url
      where not exists (select 1 from public.banknote_security_features f where f.catalog_item_id=item_id and f.name_ru='Рельефные элементы');
    end if;
  end loop;
end $$;

-- The 2026 100-ruble note entered circulation on 10 July 2026.
update public.catalog_items
set issue_date='2026-07-10'
where source_external_id='100R-2026' and source_id=(select id from public.catalog_sources where code='cbr_ru_banknotes');
