-- NumisRU v1.7: multi-source Russian numismatic catalog foundation
-- Run after 012_import_export.sql (if present).

alter table public.catalog_sources
  add column if not exists scope_code text,
  add column if not exists authority_level text default 'community',
  add column if not exists license_note text,
  add column if not exists is_active boolean not null default true;

create index if not exists idx_catalog_sources_scope
  on public.catalog_sources(scope_code);

-- Official Bank of Russia source remains the authoritative source for its own
-- commemorative/investment issues. These additional source records are
-- intentionally empty: they are namespaces for licensed/verified datasets,
-- not fabricated catalog entries.
insert into public.catalog_sources(code, name_ru, base_url, scope_code, authority_level, license_note, is_active)
values
  ('cbr_ru_coins', 'Банк России — памятные и инвестиционные монеты', 'https://www.cbr.ru/cash_circulation/memorable_coins/coins_base/', 'rf_1992_present', 'official', 'Официальные данные Банка России; условия использования проверять перед зеркалированием изображений.', true),
  ('ussr_verified', 'СССР — проверенный нумизматический источник', null, 'ussr', 'verified', 'Источник должен быть подключён отдельным лицензированным импортом.', false),
  ('rsfsr_verified', 'РСФСР — проверенный нумизматический источник', null, 'rsfsr', 'verified', 'Источник должен быть подключён отдельным лицензированным импортом.', false),
  ('imperial_russia_verified', 'Российская империя — проверенный нумизматический источник', null, 'imperial_russia', 'verified', 'Источник должен быть подключён отдельным лицензированным импортом.', false)
on conflict (code) do update set
  name_ru = excluded.name_ru,
  base_url = excluded.base_url,
  scope_code = excluded.scope_code,
  authority_level = excluded.authority_level,
  license_note = excluded.license_note,
  is_active = excluded.is_active;

-- Server-side helper for catalog scope discovery.
create or replace function public.catalog_source_scopes()
returns table (
  code text,
  name_ru text,
  scope_code text,
  authority_level text,
  item_count bigint
)
language sql
stable
security invoker
as $$
  select
    s.code,
    s.name_ru,
    s.scope_code,
    s.authority_level,
    count(ci.id)::bigint as item_count
  from public.catalog_sources s
  left join public.catalog_items ci on ci.source_id = s.id
  where s.is_active = true
  group by s.id, s.code, s.name_ru, s.scope_code, s.authority_level
  order by s.name_ru;
$$;

grant execute on function public.catalog_source_scopes() to authenticated;
