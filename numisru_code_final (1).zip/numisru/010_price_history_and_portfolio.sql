-- NumisRU v1.4: price history and portfolio statistics
create table if not exists public.collection_item_value_snapshots (
  id uuid primary key default gen_random_uuid(),
  collection_item_id uuid not null references public.collection_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  value numeric(14,2) not null,
  source text not null default 'estimate',
  captured_at timestamptz not null default now()
);

create index if not exists idx_value_snapshots_item_date
  on public.collection_item_value_snapshots(collection_item_id, captured_at desc);
create index if not exists idx_value_snapshots_user_date
  on public.collection_item_value_snapshots(user_id, captured_at desc);

alter table public.collection_item_value_snapshots enable row level security;
grant select, insert, update, delete on public.collection_item_value_snapshots to authenticated;

drop policy if exists "value snapshots own select" on public.collection_item_value_snapshots;
create policy "value snapshots own select" on public.collection_item_value_snapshots
  for select to authenticated using (user_id = auth.uid());
drop policy if exists "value snapshots own insert" on public.collection_item_value_snapshots;
create policy "value snapshots own insert" on public.collection_item_value_snapshots
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "value snapshots own update" on public.collection_item_value_snapshots;
create policy "value snapshots own update" on public.collection_item_value_snapshots
  for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "value snapshots own delete" on public.collection_item_value_snapshots;
create policy "value snapshots own delete" on public.collection_item_value_snapshots
  for delete to authenticated using (user_id = auth.uid());

create or replace function public.portfolio_summary()
returns table (
  item_count bigint,
  piece_count bigint,
  purchase_total numeric,
  current_total numeric,
  gain_total numeric,
  gain_percent numeric
)
language sql
security invoker
as $$
  with x as (
    select
      count(*)::bigint item_count,
      coalesce(sum(coalesce(quantity,1)),0)::bigint piece_count,
      coalesce(sum(coalesce(purchase_price,0)),0)::numeric purchase_total,
      coalesce(sum(coalesce(current_value,0)),0)::numeric current_total
    from public.collection_items
    where user_id = auth.uid()
      and coalesce(status, 'owned') not in ('sold','exchanged','lost')
  )
  select item_count, piece_count, purchase_total, current_total,
         current_total - purchase_total,
         case when purchase_total > 0 then ((current_total - purchase_total) / purchase_total) * 100 else null end
  from x;
$$;

grant execute on function public.portfolio_summary() to authenticated;

create or replace function public.record_current_value_snapshot(p_collection_item_id uuid)
returns public.collection_item_value_snapshots
language plpgsql
security invoker
as $$
declare r public.collection_item_value_snapshots;
begin
  insert into public.collection_item_value_snapshots(collection_item_id,user_id,value,source)
  select id, auth.uid(), coalesce(current_value,0), 'estimate'
  from public.collection_items
  where id = p_collection_item_id and user_id = auth.uid()
  returning * into r;
  return r;
end;
$$;

grant execute on function public.record_current_value_snapshot(uuid) to authenticated;
