-- NumisRU v0.6
-- Anonymous Auth + RLS for Wishlist/Profile.
-- Enable Anonymous Sign-Ins in Supabase Dashboard:
-- Authentication -> Providers -> Anonymous Sign-Ins.

alter table public.profiles enable row level security;
grant select, insert, update on public.profiles to authenticated;
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

grant select, insert, update, delete on public.wishlists to authenticated;
grant select, insert, update, delete on public.wishlist_items to authenticated;
alter table public.wishlists enable row level security;
alter table public.wishlist_items enable row level security;

drop policy if exists "wishlists_own" on public.wishlists;
create policy "wishlists_own" on public.wishlists for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "wishlist_items_own" on public.wishlist_items;
create policy "wishlist_items_own" on public.wishlist_items for all to authenticated
using (exists (select 1 from public.wishlists w where w.id = wishlist_id and w.user_id = auth.uid()))
with check (exists (select 1 from public.wishlists w where w.id = wishlist_id and w.user_id = auth.uid()));
