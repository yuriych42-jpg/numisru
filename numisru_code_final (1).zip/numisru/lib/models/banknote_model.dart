class BanknoteItem {
  final String id;
  final String? name;
  final String? denomination;
  final int? year;
  final int? modificationYear;
  final String? catalogNumber;
  final String? sourceCode;
  final String? sourceName;
  final double? width;
  final double? height;
  final String? material;
  final String? colors;
  final String? serialFormat;
  final String? photoUrl;

  const BanknoteItem({required this.id, this.name, this.denomination, this.year, this.modificationYear, this.catalogNumber, this.sourceCode, this.sourceName, this.width, this.height, this.material, this.colors, this.serialFormat, this.photoUrl});
  factory BanknoteItem.fromMap(Map<String,dynamic> m) => BanknoteItem(
    id: m['id'].toString(), name: m['official_name_ru'] as String?, denomination: m['denomination_text_ru'] as String?,
    year: (m['year'] as num?)?.toInt(), modificationYear: (m['banknote_modification_year'] as num?)?.toInt(),
    catalogNumber: m['catalog_number'] as String?, sourceCode: m['source_code'] as String?, sourceName: m['source_name_ru'] as String?,
    width: (m['banknote_size_width_mm'] as num?)?.toDouble(), height: (m['banknote_size_height_mm'] as num?)?.toDouble(),
    material: m['banknote_material'] as String?, colors: m['banknote_colors'] as String?, serialFormat: m['banknote_serial_format'] as String?, photoUrl: m['photo_url'] as String?,
  );
}
