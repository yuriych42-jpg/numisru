class CatalogItem {
  final String id;
  final String? name;
  final String? catalogNumber;
  final int? year;
  final String? denomination;
  final String? metal;
  final double? weight;
  final double? diameter;
  final int? mintage;
  final String? photoUrl;
  final String? sourceCode;
  final String? sourceName;

  const CatalogItem({
    required this.id,
    this.name,
    this.catalogNumber,
    this.year,
    this.denomination,
    this.metal,
    this.weight,
    this.diameter,
    this.mintage,
    this.photoUrl,
    this.sourceCode,
    this.sourceName,
  });

  factory CatalogItem.fromMap(Map<String, dynamic> map) {
    return CatalogItem(
      id: map['id'].toString(),
      name: map['official_name_ru'] as String?,
      catalogNumber: map['catalog_number'] as String?,
      year: (map['year'] as num?)?.toInt(),
      denomination: map['denomination_text_ru'] as String?,
      metal: map['metal_text_ru'] as String?,
      weight: (map['weight_g'] as num?)?.toDouble(),
      diameter: (map['diameter_mm'] as num?)?.toDouble(),
      mintage: (map['mintage'] as num?)?.toInt(),
      photoUrl: map['photo_url'] as String?,
      sourceCode: (map['source'] is Map) ? map['source']['code'] as String? : null,
      sourceName: (map['source'] is Map) ? map['source']['name_ru'] as String? : null,
    );
  }
}
