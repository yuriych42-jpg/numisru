import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/catalog_item.dart';

class CatalogRepository {
  final SupabaseClient client;

  CatalogRepository(this.client);

  Future<List<CatalogItem>> search({
    String query = '',
    int? year,
    String? sourceCode,
    int limit = 50,
  }) async {
    dynamic request = client
        .from('catalog_items')
        .select('''
          id,
          official_name_ru,
          catalog_number,
          year,
          denomination_text_ru,
          metal_text_ru,
          weight_g,
          diameter_mm,
          mintage,
          source:catalog_sources(code,name_ru)
        ''')
        .eq('item_kind', 'coin');

    if (query.trim().isNotEmpty) {
      final q = query.trim().replaceAll(',', ' ');
      request = request.or(
        'official_name_ru.ilike.%$q%,catalog_number.ilike.%$q%',
      );
    }

    if (year != null) {
      request = request.eq('year', year);
    }

    if (sourceCode != null && sourceCode.isNotEmpty) {
      request = request.eq('catalog_sources.code', sourceCode);
    }

    final rows = await request
        .order('year', ascending: false)
        .order('official_name_ru')
        .limit(limit);

    return (rows as List)
        .map((row) => CatalogItem.fromMap(Map<String, dynamic>.from(row)))
        .toList();
  }
}
