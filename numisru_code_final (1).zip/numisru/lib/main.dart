import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/unified_recognition_page.dart';
import 'pages/banknote_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/stats_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const _ConfigErrorApp());
    return;
  }
  await Supabase.initialize(url: url, publishableKey: key);
  await _ensureAnonymousSession();
  runApp(const NumisRuApp());
}

Future<void> _ensureAnonymousSession() async {
  final auth = Supabase.instance.client.auth;
  if (auth.currentSession == null) {
    await auth.signInAnonymously();
  }
}

class _ConfigErrorApp extends StatelessWidget {
  const _ConfigErrorApp();
  @override
  Widget build(BuildContext context) => const MaterialApp(
        home: Scaffold(
          body: Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Не заданы SUPABASE_URL и SUPABASE_PUBLISHABLE_KEY.'),
            ),
          ),
        ),
      );
}

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NumisRU',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF263238)),
          useMaterial3: true,
          cardTheme: const CardThemeData(
            margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          ),
        ),
        home: const HomeShell(),
      );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [
    CatalogPage(),
    CollectionPage(),
    WishlistPage(),
    PortfolioPage(),
    ProfilePage(),
  ];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Wishlist'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _index, children: _pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: _destinations,
        ),
      );
}
