import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CoinRecognitionPage extends StatefulWidget {
  const CoinRecognitionPage({super.key});
  @override State<CoinRecognitionPage> createState() => _CoinRecognitionPageState();
}

class _CoinRecognitionPageState extends State<CoinRecognitionPage> {
  final _picker = ImagePicker();
  File? _obverse, _reverse;
  bool _busy = false;
  Map<String, dynamic>? _result;
  String? _error;
  String? _addedCatalogId;

  Future<File?> _pick(ImageSource source) async {
    final x = await _picker.pickImage(source: source, imageQuality: 90, maxWidth: 2400);
    return x == null ? null : File(x.path);
  }

  Future<void> _choose(bool obverse) async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (c) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(leading: const Icon(Icons.camera_alt), title: const Text('Камера'), onTap: () => Navigator.pop(c, ImageSource.camera)),
        ListTile(leading: const Icon(Icons.photo_library), title: const Text('Галерея'), onTap: () => Navigator.pop(c, ImageSource.gallery)),
      ])),
    );
    if (source == null) return;
    final f = await _pick(source);
    if (f != null) setState(() => obverse ? _obverse = f : _reverse = f);
  }

  Future<void> _recognize() async {
    if (_obverse == null && _reverse == null) return;
    setState(() { _busy = true; _error = null; _result = null; _addedCatalogId = null; });
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser!;
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      Future<String?> upload(File? f, String side) async {
        if (f == null) return null;
        final path = '${user.id}/recognition/$id-$side.jpg';
        await client.storage.from('collection-photos').upload(path, f, fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true));
        return path;
      }
      final op = await upload(_obverse, 'obverse');
      final rp = await upload(_reverse, 'reverse');
      final ins = await client.from('recognition_attempts').insert({'user_id': user.id, 'obverse_storage_path': op, 'reverse_storage_path': rp}).select('id').single();
      final res = await client.functions.invoke('recognize-coin', body: {'attempt_id': ins['id'], 'obverse_path': op, 'reverse_path': rp});
      if (res.data is Map && (res.data['error'] != null)) throw Exception(res.data['error']);
      setState(() => _result = Map<String, dynamic>.from(res.data as Map));
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _addCandidate(Map<String, dynamic> candidate) async {
    final catalogId = candidate['id']?.toString();
    if (catalogId == null || catalogId.isEmpty) return;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _ConfirmAddSheet(candidate: candidate),
    );
    if (ok != true) return;
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) throw Exception('Нет локальной сессии');
      final created = await client.from('collection_items').insert({
        'user_id': user.id,
        'catalog_item_id': catalogId,
        'condition_code': 'VF',
        'quantity': 1,
        'status': 'owned',
      }).select('id').single();
      setState(() => _addedCatalogId = catalogId);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Монета добавлена в коллекцию (экземпляр ${created['id']})')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось добавить: $e')));
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Определить монету')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Сфотографируйте аверс и реверс. Приложение сопоставит результат с каталогом NumisRU.', style: TextStyle(fontSize: 16)),
      const SizedBox(height: 16),
      Row(children: [Expanded(child: _photoCard('Аверс', _obverse, true)), const SizedBox(width: 12), Expanded(child: _photoCard('Реверс', _reverse, false))]),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: _busy ? null : _recognize, icon: _busy ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Icon(Icons.auto_awesome), label: Text(_busy ? 'Определяем…' : 'Определить монету')),
      if (_error != null) ...[const SizedBox(height: 16), Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error))))],
      if (_result != null) _resultCard(_result!),
    ]),
  );

  Widget _photoCard(String title, File? file, bool obverse) => Card(child: InkWell(onTap: () => _choose(obverse), borderRadius: BorderRadius.circular(12), child: SizedBox(height: 190, child: file == null ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.add_a_photo_outlined, size: 40), const SizedBox(height: 8), Text(title)]) : ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(file, fit: BoxFit.cover)))));

  Widget _resultCard(Map<String,dynamic> r) {
    final i = Map<String,dynamic>.from(r['identified'] ?? {});
    final candidates = (r['candidates'] as List? ?? []).map((e) => Map<String,dynamic>.from(e as Map)).toList();
    return Card(margin: const EdgeInsets.only(top: 20), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Результат', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      Text('${i['country'] ?? ''} ${i['denomination'] ?? ''}'.trim(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      if (i['year'] != null) Text('Год: ${i['year']}'),
      if ((i['metal'] ?? '').toString().isNotEmpty) Text('Металл: ${i['metal']}'),
      Text('Уверенность: ${(((i['confidence'] ?? 0) as num) * 100).round()}%'),
      if ((i['catalog_number'] ?? '').toString().isNotEmpty) Text('Каталожный №: ${i['catalog_number']}'),
      if ((i['notes'] ?? '').toString().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(i['notes'].toString())),
      if (candidates.isNotEmpty) ...[
        const Divider(height: 28),
        const Text('Совпадения каталога', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...candidates.take(5).map(_candidateTile),
      ],
    ])));
  }

  Widget _candidateTile(Map<String,dynamic> c) {
    final id = c['id']?.toString();
    final added = id != null && id == _addedCatalogId;
    return Card(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(c['official_name_ru']?.toString() ?? 'Без названия', style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('${c['year'] ?? '—'} • ${c['catalog_number'] ?? 'без номера'}'),
          if (c['match_score'] != null) ...[
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: LinearProgressIndicator(value: ((c['match_score'] as num).toDouble().clamp(0, 100)) / 100)),
              const SizedBox(width: 8),
              Text('${(c['match_score'] as num).round()}%'),
            ]),
          ],
          if ((c['match_reasons'] as List?)?.isNotEmpty == true)
            Padding(padding: const EdgeInsets.only(top: 6), child: Text((c['match_reasons'] as List).join(' • '), style: Theme.of(context).textTheme.bodySmall)),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            onPressed: added ? null : () => _addCandidate(c),
            icon: Icon(added ? Icons.check : Icons.add),
            label: Text(added ? 'Уже добавлено' : 'Это моя монета'),
          )),
        ]),
      ),
    );
  }
}

class _ConfirmAddSheet extends StatefulWidget {
  final Map<String, dynamic> candidate;
  const _ConfirmAddSheet({required this.candidate});
  @override State<_ConfirmAddSheet> createState() => _ConfirmAddSheetState();
}

class _ConfirmAddSheetState extends State<_ConfirmAddSheet> {
  String condition = 'VF';
  final quantity = TextEditingController(text: '1');
  final price = TextEditingController();
  bool saving = false;

  @override void dispose() { quantity.dispose(); price.dispose(); super.dispose(); }

  Future<void> save() async {
    final q = int.tryParse(quantity.text) ?? 1;
    if (q < 1) return;
    final p = double.tryParse(price.text.replaceAll(',', '.'));
    setState(() => saving = true);
    try {
      final user = Supabase.instance.client.auth.currentUser!;
      await Supabase.instance.client.from('collection_items').insert({
        'user_id': user.id,
        'catalog_item_id': widget.candidate['id'].toString(),
        'condition_code': condition,
        'quantity': q,
        'purchase_price': p,
        'status': 'owned',
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e')));
      }
    }
  }

  @override Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.only(left: 16, right: 16, top: 8, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Добавить в коллекцию', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 8),
      Text(widget.candidate['official_name_ru']?.toString() ?? 'Монета'),
      Text('${widget.candidate['year'] ?? '—'} • ${widget.candidate['catalog_number'] ?? 'без номера'}'),
      const SizedBox(height: 16),
      DropdownButtonFormField<String>(value: condition, decoration: const InputDecoration(labelText: 'Состояние'), items: const ['PR','G','VG','F','VF','XF','AU','UNC','BU','PROOF'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: saving ? null : (v) => setState(() => condition = v ?? 'VF')),
      const SizedBox(height: 12),
      TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Количество')),
      const SizedBox(height: 12),
      TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Цена покупки, ₽ (необязательно)')),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.check), label: Text(saving ? 'Сохраняем…' : 'Добавить'))),
    ]),
  );
}
