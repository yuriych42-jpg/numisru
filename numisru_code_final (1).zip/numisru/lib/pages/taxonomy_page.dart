import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TaxonomyPage extends StatefulWidget {
  const TaxonomyPage({super.key});
  @override
  State<TaxonomyPage> createState() => _TaxonomyPageState();
}

class _TaxonomyPageState extends State<TaxonomyPage> {
  final client = Supabase.instance.client;
  String? periodId;
  String? rulerId;
  String? mintId;
  int? yearFrom;
  int? yearTo;
  bool loading = true;
  List<Map<String, dynamic>> periods = [];
  List<Map<String, dynamic>> rulers = [];
  List<Map<String, dynamic>> mints = [];
  List<Map<String, dynamic>> results = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final data = await Future.wait([
        client.from('numis_period_groups').select().order('sort_order'),
        client.from('numis_rulers').select().order('start_year'),
        client.from('mint_marks').select('id,name_ru,code').order('name_ru'),
        client.rpc('search_catalog_taxonomy', params: {
          'p_period_group_id': periodId,
          'p_ruler_id': rulerId,
          'p_mint_mark_id': mintId,
          'p_year_from': yearFrom,
          'p_year_to': yearTo,
          'p_limit': 100,
        }),
      ]);
      if (!mounted) return;
      setState(() {
        periods = List<Map<String, dynamic>>.from(data[0] as List);
        rulers = List<Map<String, dynamic>>.from(data[1] as List);
        mints = List<Map<String, dynamic>>.from(data[2] as List);
        results = List<Map<String, dynamic>>.from(data[3] as List);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e')));
    }
  }

  Future<void> _apply() async {
    setState(() => loading = true);
    try {
      final data = await client.rpc('search_catalog_taxonomy', params: {
        'p_period_group_id': periodId,
        'p_ruler_id': rulerId,
        'p_mint_mark_id': mintId,
        'p_year_from': yearFrom,
        'p_year_to': yearTo,
        'p_limit': 100,
      });
      if (mounted) setState(() { results = List<Map<String, dynamic>>.from(data as List); loading = false; });
    } catch (e) {
      if (mounted) { setState(() => loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка фильтра: $e'))); }
    }
  }

  Widget _drop(String label, String? value, List<Map<String, dynamic>> items, String valueKey, String labelKey, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      isExpanded: true,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      items: [
        const DropdownMenuItem(value: null, child: Text('Все')),
        ...items.map((x) => DropdownMenuItem(value: x[valueKey]?.toString(), child: Text(x[labelKey]?.toString() ?? ''))),
      ],
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Справочник')),
      body: loading && results.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(12),
                children: [
                  Text('Периоды, правители и монетные дворы', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  _drop('Исторический период', periodId, periods, 'id', 'name_ru', (v) { periodId = v; _apply(); }),
                  const SizedBox(height: 10),
                  _drop('Правитель / эмитент', rulerId, rulers, 'id', 'name_ru', (v) { rulerId = v; _apply(); }),
                  const SizedBox(height: 10),
                  _drop('Монетный двор', mintId, mints, 'id', 'name_ru', (v) { mintId = v; _apply(); }),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: TextFormField(decoration: const InputDecoration(labelText: 'Год от', border: OutlineInputBorder()), keyboardType: TextInputType.number, onChanged: (v) => yearFrom = int.tryParse(v))),
                    const SizedBox(width: 10),
                    Expanded(child: TextFormField(decoration: const InputDecoration(labelText: 'Год до', border: OutlineInputBorder()), keyboardType: TextInputType.number, onChanged: (v) => yearTo = int.tryParse(v))),
                  ]),
                  const SizedBox(height: 10),
                  FilledButton.icon(onPressed: _apply, icon: const Icon(Icons.filter_alt), label: const Text('Применить фильтры')),
                  const SizedBox(height: 12),
                  Text('Найдено: ${results.length}'),
                  const SizedBox(height: 6),
                  ...results.map((x) => Card(child: ListTile(
                    title: Text(x['official_name_ru']?.toString() ?? 'Без названия'),
                    subtitle: Text([
                      if (x['year'] != null) x['year'].toString(),
                      if (x['catalog_number'] != null) '№ ${x['catalog_number']}',
                      if (x['period_group'] != null) x['period_group'].toString(),
                      if (x['ruler_name'] != null) x['ruler_name'].toString(),
                      if (x['mint_mark'] != null) 'МД: ${x['mint_mark']}',
                    ].join(' • ')),
                  )))
                ],
              ),
            ),
    );
  }
}
