import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PortfolioPage extends StatefulWidget {
  const PortfolioPage({super.key});
  @override State<PortfolioPage> createState() => _PortfolioPageState();
}

class _PortfolioPageState extends State<PortfolioPage> {
  final db = Supabase.instance.client;
  bool loading = true;
  Map<String,dynamic>? summary;
  List<Map<String,dynamic>> snapshots = [];

  @override void initState(){super.initState(); _load();}
  Future<void> _load() async {
    setState(()=>loading=true);
    try {
      final s = await db.rpc('portfolio_summary');
      final rows = await db.from('collection_item_value_snapshots').select('value,captured_at').order('captured_at');
      if(!mounted)return;
      setState((){
        summary = s is List && s.isNotEmpty ? Map<String,dynamic>.from(s.first) : null;
        snapshots = rows.map((e)=>Map<String,dynamic>.from(e)).toList();
        loading=false;
      });
    } catch(e){ if(mounted){setState(()=>loading=false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Не удалось загрузить портфель: $e')));}}
  }
  double n(String k)=> (summary?[k] as num?)?.toDouble() ?? 0;
  String money(double v)=> '${v.toStringAsFixed(0)} ₽';
  @override Widget build(BuildContext context){
    final gain=n('gain_total'); final pct=summary?['gain_percent'] as num?;
    return Scaffold(appBar:AppBar(title:const Text('Портфель'),actions:[IconButton(onPressed:_load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:_load,child:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,32),children:[
      Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[const Text('Текущая оценка'),const SizedBox(height:8),Text(money(n('current_total')),style:Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:6),Text('Покупки: ${money(n('purchase_total'))}'),const SizedBox(height:10),Chip(avatar:Icon(gain>=0?Icons.trending_up:Icons.trending_down,size:18),label:Text('${gain>=0?'+':''}${money(gain)}${pct==null?'':'  (${pct.toStringAsFixed(1)}%)'}'))]))),
      const SizedBox(height:12),
      Row(children:[Expanded(child:_metric('Позиции','${(summary?['item_count'] as num?)?.toInt()??0}')),Expanded(child:_metric('Экземпляры','${(summary?['piece_count'] as num?)?.toInt()??0}'))]),
      const SizedBox(height:12),
      Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('История оценок',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:16),SizedBox(height:180,child:_MiniChart(values:snapshots.map((e)=>(e['value'] as num?)?.toDouble()??0).toList()))]))),
      const SizedBox(height:12),
      const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Стоимость портфеля ориентировочная. Для редких монет итоговая цена может заметно зависеть от разновидности, состояния, подлинности и конкретного рынка.')))
    ])));
  }
  Widget _metric(String a,String b)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[Text(a),const SizedBox(height:6),Text(b,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold))])));
}

class _MiniChart extends StatelessWidget{
  final List<double> values; const _MiniChart({required this.values});
  @override Widget build(BuildContext context){if(values.length<2)return const Center(child:Text('Нужно минимум две оценки')); final min=values.reduce((a,b)=>a<b?a:b),max=values.reduce((a,b)=>a>b?a:b),range=(max-min)==0?1:max-min; return CustomPaint(painter:_ChartPainter(values,min,range),child:const SizedBox.expand());}
}
class _ChartPainter extends CustomPainter{
  final List<double> v; final double min,range; _ChartPainter(this.v,this.min,this.range);
  @override void paint(Canvas c,Size s){final p=Paint()..strokeWidth=3..style=PaintingStyle.stroke; final path=Path(); for(var i=0;i<v.length;i++){final x=s.width*i/(v.length-1),y=s.height-(v[i]-min)/range*s.height; i==0?path.moveTo(x,y):path.lineTo(x,y);} c.drawPath(path,p);}
  @override bool shouldRepaint(covariant _ChartPainter old)=>old.v!=v;
}
