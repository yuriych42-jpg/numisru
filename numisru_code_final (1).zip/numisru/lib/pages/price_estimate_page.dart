import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PriceEstimatePage extends StatefulWidget {
  final String collectionItemId;
  final String title;

  const PriceEstimatePage({super.key, required this.collectionItemId, required this.title});

  @override
  State<PriceEstimatePage> createState() => _PriceEstimatePageState();
}

class _PriceEstimatePageState extends State<PriceEstimatePage> {
  SupabaseClient get db => Supabase.instance.client;
  Map<String, dynamic>? result;
  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final data = await db.rpc('estimate_collection_item_value', params: {
        'p_collection_item_id': widget.collectionItemId,
      });
      if (mounted) {
        setState(() {
          result = data is List && data.isNotEmpty
              ? Map<String, dynamic>.from(data.first)
              : null;
          loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => loading = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось рассчитать стоимость: $e')));
      }
    }
  }

  double? _num(String key) => (result?[key] as num?)?.toDouble();
  String _money(double? value) => value == null ? '—' : '${value.toStringAsFixed(0)} ₽';

  Future<void> _saveEstimate() async {
    final value = _num('estimated_value');
    if (value == null) return;
    setState(() => saving = true);
    try {
      await db.from('collection_items').update({'current_value': value}).eq('id', widget.collectionItemId);
      await db.rpc('record_current_value_snapshot', params: {'p_collection_item_id': widget.collectionItemId});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Оценочная стоимость сохранена')));
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e')));
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final estimate = _num('estimated_value');
    final low = _num('low_value');
    final high = _num('high_value');
    final confidence = (_num('confidence') ?? 0) * 100;
    final samples = (result?['sample_count'] as num?)?.toInt() ?? 0;
    final method = result?['method']?.toString() ?? '';
    final manual = _num('manual_value');

    return Scaffold(
      appBar: AppBar(title: const Text('Оценка стоимости')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : result == null
              ? const Center(child: Text('Экземпляр не найден'))
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  children: [
                    Text(widget.title, style: Theme.of(context).textTheme.titleLarge),
                    const SizedBox(height: 20),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(children: [
                          const Text('Ориентировочная рыночная стоимость'),
                          const SizedBox(height: 8),
                          Text(_money(estimate), style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
                          if (low != null && high != null) ...[
                            const SizedBox(height: 8),
                            Text('Диапазон: ${_money(low)} — ${_money(high)}'),
                          ],
                          const SizedBox(height: 14),
                          LinearProgressIndicator(value: confidence.clamp(0, 100) / 100),
                          const SizedBox(height: 8),
                          Text('Уверенность: ${confidence.toStringAsFixed(0)}%'),
                        ]),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Card(
                      child: Column(children: [
                        ListTile(leading: const Icon(Icons.analytics_outlined), title: const Text('Метод'), subtitle: Text(method)),
                        ListTile(leading: const Icon(Icons.data_usage_outlined), title: const Text('Рыночных наблюдений'), trailing: Text('$samples')),
                        if (manual != null) ListTile(leading: const Icon(Icons.edit_note_outlined), title: const Text('Текущее значение в коллекции'), trailing: Text(_money(manual))),
                      ]),
                    ),
                    const SizedBox(height: 12),
                    const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Оценка не является гарантированной ценой продажи. Она строится по доступным рыночным данным и становится точнее по мере накопления источников и сделок.'))),
                    const SizedBox(height: 16),
                    FilledButton.icon(onPressed: estimate == null || saving ? null : _saveEstimate, icon: const Icon(Icons.save_outlined), label: Text(saving ? 'Сохранение…' : 'Сохранить как текущую стоимость')),
                  ],
                ),
    );
  }
}
