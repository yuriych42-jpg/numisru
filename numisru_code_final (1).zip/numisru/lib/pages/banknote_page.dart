import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/banknote_model.dart';
import 'banknote_detail_page.dart';

class BanknotePage extends StatefulWidget {
  const BanknotePage({super.key});
  @override
  State<BanknotePage> createState() => _BanknotePageState();
}

class _BanknotePageState extends State<BanknotePage> {
  final q = TextEditingController();
  int? year;
  String? denom;
  Future<List<dynamic>>? future;
  static const denoms = ['5', '10', '50', '100', '200', '500', '1000', '2000', '5000'];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    future = Supabase.instance.client.rpc('search_banknotes', params: {
      'p_query': q.text,
      'p_denomination': denom == null ? null : '$denom ₽',
      'p_year': year,
    });
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Банкноты')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SearchBar(
              controller: q,
              hintText: 'Название или каталожный номер',
              onSubmitted: (_) => _load(),
              trailing: [IconButton(onPressed: _load, icon: const Icon(Icons.search))],
            ),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                ChoiceChip(
                  label: const Text('Все номиналы'),
                  selected: denom == null,
                  onSelected: (_) {
                    setState(() => denom = null);
                    _load();
                  },
                ),
                ...denoms.map((d) => Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: ChoiceChip(
                        label: Text('$d ₽'),
                        selected: denom == d,
                        onSelected: (_) {
                          setState(() => denom = d);
                          _load();
                        },
                      ),
                    )),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Expanded(
            child: FutureBuilder<List<dynamic>>(
              future: future,
              builder: (c, s) {
                if (s.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (s.hasError) return Center(child: Text('Ошибка: ${s.error}'));
                final xs = (s.data ?? [])
                    .map((e) => BanknoteItem.fromMap(Map<String, dynamic>.from(e)))
                    .toList();
                if (xs.isEmpty) {
                  return const Center(child: Text('Банкноты пока не загружены в каталог'));
                }
                return ListView(
                  children: xs.map((x) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.payments_outlined),
                      title: Text(x.name ?? 'Банкнота'),
                      subtitle: Text('${x.denomination ?? ''} • ${x.year ?? '—'}${x.modificationYear != null ? ' • мод. ${x.modificationYear}' : ''}'),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => BanknoteDetailPage(item: x)),
                      ),
                    ),
                  )).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
