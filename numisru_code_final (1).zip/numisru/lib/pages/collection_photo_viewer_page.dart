import 'package:flutter/material.dart';

class CollectionPhotoViewerPage extends StatefulWidget {
  final List<Map<String, dynamic>> photos;
  final int initialIndex;
  final Future<String> Function(String path) signedUrl;
  final Future<void> Function(Map<String, dynamic> photo) onDelete;

  const CollectionPhotoViewerPage({super.key, required this.photos, required this.initialIndex, required this.signedUrl, required this.onDelete});

  @override
  State<CollectionPhotoViewerPage> createState() => _CollectionPhotoViewerPageState();
}

class _CollectionPhotoViewerPageState extends State<CollectionPhotoViewerPage> {
  late final PageController _pageController;
  late int _index;
  final Map<String, String> _urls = {};
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex.clamp(0, widget.photos.length - 1);
    _pageController = PageController(initialPage: _index);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  String _label(String type) => switch (type) {
        'obverse' => 'Аверс',
        'reverse' => 'Реверс',
        'edge' => 'Гурт',
        _ => 'Фото',
      };

  Future<String> _urlFor(Map<String, dynamic> photo) async {
    final path = photo['storage_path'].toString();
    final cached = _urls[path];
    if (cached != null) return cached;
    final url = await widget.signedUrl(path);
    _urls[path] = url;
    return url;
  }

  Future<void> _deleteCurrent() async {
    if (_deleting || widget.photos.isEmpty) return;
    final photo = widget.photos[_index];
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Удалить фотографию?'),
        content: Text('Удалить фото «${_label(photo['photo_type']?.toString() ?? '')}»?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Отмена')),
          FilledButton.tonal(onPressed: () => Navigator.pop(context, true), child: const Text('Удалить')),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() => _deleting = true);
    try {
      await widget.onDelete(photo);
      if (mounted) Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Text('${_label(widget.photos[_index]['photo_type']?.toString() ?? '')} • ${_index + 1}/${widget.photos.length}'),
        actions: [IconButton(tooltip: 'Удалить', onPressed: _deleting ? null : _deleteCurrent, icon: const Icon(Icons.delete_outline))],
      ),
      body: Stack(children: [
        PageView.builder(
          controller: _pageController,
          itemCount: widget.photos.length,
          onPageChanged: (index) => setState(() => _index = index),
          itemBuilder: (context, index) {
            final photo = widget.photos[index];
            return FutureBuilder<String>(
              future: _urlFor(photo),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
                if (snapshot.hasError || !snapshot.hasData) return const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white, size: 64));
                return InteractiveViewer(
                  minScale: 0.8,
                  maxScale: 5,
                  child: Center(child: Image.network(snapshot.data!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_outlined, color: Colors.white, size: 64))),
                );
              },
            );
          },
        ),
        if (_deleting) const Positioned.fill(child: ColoredBox(color: Color(0x66000000), child: Center(child: CircularProgressIndicator()))),
      ]),
    );
  }
}
