import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});

  Future<Map<String, dynamic>> _load() async {
    final supabase = Supabase.instance.client;
    final rows = await supabase.from('collection_items').select('quantity,purchase_price,condition_code').eq('user_id', supabase.auth.currentUser!.id);
    var pieces = 0;
    var spent = 0.0;
    final conditions = <String, int>{};
    for (final row in rows) {
      pieces += (row['quantity'] as num?)?.toInt() ?? 1;
      spent += (row['purchase_price'] as num?)?.toDouble() ?? 0;
      final c = (row['condition_code'] ?? '—').toString();
      conditions[c] = (conditions[c] ?? 0) + 1;
    }
    return {'items': rows.length, 'pieces': pieces, 'spent': spent, 'conditions': conditions};
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Статистика')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Ошибка: ${snapshot.error}'));
          final d = snapshot.data!;
          final conditions = (d['conditions'] as Map<String, int>);
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _StatCard(icon: Icons.collections_bookmark_outlined, title: 'Позиции', value: '${d['items']}'),
              _StatCard(icon: Icons.numbers, title: 'Экземпляры', value: '${d['pieces']}'),
              _StatCard(icon: Icons.payments_outlined, title: 'Потрачено', value: '${(d['spent'] as double).toStringAsFixed(2)} ₽'),
              const SizedBox(height: 8),
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Состояние', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8), ...conditions.entries.map((e) => ListTile(contentPadding: EdgeInsets.zero, title: Text(e.key), trailing: Text('${e.value}')))]))),
            ],
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon; final String title; final String value;
  const _StatCard({required this.icon, required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon), title: Text(title), trailing: Text(value, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))));
}
