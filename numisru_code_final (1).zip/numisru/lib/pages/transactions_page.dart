import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({super.key});
  @override State<TransactionsPage> createState()=>_TransactionsPageState();
}
class _TransactionsPageState extends State<TransactionsPage>{
  final db=Supabase.instance.client; bool loading=true; List<Map<String,dynamic>> rows=[]; Map<String,dynamic>? summary;
  @override void initState(){super.initState();load();}
  Future<void> load() async { setState(()=>loading=true); try { final data=await db.from('transactions').select('id,transaction_type,transaction_date,quantity,unit_price,total_price,counterparty,notes,collection_item_id').order('transaction_date',ascending:false); final s=await db.rpc('transaction_summary'); if(!mounted)return; setState(() { rows=(data as List).map((e)=>Map<String,dynamic>.from(e)).toList(); summary=s is List&&s.isNotEmpty?Map<String,dynamic>.from(s.first):null; loading=false; }); } catch(e){if(mounted){setState(()=>loading=false);ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Не удалось загрузить операции: $e')));}}}
  String type(String? v)=>switch(v){'purchase'=>'Покупка','sale'=>'Продажа','exchange'=>'Обмен','gift'=>'Подарок','found'=>'Найдена','inheritance'=>'Наследство',_=>'Другое'};
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Операции'),actions:[IconButton(onPressed:load,icon:const Icon(Icons.refresh))]),body:loading?const Center(child:CircularProgressIndicator()):RefreshIndicator(onRefresh:load,child:ListView(padding:const EdgeInsets.fromLTRB(12,12,12,32),children:[
    Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Expanded(child:_metric('Покупки','${(summary?['purchase_total'] as num?)?.toStringAsFixed(0)??'0'} ₽')),Expanded(child:_metric('Продажи','${(summary?['sale_total'] as num?)?.toStringAsFixed(0)??'0'} ₽')),Expanded(child:_metric('Операции','${(summary?['transaction_count'] as num?)?.toInt()??0}'))]))),
    const SizedBox(height:8),
    ...rows.map((r)=>Card(child:ListTile(leading:CircleAvatar(child:Icon(r['transaction_type']=='sale'?Icons.sell_outlined: r['transaction_type']=='purchase'?Icons.shopping_cart_outlined:Icons.swap_horiz)),title:Text(type(r['transaction_type']?.toString())),subtitle:Text('${r['transaction_date']??''} · ${r['quantity']??1} шт. · ${r['counterparty']??'без контрагента'}'),trailing:Text('${(r['total_price'] as num?)?.toStringAsFixed(0)??'0'} ₽',style:const TextStyle(fontWeight:FontWeight.bold))))),
    if(rows.isEmpty) const Padding(padding:EdgeInsets.all(32),child:Center(child:Text('Операций пока нет')))
  ])));
  Widget _metric(String a,String b)=>Column(children:[Text(a,style:const TextStyle(fontSize:12)),const SizedBox(height:4),Text(b,style:const TextStyle(fontWeight:FontWeight.bold))]);
}
