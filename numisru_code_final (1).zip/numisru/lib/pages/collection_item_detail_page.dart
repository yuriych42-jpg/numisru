import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'collection_item_edit_page.dart';
import 'collection_photo_viewer_page.dart';
import 'price_estimate_page.dart';
import 'transaction_add_page.dart';

class CollectionItemDetailPage extends StatefulWidget {
  final String collectionItemId;
  final String title;

  const CollectionItemDetailPage({
    super.key,
    required this.collectionItemId,
    required this.title,
  });

  @override
  State<CollectionItemDetailPage> createState() =>
      _CollectionItemDetailPageState();
}

class _CollectionItemDetailPageState extends State<CollectionItemDetailPage> {
  final _picker = ImagePicker();
  late Future<List<Map<String, dynamic>>> _future;
  late Future<Map<String, dynamic>> _itemFuture;
  bool _busy = false;

  SupabaseClient get _supabase => Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _future = _loadPhotos();
    _itemFuture = _loadItem();
  }

  Future<Map<String, dynamic>> _loadItem() async {
    final row = await _supabase.from('collection_items').select('inventory_number,condition_code,quantity,purchase_price,current_value,purchase_date,purchase_source,status,favorite,for_sale,for_exchange,storage_location_text,notes').eq('id', widget.collectionItemId).single();
    return Map<String, dynamic>.from(row);
  }

  Future<List<Map<String, dynamic>>> _loadPhotos() async {
    final rows = await _supabase
        .from('collection_item_photos')
        .select('id, storage_path, photo_type, sort_order, is_primary')
        .eq('collection_item_id', widget.collectionItemId)
        .order('sort_order');
    return (rows as List)
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  Future<String> _signedUrl(String path) {
    return _supabase.storage
        .from('collection-photos')
        .createSignedUrl(path, 60 * 60 * 24);
  }

  Future<void> _openPhotoViewer(List<Map<String, dynamic>> photos, Map<String, dynamic> selected) async {
    final index = photos.indexWhere((p) => p['id']?.toString() == selected['id']?.toString());
    if (index < 0) return;
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => CollectionPhotoViewerPage(
        photos: photos,
        initialIndex: index,
        signedUrl: _signedUrl,
        onDelete: _delete,
      ),
    ));
    if (mounted) setState(() => _future = _loadPhotos());
  }

  Future<void> _pickAndUpload(String photoType) async {
    if (_supabase.auth.currentUser == null) return;

    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Камера'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Галерея'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;

    final image = await _picker.pickImage(
      source: source,
      maxWidth: 2400,
      maxHeight: 2400,
      imageQuality: 92,
    );
    if (image == null) return;

    setState(() => _busy = true);
    try {
      final bytes = await image.readAsBytes();
      final ext = _extension(image.path);
      final userId = _supabase.auth.currentUser!.id;
      final path =
          '$userId/${widget.collectionItemId}/${photoType}_${DateTime.now().millisecondsSinceEpoch}.$ext';

      await _supabase.storage.from('collection-photos').uploadBinary(
            path,
            Uint8List.fromList(bytes),
            fileOptions: FileOptions(
              contentType: image.mimeType ?? 'image/jpeg',
              cacheControl: '3600',
              upsert: false,
            ),
          );

      final existing = await _supabase
          .from('collection_item_photos')
          .select('id')
          .eq('collection_item_id', widget.collectionItemId)
          .eq('photo_type', photoType)
          .order('sort_order');

      final sortOrder = (existing as List).length;
      await _supabase.from('collection_item_photos').insert({
        'collection_item_id': widget.collectionItemId,
        'storage_path': path,
        'photo_type': photoType,
        'sort_order': sortOrder,
        'is_primary': sortOrder == 0,
      });

      if (mounted) {
        setState(() => _future = _loadPhotos());
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Фото ${_label(photoType)} сохранено')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не удалось загрузить фото: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete(Map<String, dynamic> photo) async {
    final path = photo['storage_path']?.toString();
    final id = photo['id']?.toString();
    if (path == null || id == null) return;

    setState(() => _busy = true);
    try {
      await _supabase.storage.from('collection-photos').remove([path]);
      await _supabase
          .from('collection_item_photos')
          .delete()
          .eq('id', id);
      if (mounted) setState(() => _future = _loadPhotos());
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не удалось удалить фото: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _extension(String path) {
    final raw = path.split('.').last.toLowerCase();
    return const {'jpg', 'jpeg', 'png', 'webp', 'heic'}.contains(raw)
        ? raw
        : 'jpg';
  }

  String _label(String type) => switch (type) {
        'obverse' => 'аверса',
        'reverse' => 'реверса',
        'edge' => 'гурта',
        _ => 'экземпляра',
      };

  @override
  Widget build(BuildContext context) {
    final signedIn = _supabase.auth.currentUser != null;

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: !signedIn
          ? const Center(child: Text('Сначала войдите в аккаунт.'))
          : FutureBuilder<List<Map<String, dynamic>>>(
              future: _future,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(child: Text('Ошибка: ${snapshot.error}'));
                }

                final photos = snapshot.data ?? const [];
                return Stack(
                  children: [
                    ListView(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                      children: [
                        FutureBuilder<Map<String, dynamic>>(
                          future: _itemFuture,
                          builder: (context, itemSnapshot) {
                            final item = itemSnapshot.data;
                            if (item == null) return const SizedBox.shrink();
                            return Card(
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Row(children: [
                                    Expanded(child: Text('Данные экземпляра', style: Theme.of(context).textTheme.titleMedium)),
                                    IconButton(
                                      tooltip: 'Добавить операцию',
                                      onPressed: () async {
                                        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => TransactionAddPage(collectionItemId: widget.collectionItemId, title: widget.title)));
                                      },
                                      icon: const Icon(Icons.receipt_long_outlined),
                                    ),
                                    IconButton(
                                      tooltip: 'Оценить стоимость',
                                      onPressed: () async {
                                        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => PriceEstimatePage(collectionItemId: widget.collectionItemId, title: widget.title)));
                                        if (mounted) setState(() => _itemFuture = _loadItem());
                                      },
                                      icon: const Icon(Icons.price_check_outlined),
                                    ),
                                    IconButton(onPressed: () async {
                                      final result = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => CollectionItemEditPage(collectionItemId: widget.collectionItemId, title: widget.title)));
                                      if (!mounted) return;
                                      if (result == 'deleted') { Navigator.pop(context, true); } else if (result == true) { setState(() => _itemFuture = _loadItem()); }
                                    }, icon: const Icon(Icons.edit_outlined)),
                                  ]),
                                  Wrap(spacing: 8, runSpacing: 4, children: [
                                    if (item['condition_code'] != null) Chip(label: Text('${item['condition_code']}')),
                                    if (item['quantity'] != null) Chip(label: Text('Кол-во: ${item['quantity']}')),
                                    if (item['favorite'] == true) const Chip(avatar: Icon(Icons.star, size: 16), label: Text('Избранное')),
                                    if (item['for_sale'] == true) const Chip(label: Text('На продажу')),
                                    if (item['for_exchange'] == true) const Chip(label: Text('На обмен')),
                                  ]),
                                  const SizedBox(height: 8),
                                  if (item['purchase_price'] != null) Text('Покупка: ${item['purchase_price']} ₽'),
                                  if (item['current_value'] != null) Text('Текущая стоимость: ${item['current_value']} ₽'),
                                  if (item['purchase_source'] != null) Text('Источник: ${item['purchase_source']}'),
                                  if (item['storage_location_text'] != null) Text('Хранение: ${item['storage_location_text']}'),
                                  if (item['purchase_date'] != null) Text('Дата покупки: ${item['purchase_date']}'),
                                  if (item['notes'] != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Заметки: ${item['notes']}')),
                                ]),
                              ),
                            );
                          },
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Фотографии экземпляра',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'Храните собственные фото аверса, реверса и гурта. '
                          'Файлы находятся в приватном Storage.',
                        ),
                        const SizedBox(height: 16),
                        _PhotoSection(
                          title: 'Аверс',
                          type: 'obverse',
                          photos: photos,
                          onAdd: () => _pickAndUpload('obverse'),
                          onDelete: _delete,
                          signedUrl: _signedUrl,
                          onOpen: (photo) => _openPhotoViewer(photos, photo),
                        ),
                        const SizedBox(height: 16),
                        _PhotoSection(
                          title: 'Реверс',
                          type: 'reverse',
                          photos: photos,
                          onAdd: () => _pickAndUpload('reverse'),
                          onDelete: _delete,
                          signedUrl: _signedUrl,
                          onOpen: (photo) => _openPhotoViewer(photos, photo),
                        ),
                        const SizedBox(height: 16),
                        _PhotoSection(
                          title: 'Гурт',
                          type: 'edge',
                          photos: photos,
                          onAdd: () => _pickAndUpload('edge'),
                          onDelete: _delete,
                          signedUrl: _signedUrl,
                          onOpen: (photo) => _openPhotoViewer(photos, photo),
                        ),
                      ],
                    ),
                    if (_busy)
                      const Positioned.fill(
                        child: ColoredBox(
                          color: Color(0x33000000),
                          child: Center(child: CircularProgressIndicator()),
                        ),
                      ),
                  ],
                );
              },
            ),
    );
  }
}

class _PhotoSection extends StatelessWidget {
  final String title;
  final String type;
  final List<Map<String, dynamic>> photos;
  final VoidCallback onAdd;
  final Future<void> Function(Map<String, dynamic>) onDelete;
  final Future<String> Function(String) signedUrl;
  final void Function(Map<String, dynamic> photo) onOpen;

  const _PhotoSection({super.key, required this.title, required this.type, required this.photos, required this.onAdd, required this.onDelete, required this.signedUrl, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final filtered = photos.where((p) => p['photo_type']?.toString() == type).toList();
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const Spacer(),
            if (filtered.isNotEmpty) Text('${filtered.length}', style: Theme.of(context).textTheme.bodySmall),
            IconButton(tooltip: 'Добавить фото', onPressed: onAdd, icon: const Icon(Icons.add_a_photo_outlined)),
          ]),
          if (filtered.isEmpty)
            InkWell(
              onTap: onAdd,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                height: 150,
                width: double.infinity,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: Theme.of(context).colorScheme.outlineVariant)),
                child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo_outlined, size: 34), SizedBox(height: 8), Text('Добавить фотографию')]),
              ),
            )
          else
            SizedBox(
              height: 220,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: filtered.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, index) {
                  final photo = filtered[index];
                  return FutureBuilder<String>(
                    future: signedUrl(photo['storage_path'].toString()),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) return const SizedBox(width: 190, child: Center(child: CircularProgressIndicator()));
                      return GestureDetector(
                        onTap: () => onOpen(photo),
                        child: SizedBox(
                          width: 190,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Stack(fit: StackFit.expand, children: [
                              Hero(tag: 'collection-photo-${photo['id']}', child: Image.network(snapshot.data!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image_outlined)))),
                              Positioned(left: 8, bottom: 8, child: DecoratedBox(decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)), child: const Padding(padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.zoom_in, color: Colors.white, size: 16), SizedBox(width: 4), Text('Открыть', style: TextStyle(color: Colors.white))])))),
                            ]),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
        ]),
      ),
    );
  }
}
