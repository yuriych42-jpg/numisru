import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class TransactionAddPage extends StatefulWidget {
  final String collectionItemId;
  final String title;
  const TransactionAddPage({super.key, required this.collectionItemId, required this.title});
  @override State<TransactionAddPage> createState() => _TransactionAddPageState();
}

class _TransactionAddPageState extends State<TransactionAddPage> {
  final db = Supabase.instance.client;
  final quantity = TextEditingController(text: '1');
  final unitPrice = TextEditingController();
  final counterparty = TextEditingController();
  final notes = TextEditingController();
  String type = 'purchase';
  DateTime date = DateTime.now();
  bool saving = false;

  @override void dispose() { for (final c in [quantity, unitPrice, counterparty, notes]) { c.dispose(); } super.dispose(); }
  double? money(String s) => double.tryParse(s.trim().replaceAll(' ', '').replaceAll(',', '.'));

  Future<void> pickDate() async {
    final d = await showDatePicker(context: context, firstDate: DateTime(1800), lastDate: DateTime.now(), initialDate: date);
    if (d != null) setState(() => date = d);
  }

  Future<void> save() async {
    final q = int.tryParse(quantity.text.trim()) ?? 1;
    final price = money(unitPrice.text);
    if (q < 1) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Количество должно быть не меньше 1'))); return; }
    if (price == null || price < 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Укажите цену за единицу'))); return; }
    setState(() => saving = true);
    try {
      final total = q * price;
      await db.from('transactions').insert({
        'user_id': db.auth.currentUser!.id,
        'collection_item_id': widget.collectionItemId,
        'transaction_type': type,
        'transaction_date': '${date.year.toString().padLeft(4,'0')}-${date.month.toString().padLeft(2,'0')}-${date.day.toString().padLeft(2,'0')}',
        'quantity': q,
        'unit_price': price,
        'total_price': total,
        'counterparty': counterparty.text.trim().isEmpty ? null : counterparty.text.trim(),
        'notes': notes.text.trim().isEmpty ? null : notes.text.trim(),
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить сделку: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Новая операция')),
    body: ListView(padding: const EdgeInsets.fromLTRB(16,16,16,120), children: [
      Text(widget.title, style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 16),
      DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Тип операции', border: OutlineInputBorder()), items: const [
        DropdownMenuItem(value:'purchase',child:Text('Покупка')), DropdownMenuItem(value:'sale',child:Text('Продажа')), DropdownMenuItem(value:'exchange',child:Text('Обмен')), DropdownMenuItem(value:'gift',child:Text('Подарок')), DropdownMenuItem(value:'found',child:Text('Найдена')), DropdownMenuItem(value:'inheritance',child:Text('Наследство')), DropdownMenuItem(value:'other',child:Text('Другое')),
      ], onChanged:(v)=>setState(()=>type=v??type)), const SizedBox(height:12),
      ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event_outlined), title: Text('${date.day.toString().padLeft(2,'0')}.${date.month.toString().padLeft(2,'0')}.${date.year}'), subtitle: const Text('Дата операции'), onTap: pickDate),
      Row(children:[Expanded(child:TextField(controller:quantity,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Количество',border:OutlineInputBorder()))),const SizedBox(width:10),Expanded(child:TextField(controller:unitPrice,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Цена за единицу',suffixText:'₽',border:OutlineInputBorder())))]), const SizedBox(height:12),
      TextField(controller:counterparty,decoration:const InputDecoration(labelText:'Контрагент / продавец',prefixIcon:Icon(Icons.person_outline),border:OutlineInputBorder())), const SizedBox(height:12),
      TextField(controller:notes,maxLines:4,decoration:const InputDecoration(labelText:'Комментарий',alignLabelWithHint:true,border:OutlineInputBorder())),
    ]),
    bottomNavigationBar: SafeArea(minimum:const EdgeInsets.all(12),child:FilledButton.icon(onPressed:saving?null:save,icon:const Icon(Icons.save_outlined),label:Text(saving?'Сохранение…':'Сохранить'))),
  );
}
