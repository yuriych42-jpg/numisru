import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'collection_item_detail_page.dart';

class CollectionPage extends StatefulWidget {
  const CollectionPage({super.key});

  @override
  State<CollectionPage> createState() => _CollectionPageState();
}

enum _SortMode { newest, yearDesc, yearAsc, valueDesc, valueAsc, nameAsc }

class _CollectionPageState extends State<CollectionPage> {
  late Future<List<Map<String, dynamic>>> future;
  final search = TextEditingController();
  String? condition;
  String status = 'all';
  bool onlyForSale = false;
  bool onlyForExchange = false;
  int? year;
  _SortMode sortMode = _SortMode.newest;

  static const conditions = ['PR','G','VG','F','VF','XF','AU','UNC','BU','PROOF'];

  @override
  void initState() {
    super.initState();
    future = _load();
    search.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  Future<List<Map<String, dynamic>>> _load() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return [];
    final rows = await Supabase.instance.client.from('collection_items').select('''
      id, inventory_number, condition_code, quantity, purchase_price, current_value,
      status, favorite, for_sale, for_exchange, storage_location_text, created_at,
      catalog_items (id, official_name_ru, catalog_number, year, metal_text_ru, denomination_id)
    ''').eq('user_id', user.id).order('created_at', ascending: false);
    return (rows as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<void> _refresh() async {
    setState(() => future = _load());
    await future;
  }

  List<Map<String, dynamic>> _filtered(List<Map<String, dynamic>> input) {
    final q = search.text.trim().toLowerCase();
    final out = input.where((item) {
      final coin = Map<String, dynamic>.from((item['catalog_items'] as Map?) ?? const {});
      final name = '${coin['official_name_ru'] ?? ''} ${coin['catalog_number'] ?? ''} ${item['inventory_number'] ?? ''}'.toLowerCase();
      final itemYear = (coin['year'] as num?)?.toInt();
      return (q.isEmpty || name.contains(q)) &&
          (condition == null || item['condition_code'] == condition) &&
          (status == 'all' || item['status'] == status) &&
          (!onlyForSale || item['for_sale'] == true) &&
          (!onlyForExchange || item['for_exchange'] == true) &&
          (year == null || itemYear == year);
    }).toList();

    out.sort((a, b) {
      final ca = Map<String, dynamic>.from((a['catalog_items'] as Map?) ?? const {});
      final cb = Map<String, dynamic>.from((b['catalog_items'] as Map?) ?? const {});
      switch (sortMode) {
        case _SortMode.yearDesc:
          return ((cb['year'] as num?)?.toInt() ?? 0).compareTo((ca['year'] as num?)?.toInt() ?? 0);
        case _SortMode.yearAsc:
          return ((ca['year'] as num?)?.toInt() ?? 99999).compareTo((cb['year'] as num?)?.toInt() ?? 99999);
        case _SortMode.valueDesc:
          return ((b['current_value'] as num?)?.toDouble() ?? 0).compareTo((a['current_value'] as num?)?.toDouble() ?? 0);
        case _SortMode.valueAsc:
          return ((a['current_value'] as num?)?.toDouble() ?? double.maxFinite).compareTo((b['current_value'] as num?)?.toDouble() ?? double.maxFinite);
        case _SortMode.nameAsc:
          return (ca['official_name_ru'] ?? '').toString().compareTo((cb['official_name_ru'] ?? '').toString());
        case _SortMode.newest:
          return (b['created_at'] ?? '').toString().compareTo((a['created_at'] ?? '').toString());
      }
    });
    return out;
  }

  Future<void> _openFilters(List<Map<String, dynamic>> items) async {
    final years = items.map((e) {
      final coin = Map<String, dynamic>.from((e['catalog_items'] as Map?) ?? const {});
      return (coin['year'] as num?)?.toInt();
    }).whereType<int>().toSet().toList()..sort((a,b) => b.compareTo(a));

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(builder: (context, setSheetState) {
        return SafeArea(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
          child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Фильтры коллекции', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 18),
            DropdownButtonFormField<String?>(
              value: condition,
              decoration: const InputDecoration(labelText: 'Состояние', border: OutlineInputBorder()),
              items: [const DropdownMenuItem<String?>(value: null, child: Text('Любое')), ...conditions.map((v) => DropdownMenuItem<String?>(value: v, child: Text(v)))],
              onChanged: (v) { setSheetState(() => condition = v); setState(() {}); },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: status,
              decoration: const InputDecoration(labelText: 'Статус', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('Любой')),
                DropdownMenuItem(value: 'owned', child: Text('В коллекции')),
                DropdownMenuItem(value: 'reserved', child: Text('Зарезервировано')),
                DropdownMenuItem(value: 'sold', child: Text('Продано')),
                DropdownMenuItem(value: 'exchanged', child: Text('Обменяно')),
                DropdownMenuItem(value: 'lost', child: Text('Утеряно')),
              ],
              onChanged: (v) { setSheetState(() => status = v ?? 'all'); setState(() {}); },
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int?>(
              value: year,
              decoration: const InputDecoration(labelText: 'Год', border: OutlineInputBorder()),
              items: [const DropdownMenuItem<int?>(value: null, child: Text('Любой')), ...years.map((v) => DropdownMenuItem<int?>(value: v, child: Text('$v')))],
              onChanged: (v) { setSheetState(() => year = v); setState(() {}); },
            ),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Только на продажу'), value: onlyForSale, onChanged: (v) { setSheetState(() => onlyForSale = v); setState(() {}); }),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Только на обмен'), value: onlyForExchange, onChanged: (v) { setSheetState(() => onlyForExchange = v); setState(() {}); }),
            const SizedBox(height: 8),
            DropdownButtonFormField<_SortMode>(
              value: sortMode,
              decoration: const InputDecoration(labelText: 'Сортировка', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: _SortMode.newest, child: Text('Сначала добавленные')),
                DropdownMenuItem(value: _SortMode.yearDesc, child: Text('Год: сначала новые')),
                DropdownMenuItem(value: _SortMode.yearAsc, child: Text('Год: сначала старые')),
                DropdownMenuItem(value: _SortMode.valueDesc, child: Text('Стоимость: по убыванию')),
                DropdownMenuItem(value: _SortMode.valueAsc, child: Text('Стоимость: по возрастанию')),
                DropdownMenuItem(value: _SortMode.nameAsc, child: Text('Название: А—Я')),
              ],
              onChanged: (v) { setSheetState(() => sortMode = v ?? sortMode); setState(() {}); },
            ),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: OutlinedButton(onPressed: () { setState(() { condition = null; status = 'all'; year = null; onlyForSale = false; onlyForExchange = false; sortMode = _SortMode.newest; }); Navigator.pop(sheetContext); }, child: const Text('Сбросить'))),
              const SizedBox(width: 12),
              Expanded(child: FilledButton(onPressed: () => Navigator.pop(sheetContext), child: const Text('Готово'))),
            ]),
          ])),
        ));
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final signedIn = Supabase.instance.client.auth.currentUser != null;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Моя коллекция'),
        actions: [
          IconButton(onPressed: signedIn ? _refresh : null, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: !signedIn ? const Center(child: Text('Коллекция недоступна без локальной сессии.')) : FutureBuilder<List<Map<String, dynamic>>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('Ошибка: ${snapshot.error}'));
          final all = snapshot.data ?? [];
          final items = _filtered(all);
          final total = items.fold<int>(0, (sum, item) => sum + ((item['quantity'] as num?)?.toInt() ?? 0));
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: Row(children: [
                Expanded(child: SearchBar(controller: search, hintText: 'Поиск по названию, № каталога…', leading: const Icon(Icons.search), trailing: [
                  IconButton(onPressed: () => _openFilters(all), icon: Icon(Icons.tune, color: _hasFilters ? Theme.of(context).colorScheme.primary : null)),
                ])),
              ]),
            ),
            Padding(padding: const EdgeInsets.fromLTRB(16, 6, 16, 8), child: Row(children: [Expanded(child: Text('${items.length} позиций • $total экземпляров')), if (_hasFilters) TextButton(onPressed: _clearFilters, child: const Text('Сбросить'))])),
            if (items.isEmpty) const Expanded(child: _EmptyCollection()) else Expanded(child: ListView.builder(padding: const EdgeInsets.only(bottom: 24), itemCount: items.length, itemBuilder: (_, index) => _CollectionCard(item: items[index]))),
          ]);
        },
      ),
    );
  }

  bool get _hasFilters => search.text.trim().isNotEmpty || condition != null || status != 'all' || year != null || onlyForSale || onlyForExchange || sortMode != _SortMode.newest;

  void _clearFilters() {
    search.clear();
    setState(() { condition = null; status = 'all'; year = null; onlyForSale = false; onlyForExchange = false; sortMode = _SortMode.newest; });
  }
}

class _CollectionCard extends StatelessWidget {
  final Map<String, dynamic> item;
  const _CollectionCard({required this.item});
  @override
  Widget build(BuildContext context) {
    final coin = Map<String, dynamic>.from((item['catalog_items'] as Map?) ?? const {});
    final badges = <Widget>[];
    if (coin['year'] != null) badges.add(Chip(label: Text('${coin['year']}'), visualDensity: VisualDensity.compact));
    if (item['condition_code'] != null) badges.add(Chip(label: Text('${item['condition_code']}'), visualDensity: VisualDensity.compact));
    if (item['for_sale'] == true) badges.add(const Chip(label: Text('Продажа'), visualDensity: VisualDensity.compact));
    if (item['for_exchange'] == true) badges.add(const Chip(label: Text('Обмен'), visualDensity: VisualDensity.compact));
    return Card(child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CollectionItemDetailPage(collectionItemId: item['id'].toString(), title: (coin['official_name_ru'] ?? 'Экземпляр').toString()))),
      child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
        Container(width: 64, height: 64, decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.monetization_on_outlined, size: 32)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(coin['official_name_ru'] ?? 'Монета', maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Wrap(spacing: 5, runSpacing: 0, children: badges),
          Text('Количество: ${item['quantity'] ?? 1}${item['current_value'] != null ? ' • Оценка: ${item['current_value']} ₽' : ''}'),
          if (item['storage_location_text'] != null && item['storage_location_text'].toString().isNotEmpty) Text('Хранение: ${item['storage_location_text']}', style: Theme.of(context).textTheme.bodySmall),
        ])),
      ])),
    ));
  }
}

class _EmptyCollection extends StatelessWidget {
  const _EmptyCollection();
  @override
  Widget build(BuildContext context) => const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.search_off, size: 56), SizedBox(height: 12), Text('Ничего не найдено', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)), SizedBox(height: 6), Text('Измените поиск или сбросьте фильтры.', textAlign: TextAlign.center)])));
}
