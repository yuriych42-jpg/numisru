import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class WishlistPage extends StatefulWidget {
  const WishlistPage({super.key});

  @override
  State<WishlistPage> createState() => _WishlistPageState();
}

class _WishlistPageState extends State<WishlistPage> {
  Future<List<Map<String, dynamic>>> _load() async {
    final supabase = Supabase.instance.client;
    final lists = await supabase.from('wishlists').select('id,name').eq('user_id', supabase.auth.currentUser!.id).order('created_at');
    if (lists.isEmpty) return [];
    final result = <Map<String, dynamic>>[];
    for (final list in lists) {
      final items = await supabase.from('wishlist_items').select('id,target_price,target_currency,priority,catalog_items(official_name_ru,year,catalog_number)').eq('wishlist_id', list['id']);
      for (final item in items) {
        result.add({'list': list['name'], ...item});
      }
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wishlist')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _load(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Не удалось загрузить wishlist:\n${snapshot.error}')));
          final items = snapshot.data ?? [];
          if (items.isEmpty) return const Center(child: Text('Wishlist пока пуст'));
          return RefreshIndicator(
            onRefresh: () async => setState(() {}),
            child: ListView.builder(
              padding: const EdgeInsets.only(top: 8, bottom: 24),
              itemCount: items.length,
              itemBuilder: (_, i) {
                final item = items[i];
                final coin = (item['catalog_items'] as Map?)?.cast<String, dynamic>() ?? {};
                return Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.bookmark_border)), title: Text((coin['official_name_ru'] ?? 'Без названия').toString()), subtitle: Text('${coin['year'] ?? ''} • ${coin['catalog_number'] ?? ''}\n${item['list']}'), isThreeLine: true, trailing: item['target_price'] == null ? null : Text('${item['target_price']} ${item['target_currency'] ?? 'RUB'}')));
              },
            ),
          );
        },
      ),
    );
  }
}
