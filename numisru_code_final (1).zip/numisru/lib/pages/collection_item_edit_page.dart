import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CollectionItemEditPage extends StatefulWidget {
  final String collectionItemId;
  final String title;
  const CollectionItemEditPage({super.key, required this.collectionItemId, required this.title});
  @override
  State<CollectionItemEditPage> createState() => _CollectionItemEditPageState();
}

class _CollectionItemEditPageState extends State<CollectionItemEditPage> {
  final inventory = TextEditingController();
  final quantity = TextEditingController(text: '1');
  final purchasePrice = TextEditingController();
  final currentValue = TextEditingController();
  final purchaseSource = TextEditingController();
  final storage = TextEditingController();
  final notes = TextEditingController();
  final conditions = const ['PR','G','VG','F','VF','XF','AU','UNC','BU','PROOF'];
  String condition = 'VF';
  String status = 'owned';
  DateTime? purchaseDate;
  bool favorite = false;
  bool forSale = false;
  bool forExchange = false;
  bool loading = true;
  bool saving = false;

  SupabaseClient get db => Supabase.instance.client;

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { for (final c in [inventory,quantity,purchasePrice,currentValue,purchaseSource,storage,notes]) { c.dispose(); } super.dispose(); }

  Future<void> _load() async {
    try {
      final row = await db.from('collection_items').select('inventory_number,condition_code,quantity,purchase_price,current_value,purchase_date,purchase_source,status,favorite,for_sale,for_exchange,storage_location_text,notes').eq('id', widget.collectionItemId).single();
      inventory.text = row['inventory_number']?.toString() ?? '';
      condition = row['condition_code']?.toString() ?? 'VF';
      if (!conditions.contains(condition)) condition = 'VF';
      quantity.text = (row['quantity'] ?? 1).toString();
      purchasePrice.text = row['purchase_price']?.toString() ?? '';
      currentValue.text = row['current_value']?.toString() ?? '';
      purchaseSource.text = row['purchase_source']?.toString() ?? '';
      storage.text = row['storage_location_text']?.toString() ?? '';
      notes.text = row['notes']?.toString() ?? '';
      status = row['status']?.toString() ?? 'owned';
      favorite = row['favorite'] == true;
      forSale = row['for_sale'] == true;
      forExchange = row['for_exchange'] == true;
      final d = row['purchase_date']?.toString();
      if (d != null && d.isNotEmpty) purchaseDate = DateTime.tryParse(d);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось загрузить экземпляр: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  double? _money(String text) => double.tryParse(text.trim().replaceAll(' ', '').replaceAll(',', '.'));

  Future<void> _pickDate() async {
    final d = await showDatePicker(context: context, firstDate: DateTime(1800), lastDate: DateTime.now(), initialDate: purchaseDate ?? DateTime.now());
    if (d != null) setState(() => purchaseDate = d);
  }

  Future<void> _save() async {
    final q = int.tryParse(quantity.text.trim()) ?? 1;
    if (q < 1) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Количество должно быть не меньше 1'))); return; }
    setState(() => saving = true);
    try {
      await db.from('collection_items').update({
        'inventory_number': inventory.text.trim().isEmpty ? null : inventory.text.trim(),
        'condition_code': condition,
        'quantity': q,
        'purchase_price': _money(purchasePrice.text),
        'current_value': _money(currentValue.text),
        'purchase_date': purchaseDate == null ? null : '${purchaseDate!.year.toString().padLeft(4,'0')}-${purchaseDate!.month.toString().padLeft(2,'0')}-${purchaseDate!.day.toString().padLeft(2,'0')}',
        'purchase_source': purchaseSource.text.trim().isEmpty ? null : purchaseSource.text.trim(),
        'storage_location_text': storage.text.trim().isEmpty ? null : storage.text.trim(),
        'notes': notes.text.trim().isEmpty ? null : notes.text.trim(),
        'status': status,
        'favorite': favorite,
        'for_sale': forSale,
        'for_exchange': forExchange,
      }).eq('id', widget.collectionItemId);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: const Text('Удалить экземпляр?'), content: const Text('Сам каталог монеты не будет удалён. Будет удалён только ваш экземпляр.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Удалить'))]));
    if (ok != true) return;
    setState(() => saving = true);
    try {
      await db.from('collection_items').delete().eq('id', widget.collectionItemId);
      if (mounted) Navigator.pop(context, 'deleted');
    } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось удалить: $e'))); } finally { if (mounted) setState(() => saving = false); }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return Scaffold(appBar: AppBar(title: const Text('Экземпляр')), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Редактировать экземпляр'), actions: [IconButton(onPressed: saving ? null : _delete, icon: const Icon(Icons.delete_outline))]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 120), children: [
        Text(widget.title, style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 16),
        TextField(controller: inventory, decoration: const InputDecoration(labelText: 'Инвентарный номер', prefixIcon: Icon(Icons.tag), border: OutlineInputBorder())), const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: condition, decoration: const InputDecoration(labelText: 'Состояние', border: OutlineInputBorder()), items: conditions.map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => condition = v ?? condition)), const SizedBox(height: 12),
        TextField(controller: quantity, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Количество', border: OutlineInputBorder())), const SizedBox(height: 12),
        Row(children: [Expanded(child: TextField(controller: purchasePrice, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Цена покупки', suffixText: '₽', border: OutlineInputBorder()))), const SizedBox(width: 10), Expanded(child: TextField(controller: currentValue, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Текущая стоимость', suffixText: '₽', border: OutlineInputBorder())))]), const SizedBox(height: 12),
        ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event_outlined), title: Text(purchaseDate == null ? 'Дата покупки' : '${purchaseDate!.day.toString().padLeft(2,'0')}.${purchaseDate!.month.toString().padLeft(2,'0')}.${purchaseDate!.year}'), subtitle: Text(purchaseDate == null ? 'Не указана' : 'Нажмите, чтобы изменить'), onTap: _pickDate),
        TextField(controller: purchaseSource, decoration: const InputDecoration(labelText: 'Продавец / источник покупки', prefixIcon: Icon(Icons.storefront_outlined), border: OutlineInputBorder())), const SizedBox(height: 12),
        TextField(controller: storage, decoration: const InputDecoration(labelText: 'Место хранения', prefixIcon: Icon(Icons.inventory_2_outlined), hintText: 'Альбом 2, ячейка 15', border: OutlineInputBorder())), const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: status, decoration: const InputDecoration(labelText: 'Статус', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'owned', child: Text('В коллекции')), DropdownMenuItem(value: 'reserved', child: Text('Зарезервировано')), DropdownMenuItem(value: 'sold', child: Text('Продано')), DropdownMenuItem(value: 'exchanged', child: Text('Обменяно')), DropdownMenuItem(value: 'lost', child: Text('Утеряно'))], onChanged: (v) => setState(() => status = v ?? status)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Избранное'), value: favorite, onChanged: (v) => setState(() => favorite = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('На продажу'), value: forSale, onChanged: (v) => setState(() => forSale = v)),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('На обмен'), value: forExchange, onChanged: (v) => setState(() => forExchange = v)),
        TextField(controller: notes, maxLines: 5, decoration: const InputDecoration(labelText: 'Заметки', alignLabelWithHint: true, border: OutlineInputBorder())),
      ]),
      bottomNavigationBar: SafeArea(minimum: const EdgeInsets.all(12), child: FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(saving ? 'Сохранение…' : 'Сохранить'))),
    );
  }
}
