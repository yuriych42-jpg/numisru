import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/catalog_item.dart';
import '../repositories/catalog_repository.dart';
import 'catalog_detail_page.dart';
import 'collection_page.dart';
import 'taxonomy_page.dart';
import 'banknote_page.dart';
import 'unified_recognition_page.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key});

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  final searchController = TextEditingController();
  late final CatalogRepository? repository;
  Future<List<CatalogItem>>? future;
  int? selectedYear;
  String? selectedSource;

  @override
  void initState() {
    super.initState();
    repository = _hasSupabase ? CatalogRepository(Supabase.instance.client) : null;
    if (repository != null) {
      future = repository!.search();
    }
  }

  bool get _hasSupabase {
    try {
      return Supabase.instance.client.auth.currentSession != null ||
          Supabase.instance.client.rest.url.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _search() {
    if (repository == null) return;
    setState(() {
      future = repository!.search(
        query: searchController.text,
        year: selectedYear,
        sourceCode: selectedSource,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NumisRU'),
        actions: [
          IconButton(tooltip: 'Банкноты', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BanknotePage())), icon: const Icon(Icons.payments_outlined)),
          IconButton(tooltip: 'Определить', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const UnifiedRecognitionPage())), icon: const Icon(Icons.auto_awesome)),
          IconButton(
            tooltip: 'Справочник',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const TaxonomyPage()),
              );
            },
            icon: const Icon(Icons.account_tree_outlined),
          ),
          IconButton(
            tooltip: 'Моя коллекция',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CollectionPage()),
              );
            },
            icon: const Icon(Icons.collections_bookmark_outlined),
          ),
          IconButton(
            tooltip: 'Обновить',
            onPressed: repository == null ? null : _search,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: SearchBar(
              controller: searchController,
              hintText: 'Название или каталожный номер',
              leading: const Icon(Icons.search),
              trailing: [
                IconButton(
                  onPressed: _search,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ],
              onSubmitted: (_) => _search(),
            ),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                DropdownButton<int?>(
                  value: selectedYear,
                  hint: const Text('Год'),
                  items: [
                    const DropdownMenuItem<int?>(
                      value: null,
                      child: Text('Все годы'),
                    ),
                    ...List.generate(
                      35,
                      (i) => DropdownMenuItem<int?>(
                        value: 2026 - i,
                        child: Text('${2026 - i}'),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() => selectedYear = value);
                    _search();
                  },
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: const Text('Все источники'),
                    selected: selectedSource == null,
                    onSelected: (_) {
                      setState(() => selectedSource = null);
                      _search();
                    },
                  ),
                  const SizedBox(width: 8),
                  ChoiceChip(
                    label: const Text('Банк России'),
                    selected: selectedSource == 'cbr_ru_coins',
                    onSelected: (_) {
                      setState(() => selectedSource = 'cbr_ru_coins');
                      _search();
                    },
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (repository == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Supabase ещё не подключён.\n\n'
            'Запустите приложение с --dart-define=SUPABASE_URL=... '
            'и --dart-define=SUPABASE_PUBLISHABLE_KEY=...',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return FutureBuilder<List<CatalogItem>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Ошибка загрузки: ${snapshot.error}'),
            ),
          );
        }

        final items = snapshot.data ?? [];
        if (items.isEmpty) {
          return const Center(child: Text('Монеты не найдены'));
        }

        return ListView.builder(
          padding: const EdgeInsets.only(top: 8, bottom: 24),
          itemCount: items.length,
          itemBuilder: (_, index) => _CoinCard(item: items[index]),
        );
      },
    );
  }
}

class _CoinCard extends StatelessWidget {
  final CatalogItem item;

  const _CoinCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => CatalogDetailPage(catalogItemId: item.id),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: item.photoUrl == null
                    ? const Icon(Icons.currency_exchange, size: 36)
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          item.photoUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              const Icon(Icons.currency_exchange, size: 36),
                        ),
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name ?? 'Без названия',
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (item.year != null) _Chip('${item.year}'),
                        if (item.catalogNumber != null)
                          _Chip('№ ${item.catalogNumber}'),
                        if (item.denomination != null)
                          _Chip(item.denomination!),
                        if (item.sourceName != null) _Chip(item.sourceName!),
                      ],
                    ),
                    if (item.metal != null) ...[
                      const SizedBox(height: 6),
                      Text(item.metal!),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  const _Chip(this.text);

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(text),
      visualDensity: VisualDensity.compact,
      padding: EdgeInsets.zero,
    );
  }
}
