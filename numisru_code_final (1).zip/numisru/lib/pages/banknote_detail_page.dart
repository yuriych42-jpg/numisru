import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/banknote_model.dart';

class BanknoteDetailPage extends StatefulWidget {
  final BanknoteItem item;
  const BanknoteDetailPage({super.key, required this.item});
  @override State<BanknoteDetailPage> createState() => _BanknoteDetailPageState();
}

class _BanknoteDetailPageState extends State<BanknoteDetailPage> {
  List<Map<String,dynamic>> features=[];
  List<Map<String,dynamic>> media=[];
  bool loading=true;

  Future<void> _load() async {
    try {
      final client=Supabase.instance.client;
      final f=await client.from('banknote_security_features').select().eq('catalog_item_id',widget.item.id).order('sort_order');
      final m=await client.rpc('banknote_media',params:{'p_catalog_item_id':widget.item.id});
      if(mounted)setState((){features=List<Map<String,dynamic>>.from(f);media=List<Map<String,dynamic>>.from(m);});
    } catch (_) {
      // Catalog remains usable even when the optional media RPC is not deployed yet.
    } finally { if(mounted)setState(()=>loading=false); }
  }
  @override void initState(){super.initState();_load();}

  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Банкнота')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Text(widget.item.name??'Без названия',style:Theme.of(c).textTheme.headlineSmall),
      const SizedBox(height:8),
      Text('${widget.item.denomination??''} • выпуск ${widget.item.year??'—'}${widget.item.modificationYear!=null?' • мод. ${widget.item.modificationYear}':''}'),
      if(media.isNotEmpty)...[
        const SizedBox(height:16),
        SizedBox(height:190,child:PageView(children:media.map((m)=>_mediaCard(m)).toList())),
      ] else if(widget.item.photoUrl!=null)Padding(padding:const EdgeInsets.symmetric(vertical:16),child:Image.network(widget.item.photoUrl!,height:180,fit:BoxFit.contain)),
      const Divider(height:28),
      _row('Размер',widget.item.width!=null?'${widget.item.width} × ${widget.item.height} мм':null),
      _row('Материал',widget.item.material),_row('Цвета',widget.item.colors),
      _row('Серийный формат',widget.item.serialFormat),_row('Каталожный №',widget.item.catalogNumber),
      const SizedBox(height:16),
      Text('Признаки подлинности',style:Theme.of(c).textTheme.titleLarge),const SizedBox(height:8),
      if(loading)const Center(child:CircularProgressIndicator())
      else if(features.isEmpty)const Text('Признаки пока не загружены.')
      else ...features.map((f)=>Card(child:ListTile(
        leading:const Icon(Icons.verified_outlined),title:Text(f['name_ru']?.toString()??''),
        subtitle:Text(f['description_ru']?.toString()??''),
      ))),
      const SizedBox(height:8),
      const Text('Информация предназначена для справочной проверки признаков. Она не подтверждает подлинность банкноты.'),
    ]));

  Widget _mediaCard(Map<String,dynamic> m)=>Card(child:Column(children:[
    Expanded(child:Image.network(m['source_url'].toString(),fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Center(child:Icon(Icons.broken_image_outlined)))),
    Padding(padding:const EdgeInsets.all(6),child:Text(m['photo_type']=='obverse'?'Аверс':'Реверс')),
  ]));
  Widget _row(String a,String? b)=>b==null?const SizedBox.shrink():Padding(padding:const EdgeInsets.only(bottom:6),child:Text('$a: $b'));
}
