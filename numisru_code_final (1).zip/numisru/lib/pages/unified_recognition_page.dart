import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class UnifiedRecognitionPage extends StatefulWidget {
  const UnifiedRecognitionPage({super.key});
  @override
  State<UnifiedRecognitionPage> createState() => _UnifiedRecognitionPageState();
}

class _UnifiedRecognitionPageState extends State<UnifiedRecognitionPage> {
  final picker = ImagePicker();
  File? front;
  File? back;
  String mode = 'auto';
  bool busy = false;
  Map<String, dynamic>? result;
  String? error;
  String? added;

  Future<void> pick(bool first) async {
    final src = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (c) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Камера'),
              onTap: () => Navigator.pop(c, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Галерея'),
              onTap: () => Navigator.pop(c, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (src == null) return;
    final x = await picker.pickImage(source: src, imageQuality: 90, maxWidth: 2400);
    if (x != null && mounted) setState(() => first ? front = File(x.path) : back = File(x.path));
  }

  Future<void> recognize() async {
    if (front == null && back == null) return;
    setState(() { busy = true; error = null; result = null; });
    try {
      final c = Supabase.instance.client;
      final u = c.auth.currentUser!;
      final id = DateTime.now().microsecondsSinceEpoch.toString();
      Future<String?> upload(File? f, String side) async {
        if (f == null) return null;
        final p = '${u.id}/recognition/$id-$side.jpg';
        await c.storage.from('collection-photos').upload(
          p, f, fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: true),
        );
        return p;
      }
      final fp = await upload(front, 'front');
      final bp = await upload(back, 'back');
      final ins = await c.from('recognition_attempts').insert({
        'user_id': u.id,
        'obverse_storage_path': fp,
        'reverse_storage_path': bp,
      }).select('id').single();
      final r = await c.functions.invoke('recognize-money', body: {
        'attempt_id': ins['id'], 'front_path': fp, 'back_path': bp, 'mode': mode,
      });
      if (r.data is Map && r.data['error'] != null) throw Exception(r.data['error']);
      if (mounted) setState(() => result = Map<String, dynamic>.from(r.data));
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> add(Map<String, dynamic> x) async {
    final id = x['id']?.toString();
    if (id == null) return;
    final identified = Map<String, dynamic>.from(result?['identified'] ?? {});
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => _AddSheet(candidate: x, isBanknote: identified['item_kind'] == 'banknote'),
    );
    if (ok == true && mounted) setState(() => added = id);
  }

  Widget _card(String title, File? file, bool first) {
    return Card(
      child: InkWell(
        onTap: () => pick(first),
        child: SizedBox(
          height: 180,
          child: file == null
              ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Icon(Icons.add_a_photo_outlined, size: 38), Text(title),
                ])
              : ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.file(file, fit: BoxFit.cover),
                ),
        ),
      ),
    );
  }

  Widget _result(Map<String, dynamic> r) {
    final i = Map<String, dynamic>.from(r['identified'] ?? {});
    final xs = (r['candidates'] as List? ?? [])
        .map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final bank = i['item_kind'] == 'banknote';
    return Card(
      margin: const EdgeInsets.only(top: 18),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(bank ? 'Распознана банкнота' : 'Распознана монета', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('${i['country'] ?? ''} ${i['denomination'] ?? ''}'.trim(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          if (i['year'] != null) Text('Год: ${i['year']}'),
          if (i['modification_year'] != null) Text('Модификация: ${i['modification_year']}'),
          if (i['catalog_number'] != null) Text('Каталожный №: ${i['catalog_number']}'),
          Text('Уверенность: ${(((i['confidence'] ?? 0) as num) * 100).round()}%'),
          if (xs.isNotEmpty) ...[
            const Divider(height: 24),
            const Text('Совпадения каталога', style: TextStyle(fontWeight: FontWeight.bold)),
            ...xs.take(5).map((x) => ListTile(
              title: Text(x['official_name_ru']?.toString() ?? 'Без названия'),
              subtitle: Text('${x['year'] ?? '—'} • ${x['catalog_number'] ?? 'без номера'}'),
              trailing: IconButton(
                icon: Icon(added == x['id'] ? Icons.check : Icons.add),
                onPressed: added == x['id'] ? null : () => add(x),
              ),
            )),
          ],
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Определить')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'auto', label: Text('Авто'), icon: Icon(Icons.auto_awesome)),
            ButtonSegment(value: 'coin', label: Text('Монета'), icon: Icon(Icons.monetization_on_outlined)),
            ButtonSegment(value: 'banknote', label: Text('Банкнота'), icon: Icon(Icons.payments_outlined)),
          ],
          selected: {mode}, onSelectionChanged: (s) => setState(() => mode = s.first),
        ),
        const SizedBox(height: 16),
        Row(children: [Expanded(child: _card('Лицевая сторона', front, true)), const SizedBox(width: 12), Expanded(child: _card('Оборотная сторона', back, false))]),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: busy ? null : recognize,
          icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
          label: Text(busy ? 'Определяем…' : 'Определить'),
        ),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
        if (result != null) _result(result!),
      ]),
    );
  }
}

class _AddSheet extends StatefulWidget {
  final Map<String, dynamic> candidate;
  final bool isBanknote;
  const _AddSheet({required this.candidate, required this.isBanknote});
  @override State<_AddSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<_AddSheet> {
  String condition = 'VF';
  final qty = TextEditingController(text: '1');
  final price = TextEditingController();
  final serial = TextEditingController();
  bool saving = false;

  Future<void> save() async {
    setState(() => saving = true);
    try {
      final u = Supabase.instance.client.auth.currentUser!;
      final m = <String, dynamic>{
        'user_id': u.id, 'catalog_item_id': widget.candidate['id'].toString(),
        'condition_code': condition, 'quantity': int.tryParse(qty.text) ?? 1,
        'purchase_price': double.tryParse(price.text.replaceAll(',', '.')), 'status': 'owned',
      };
      if (widget.isBanknote) m['serial_number'] = serial.text.trim().isEmpty ? null : serial.text.trim();
      await Supabase.instance.client.from('collection_items').insert(m);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        setState(() => saving = false);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ошибка: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext c) {
    return Padding(
      padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(c).viewInsets.bottom + 16),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('Добавить в коллекцию', style: Theme.of(c).textTheme.titleLarge),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: condition,
          decoration: const InputDecoration(labelText: 'Состояние'),
          items: const ['PR','G','VG','F','VF','XF','AU','UNC','BU','PROOF'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() => condition = v ?? 'VF'),
        ),
        TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Количество')),
        TextField(controller: price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Цена покупки, ₽')),
        if (widget.isBanknote) TextField(controller: serial, decoration: const InputDecoration(labelText: 'Серийный номер (необязательно)')),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton(onPressed: saving ? null : save, child: Text(saving ? 'Сохраняем…' : 'Добавить'))),
      ]),
    );
  }
}
