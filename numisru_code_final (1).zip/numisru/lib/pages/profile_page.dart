import 'package:flutter/material.dart';
import 'transactions_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _name = TextEditingController();
  bool _loading = true;
  bool _saving = false;
  SupabaseClient get _supabase => Supabase.instance.client;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final id = _supabase.auth.currentUser!.id;
      final row = await _supabase.from('profiles').select('display_name').eq('id', id).maybeSingle();
      _name.text = (row?['display_name'] ?? '').toString();
    } finally { if (mounted) setState(() => _loading = false); }
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await _supabase.from('profiles').update({'display_name': _name.text.trim(), 'updated_at': DateTime.now().toIso8601String()}).eq('id', _supabase.auth.currentUser!.id);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Профиль сохранён')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override
  void dispose() { _name.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Профиль')),
      body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(leading: const Icon(Icons.receipt_long_outlined), title: const Text('Операции'), subtitle: const Text('Покупки, продажи и обмены'), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TransactionsPage()))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.lock_open_outlined), const SizedBox(width: 10), Expanded(child: Text('Гостевой режим', style: Theme.of(context).textTheme.titleMedium))]),
          const SizedBox(height: 8),
          const Text('Регистрация не нужна. Коллекция хранится в вашей анонимной Supabase-сессии на устройстве.'),
          const SizedBox(height: 16),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Имя коллекционера')),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: const Text('Сохранить')),
        ]))),
        const SizedBox(height: 8),
        Card(child: ListTile(leading: const Icon(Icons.currency_ruble), title: const Text('Основная валюта'), subtitle: const Text('RUB'))),
        const SizedBox(height: 8),
        const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('О NumisRU'), subtitle: Text('Профессиональный каталог и учёт коллекции монет и банкнот.'))),
      ]),
    );
  }
}
