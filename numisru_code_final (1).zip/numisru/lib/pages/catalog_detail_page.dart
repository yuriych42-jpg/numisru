import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CatalogDetailPage extends StatefulWidget {
  final String catalogItemId;
  const CatalogDetailPage({super.key, required this.catalogItemId});

  @override
  State<CatalogDetailPage> createState() => _CatalogDetailPageState();
}

class _CatalogDetailPageState extends State<CatalogDetailPage> {
  late Future<Map<String, dynamic>> future;

  @override
  void initState() {
    super.initState();
    future = _load();
  }

  Future<Map<String, dynamic>> _load() async {
    final row = await Supabase.instance.client
        .from('catalog_items')
        .select('id, official_name_ru, description_ru, '
            'obverse_description_ru, reverse_description_ru, '
            'edge_description_ru, catalog_number, series_name_ru, '
            'year, issue_date, metal_text_ru, fineness, weight_g, '
            'diameter_mm, thickness_mm, mintage, quality, shape, edge_text')
        .eq('id', widget.catalogItemId)
        .single();
    return Map<String, dynamic>.from(row);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Монета')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Ошибка: ${snapshot.error}'));
          }
          final c = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            children: [
              Text(c['official_name_ru'] ?? 'Без названия',
                  style: Theme.of(context).textTheme.headlineSmall),
              if (c['catalog_number'] != null)
                Text('Каталожный № ${c['catalog_number']}'),
              const SizedBox(height: 16),
              _InfoCard(c),
              _Desc('Описание', c['description_ru']),
              _Desc('Аверс', c['obverse_description_ru']),
              _Desc('Реверс', c['reverse_description_ru']),
              _Desc('Гурт', c['edge_description_ru']),
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: _addWishlist, icon: const Icon(Icons.bookmark_add_outlined), label: const Text('Добавить в Wishlist')),
            ],
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.all(12),
        child: FilledButton.icon(
          onPressed: _add,
          icon: const Icon(Icons.add),
          label: const Text('Добавить в коллекцию'),
        ),
      ),
    );
  }

  Future<void> _addWishlist() async {
    final supabase = Supabase.instance.client;
    final user = supabase.auth.currentUser;
    if (user == null) return;
    try {
      final existing = await supabase.from('wishlists').select('id').eq('user_id', user.id).eq('name', 'Основной').maybeSingle();
      String listId;
      if (existing == null) {
        final created = await supabase.from('wishlists').insert({'user_id': user.id, 'name': 'Основной'}).select('id').single();
        listId = created['id'].toString();
      } else {
        listId = existing['id'].toString();
      }
      final duplicate = await supabase.from('wishlist_items').select('id').eq('wishlist_id', listId).eq('catalog_item_id', widget.catalogItemId).maybeSingle();
      if (duplicate == null) {
        await supabase.from('wishlist_items').insert({'wishlist_id': listId, 'catalog_item_id': widget.catalogItemId, 'priority': 'normal', 'target_currency': 'RUB'});
      }
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Добавлено в Wishlist')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось добавить: $e')));
    }
  }

  Future<void> _add() async {
    if (Supabase.instance.client.auth.currentUser == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не удалось создать локальную сессию')),
      );
      return;
    }
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _AddSheet(catalogItemId: widget.catalogItemId),
    );
    if (ok == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Экземпляр добавлен')),
      );
    }
  }
}

class _InfoCard extends StatelessWidget {
  final Map<String, dynamic> c;
  const _InfoCard(this.c);

  @override
  Widget build(BuildContext context) {
    final rows = <MapEntry<String, String>>[];
    void add(String name, dynamic value, [String suffix = '']) {
      if (value != null && value.toString().trim().isNotEmpty) {
        rows.add(MapEntry(name, '${value.toString()}$suffix'));
      }
    }
    add('Год', c['year']);
    add('Дата выпуска', c['issue_date']);
    add('Серия', c['series_name_ru']);
    add('Металл', c['metal_text_ru']);
    add('Проба', c['fineness']);
    add('Масса', c['weight_g'], ' г');
    add('Диаметр', c['diameter_mm'], ' мм');
    add('Толщина', c['thickness_mm'], ' мм');
    add('Тираж', c['mintage']);
    add('Качество', c['quality']);
    add('Форма', c['shape']);
    add('Гурт', c['edge_text']);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: rows.map((r) => Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(width: 125, child: Text(r.key)),
                Expanded(child: Text(r.value)),
              ],
            ),
          )).toList(),
        ),
      ),
    );
  }
}

class _Desc extends StatelessWidget {
  final String title;
  final dynamic value;
  const _Desc(this.title, this.value);

  @override
  Widget build(BuildContext context) {
    final text = value?.toString().trim();
    if (text == null || text.isEmpty) return const SizedBox.shrink();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(text),
          ],
        ),
      ),
    );
  }
}

class _AddSheet extends StatefulWidget {
  final String catalogItemId;
  const _AddSheet({required this.catalogItemId});

  @override
  State<_AddSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<_AddSheet> {
  final condition = TextEditingController(text: 'VF');
  final quantity = TextEditingController(text: '1');
  final price = TextEditingController();
  bool saving = false;

  @override
  void dispose() {
    condition.dispose();
    quantity.dispose();
    price.dispose();
    super.dispose();
  }

  Future<void> save() async {
    final user = Supabase.instance.client.auth.currentUser!;
    final q = int.tryParse(quantity.text) ?? 1;
    final p = double.tryParse(price.text.replaceAll(',', '.'));
    if (q < 1) return;

    setState(() => saving = true);
    try {
      await Supabase.instance.client.from('collection_items').insert({
        'user_id': user.id,
        'catalog_item_id': widget.catalogItemId,
        'condition_code': condition.text.trim().toUpperCase(),
        'quantity': q,
        if (p != null) 'purchase_price': p,
        'status': 'owned',
      });
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не удалось сохранить: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + bottom),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Новый экземпляр',
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            TextField(
              controller: condition,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                labelText: 'Состояние',
                hintText: 'VF / XF / AU / UNC',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: quantity,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Количество',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: price,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Цена покупки',
                suffixText: '₽',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: saving ? null : save,
              child: saving
                  ? const SizedBox(
                      height: 20, width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Сохранить'),
            ),
          ],
        ),
      ),
    );
  }
}
