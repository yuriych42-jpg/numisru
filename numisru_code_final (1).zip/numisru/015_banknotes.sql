-- NumisRU v2.1: banknote taxonomy, security features and per-note serials.
alter table public.catalog_items
  add column if not exists banknote_modification_year int,
  add column if not exists banknote_size_width_mm numeric,
  add column if not exists banknote_size_height_mm numeric,
  add column if not exists banknote_material text,
  add column if not exists banknote_colors text,
  add column if not exists banknote_serial_format text,
  add column if not exists banknote_front_description_ru text,
  add column if not exists banknote_back_description_ru text;

create table if not exists public.banknote_security_features (
  id uuid primary key default gen_random_uuid(),
  catalog_item_id uuid not null references public.catalog_items(id) on delete cascade,
  control_method text not null check (control_method in ('look','light','angle','touch','magnifier','uv','ir','other')),
  name_ru text not null,
  description_ru text,
  is_primary boolean not null default false,
  sort_order int not null default 0,
  source_url text,
  created_at timestamptz not null default now()
);
create index if not exists banknote_security_features_item_idx on public.banknote_security_features(catalog_item_id, sort_order);
alter table public.banknote_security_features enable row level security;
grant select on public.banknote_security_features to authenticated;
create policy "banknote security features readable" on public.banknote_security_features
for select to authenticated using (exists (select 1 from public.catalog_items ci where ci.id = catalog_item_id and ci.item_kind = 'banknote'));

alter table public.collection_items
  add column if not exists serial_prefix text,
  add column if not exists serial_number text,
  add column if not exists serial_number_left text,
  add column if not exists serial_number_right text;
create index if not exists collection_items_serial_idx on public.collection_items(user_id, serial_number);

insert into public.catalog_sources(code, name_ru, scope_code, authority_level, license_note, is_active)
values ('cbr_ru_banknotes', 'Банк России — банкноты', 'rf_banknotes', 'official', 'Использовать официальный источник и соблюдать условия Банка России.', true)
on conflict (code) do update set is_active = true, name_ru = excluded.name_ru, scope_code = excluded.scope_code, authority_level = excluded.authority_level, license_note = excluded.license_note;

create or replace function public.search_banknotes(
  p_query text default null,
  p_denomination text default null,
  p_year int default null,
  p_modification_year int default null
)
returns table (
  id uuid, official_name_ru text, denomination_text_ru text, year int,
  banknote_modification_year int, catalog_number text, source_code text,
  source_name_ru text, banknote_size_width_mm numeric, banknote_size_height_mm numeric,
  banknote_material text, banknote_colors text, banknote_serial_format text,
  photo_url text
)
language sql stable security definer set search_path = public
as $$
  select ci.id, ci.official_name_ru, ci.denomination_text_ru, ci.year,
         ci.banknote_modification_year, ci.catalog_number, cs.code, cs.name_ru,
         ci.banknote_size_width_mm, ci.banknote_size_height_mm, ci.banknote_material,
         ci.banknote_colors, ci.banknote_serial_format,
         (select cip.source_url from public.catalog_item_photos cip where cip.catalog_item_id = ci.id order by cip.sort_order limit 1)
  from public.catalog_items ci
  join public.catalog_sources cs on cs.id = ci.source_id
  where ci.item_kind = 'banknote'
    and cs.is_active
    and (p_query is null or p_query = '' or ci.official_name_ru ilike '%'||p_query||'%' or ci.catalog_number ilike '%'||p_query||'%')
    and (p_denomination is null or p_denomination = '' or ci.denomination_text_ru = p_denomination)
    and (p_year is null or ci.year = p_year)
    and (p_modification_year is null or ci.banknote_modification_year = p_modification_year)
  order by coalesce(ci.denomination_text_ru,''), coalesce(ci.year,0) desc, ci.official_name_ru;
$$;
grant execute on function public.search_banknotes(text,text,int,int) to authenticated;

create or replace function public.match_banknote_candidates(
  p_denomination text default null,
  p_year int default null,
  p_modification_year int default null,
  p_catalog_number text default null,
  p_name text default null
)
returns table (id uuid, official_name_ru text, denomination_text_ru text, year int, catalog_number text, match_score numeric, match_reasons text[])
language sql stable security definer set search_path = public
as $$
  select ci.id, ci.official_name_ru, ci.denomination_text_ru, ci.year, ci.catalog_number,
    least(100, (case when p_catalog_number is not null and ci.catalog_number = p_catalog_number then 65 else 0 end)
      + case when p_year is not null and ci.year = p_year then 20 else 0 end
      + case when p_modification_year is not null and ci.banknote_modification_year = p_modification_year then 10 else 0 end
      + case when p_denomination is not null and ci.denomination_text_ru = p_denomination then 5 else 0 end) as match_score,
    array_remove(array[
      case when p_catalog_number is not null and ci.catalog_number = p_catalog_number then 'точный каталожный номер' end,
      case when p_year is not null and ci.year = p_year then 'совпадает год' end,
      case when p_modification_year is not null and ci.banknote_modification_year = p_modification_year then 'совпадает модификация' end,
      case when p_denomination is not null and ci.denomination_text_ru = p_denomination then 'совпадает номинал' end
    ], null)::text[] as match_reasons
  from public.catalog_items ci
  where ci.item_kind = 'banknote'
  order by match_score desc, ci.year desc nulls last
  limit 10;
$$;
grant execute on function public.match_banknote_candidates(text,int,int,text,text) to authenticated;
