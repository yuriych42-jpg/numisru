-- NumisRU v1.2: weighted catalog matching for recognition results.
create extension if not exists pg_trgm;

create or replace function public.match_recognition_candidates(
  p_catalog_number text default null,
  p_year integer default null,
  p_denomination text default null,
  p_metal text default null,
  p_country text default null,
  p_issuer text default null
)
returns table (
  id uuid,
  official_name_ru text,
  catalog_number text,
  year integer,
  metal_text_ru text,
  series_name_ru text,
  match_score numeric,
  match_reasons text[]
)
language sql
stable
as $$
  with base as (
    select
      c.id,
      c.official_name_ru,
      c.catalog_number,
      c.year,
      c.metal_text_ru,
      c.series_name_ru,
      lower(concat_ws(' ', c.official_name_ru, c.description_ru, c.series_name_ru, c.metal_text_ru, c.catalog_number)) as haystack,
      lower(coalesce(p_catalog_number, '')) as q_catalog,
      lower(coalesce(p_denomination, '')) as q_denom,
      lower(coalesce(p_metal, '')) as q_metal,
      lower(coalesce(p_country, '')) as q_country,
      lower(coalesce(p_issuer, '')) as q_issuer
    from public.catalog_items c
  ), scored as (
    select
      b.*,
      (case when q_catalog <> '' and lower(coalesce(b.catalog_number,'')) = q_catalog then 60 else 0 end
       + case when p_year is not null and b.year = p_year then 20 else 0 end
       + case when q_denom <> '' and b.haystack like '%' || q_denom || '%' then 10 else 0 end
       + case when q_metal <> '' and b.haystack like '%' || q_metal || '%' then 5 else 0 end
       + case when q_country <> '' and b.haystack like '%' || q_country || '%' then 3 else 0 end
       + case when q_issuer <> '' and b.haystack like '%' || q_issuer || '%' then 2 else 0 end
       + case when q_denom <> '' then round(greatest(similarity(b.haystack, q_denom), 0)::numeric * 5, 2) else 0 end
      )::numeric as score
    from base b
  )
  select
    s.id,
    s.official_name_ru,
    s.catalog_number,
    s.year,
    s.metal_text_ru,
    s.series_name_ru,
    least(s.score, 100)::numeric as match_score,
    array_remove(array[
      case when q_catalog <> '' and lower(coalesce(s.catalog_number,'')) = q_catalog then 'точный каталожный номер' end,
      case when p_year is not null and s.year = p_year then 'совпадает год' end,
      case when q_denom <> '' and s.haystack like '%' || q_denom || '%' then 'совпадает номинал/название' end,
      case when q_metal <> '' and s.haystack like '%' || q_metal || '%' then 'совпадает металл' end,
      case when q_country <> '' and s.haystack like '%' || q_country || '%' then 'совпадает страна' end,
      case when q_issuer <> '' and s.haystack like '%' || q_issuer || '%' then 'совпадает эмитент' end
    ], null) as match_reasons
  from scored s
  where s.score > 0
  order by s.score desc, s.year desc nulls last, s.catalog_number asc nulls last
  limit 10;
$$;

revoke all on function public.match_recognition_candidates(text, integer, text, text, text, text) from public, anon, authenticated;
grant execute on function public.match_recognition_candidates(text, integer, text, text, text, text) to service_role;
