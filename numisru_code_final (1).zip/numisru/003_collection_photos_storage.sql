-- NumisRU v0.3: Storage для пользовательских фотографий.
insert into storage.buckets (id, name, public)
values ('collection-photos', 'collection-photos', false)
on conflict (id) do nothing;

drop policy if exists "collection_photos_select_own" on storage.objects;
create policy "collection_photos_select_own"
on storage.objects for select
to authenticated
using (
  bucket_id = 'collection-photos'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

drop policy if exists "collection_photos_insert_own" on storage.objects;
create policy "collection_photos_insert_own"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'collection-photos'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

drop policy if exists "collection_photos_update_own" on storage.objects;
create policy "collection_photos_update_own"
on storage.objects for update
to authenticated
using (
  bucket_id = 'collection-photos'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
)
with check (
  bucket_id = 'collection-photos'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);

drop policy if exists "collection_photos_delete_own" on storage.objects;
create policy "collection_photos_delete_own"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'collection-photos'
  and (storage.foldername(name))[1] = (select auth.uid()::text)
);
