-- NumisRU v0.7
-- Extra editable fields for a professional per-specimen record.
-- Safe to run more than once.

alter table public.collection_items add column if not exists purchase_source text;
alter table public.collection_items add column if not exists storage_location_text text;
alter table public.collection_items add column if not exists notes text;
alter table public.collection_items add column if not exists for_sale boolean not null default false;
alter table public.collection_items add column if not exists for_exchange boolean not null default false;

-- These are expected in the base schema, but keeping the migration idempotent helps
-- when upgrading an older MVP database.
alter table public.collection_items add column if not exists current_value numeric(14,2);
alter table public.collection_items add column if not exists purchase_date date;
alter table public.collection_items add column if not exists favorite boolean not null default false;
alter table public.collection_items add column if not exists status text not null default 'owned';

alter table public.collection_items enable row level security;
grant select, insert, update, delete on public.collection_items to authenticated;

drop policy if exists "collection_items_own" on public.collection_items;
create policy "collection_items_own"
on public.collection_items
for all to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());
