-- NumisRU v0.2: безопасный доступ пользователя к своим экземплярам.
alter table public.collection_items enable row level security;

grant select, insert, update, delete
on public.collection_items to authenticated;

drop policy if exists "collection_items_select_own" on public.collection_items;
create policy "collection_items_select_own"
on public.collection_items for select to authenticated
using (user_id = auth.uid());

drop policy if exists "collection_items_insert_own" on public.collection_items;
create policy "collection_items_insert_own"
on public.collection_items for insert to authenticated
with check (user_id = auth.uid());

drop policy if exists "collection_items_update_own" on public.collection_items;
create policy "collection_items_update_own"
on public.collection_items for update to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());

drop policy if exists "collection_items_delete_own" on public.collection_items;
create policy "collection_items_delete_own"
on public.collection_items for delete to authenticated
using (user_id = auth.uid());
