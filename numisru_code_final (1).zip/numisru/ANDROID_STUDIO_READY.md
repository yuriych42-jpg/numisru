# NumisRU — пакет для Android Studio

Это Flutter-проект с Android host уже добавленным в репозиторий. Открывайте корневую папку `numisru`, а не папку `android` отдельно.

## Требования
- Flutter SDK (stable, Dart 3.10+)
- Android Studio
- Android SDK / Platform Tools
- Android SDK API, который использует установленная версия Flutter

## Первый запуск

```bash
flutter doctor
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

## Сборка APK

```bash
flutter build apk --release --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

APK появится в `build/app/outputs/flutter-apk/app-release.apk`.

## Supabase

Включите Anonymous Sign-Ins. Примените SQL-миграции из корня проекта по порядку. `SUPABASE_PUBLISHABLE_KEY` — только publishable/anon key; service role key в APK не помещается.
