-- NumisRU v1.3: market value estimation.
-- Uses recent catalog price history, user-entered market/sale prices and
-- real sales transactions. A manually entered current_value remains the
-- user's override and is never silently replaced.

create or replace function public.estimate_collection_item_value(p_collection_item_id uuid)
returns table (
  collection_item_id uuid,
  catalog_item_id uuid,
  manual_value numeric,
  estimated_value numeric,
  low_value numeric,
  high_value numeric,
  confidence numeric,
  sample_count integer,
  method text,
  currency char(3)
)
language sql
stable
security invoker
as $$
  with item as (
    select ci.id, ci.catalog_item_id, ci.current_value
    from public.collection_items ci
    where ci.id = p_collection_item_id
      and ci.user_id = auth.uid()
  ),
  prices as (
    select ph.price::numeric as price
    from public.price_history ph
    join item i on i.catalog_item_id = ph.catalog_item_id
    where ph.currency = 'RUB'
      and ph.price_date >= current_date - interval '365 days'
      and ph.price > 0
    union all
    select cip.price::numeric
    from public.collection_item_prices cip
    join public.collection_items ci on ci.id = cip.collection_item_id
    join item i on i.catalog_item_id = ci.catalog_item_id
    where cip.currency = 'RUB'
      and cip.created_at >= now() - interval '365 days'
      and cip.price > 0
      and cip.price_type in ('market','sale','auction','estimated','catalog')
    union all
    select t.amount::numeric
    from public.transactions t
    join public.collection_items ci on ci.id = t.collection_item_id
    join item i on i.catalog_item_id = ci.catalog_item_id
    where t.currency = 'RUB'
      and t.type = 'sale'
      and t.transaction_date >= current_date - interval '365 days'
      and t.amount > 0
  ),
  stats as (
    select
      count(*)::integer as n,
      percentile_cont(0.25) within group (order by price)::numeric as p25,
      percentile_cont(0.50) within group (order by price)::numeric as p50,
      percentile_cont(0.75) within group (order by price)::numeric as p75
    from prices
  )
  select
    i.id,
    i.catalog_item_id,
    i.current_value,
    case when s.n > 0 then round(s.p50, 2) else null end,
    case when s.n > 0 then round(s.p25, 2) else null end,
    case when s.n > 0 then round(s.p75, 2) else null end,
    case
      when s.n >= 20 then 0.95
      when s.n >= 10 then 0.85
      when s.n >= 5 then 0.70
      when s.n >= 2 then 0.50
      when s.n = 1 then 0.30
      else 0
    end,
    s.n,
    case
      when s.n >= 5 then 'Медиана рыночных данных'
      when s.n > 0 then 'Ограниченная рыночная выборка'
      else 'Недостаточно рыночных данных'
    end,
    'RUB'::char(3)
  from item i
  cross join stats s;
$$;

revoke all on function public.estimate_collection_item_value(uuid) from public, anon;
grant execute on function public.estimate_collection_item_value(uuid) to authenticated;
