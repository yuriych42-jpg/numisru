-- NumisRU v0.4: RLS + grants for user collection photos.
-- The base schema already has the ownership policy, but this migration is
-- idempotent and makes the client permissions explicit.

alter table public.collection_item_photos enable row level security;

grant select, insert, update, delete
on public.collection_item_photos to authenticated;

drop policy if exists "collection photos own rows" on public.collection_item_photos;
create policy "collection photos own rows"
on public.collection_item_photos
for all
to authenticated
using (
  exists (
    select 1
    from public.collection_items c
    where c.id = collection_item_id
      and c.user_id = auth.uid()
  )
)
with check (
  exists (
    select 1
    from public.collection_items c
    where c.id = collection_item_id
      and c.user_id = auth.uid()
  )
);
