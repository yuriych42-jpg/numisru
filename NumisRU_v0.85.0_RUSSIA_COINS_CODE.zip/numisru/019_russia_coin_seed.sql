-- NumisRU v0.85.0: starter catalog of Russian regular-issue coins.
-- Conservative seed: only denomination/year labels are populated; no unverified
-- mintages, alloy details, mint marks, or catalog numbers are invented.
-- Run after 018_coin_issue_types.sql.

insert into public.catalog_sources(code, name_ru, base_url, scope_code, authority_level, license_note, is_active)
values ('cbr_ru_regular_coins', 'Банк России — монеты регулярного чекана',
        'https://www.cbr.ru/cash_circulation/', 'rf_1992_present', 'official',
        'Наименования и годы выпуска; спецификации следует дополнять по официальным данным.', true)
on conflict (code) do update set
  name_ru=excluded.name_ru, base_url=excluded.base_url, scope_code=excluded.scope_code,
  authority_level=excluded.authority_level, license_note=excluded.license_note, is_active=true;

do $$
declare src uuid; r record;
begin
  select id into src from public.catalog_sources where code='cbr_ru_regular_coins';
  for r in select * from (values
    ('RU-KOP-01-1997','1 копейка',1997),
    ('RU-KOP-05-1997','5 копеек',1997),
    ('RU-KOP-10-1997','10 копеек',1997),
    ('RU-KOP-50-1997','50 копеек',1997),
    ('RU-RUB-01-1997','1 рубль',1997),
    ('RU-RUB-02-1997','2 рубля',1997),
    ('RU-RUB-05-1997','5 рублей',1997),
    ('RU-RUB-10-1997','10 рублей',1997),
    ('RU-RUB-01-2009','1 рубль',2009),
    ('RU-RUB-02-2009','2 рубля',2009),
    ('RU-RUB-05-2009','5 рублей',2009),
    ('RU-RUB-10-2009','10 рублей',2009)
  ) as v(ext_id,denom,yr)
  loop
    insert into public.catalog_items(source_id,source_external_id,item_kind,year,
      official_name_ru,denomination_text_ru,issue_type,official_url,source_updated_at)
    values (src,r.ext_id,'coin'::public.item_kind,r.yr,
      'Россия. Монета регулярного чекана номиналом '||r.denom||', '||r.yr||' год',
      r.denom,'regular','https://www.cbr.ru/cash_circulation/',now())
    on conflict (source_id,source_external_id) do update set
      year=excluded.year, official_name_ru=excluded.official_name_ru,
      denomination_text_ru=excluded.denomination_text_ru, issue_type=excluded.issue_type,
      official_url=excluded.official_url, source_updated_at=excluded.source_updated_at;
  end loop;
end $$;
