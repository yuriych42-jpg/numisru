import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/catalog_item.dart';
import '../models/banknote_model.dart';
import '../repositories/catalog_repository.dart';
import 'catalog_detail_page.dart';
import 'banknote_detail_page.dart';
import 'collection_page.dart';
import 'taxonomy_page.dart';
import 'banknote_page.dart';
import 'unified_recognition_page.dart';

class CatalogPage extends StatefulWidget {
  final String initialQuery;
  const CatalogPage({super.key, this.initialQuery = ''});

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  final searchController = TextEditingController();
  late final CatalogRepository? repository;
  Future<List<CatalogItem>>? future;
  Future<List<_GlobalSearchResult>>? globalSearchFuture;
  bool _showGlobalResults = false;
  int? selectedYear;
  String? selectedSource;

  @override
  void initState() {
    super.initState();
    repository = _hasSupabase ? CatalogRepository(Supabase.instance.client) : null;
    if (repository != null) {
      future = repository!.search();
      final query = widget.initialQuery.trim();
      if (query.isNotEmpty) {
        searchController.text = query;
        _showGlobalResults = true;
        globalSearchFuture = _searchAllCatalogs(query);
      }
    }
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  bool get _hasSupabase {
    try {
      return Supabase.instance.client.auth.currentSession != null ||
          Supabase.instance.client.rest.url.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _search() {
    if (repository == null) return;
    final query = searchController.text.trim();
    setState(() {
      if (query.isNotEmpty) {
        _showGlobalResults = true;
        globalSearchFuture = _searchAllCatalogs(query);
      } else {
        _showGlobalResults = false;
        globalSearchFuture = null;
        future = repository!.search(year: selectedYear, sourceCode: selectedSource);
      }
    });
  }

  Future<List<_GlobalSearchResult>> _searchAllCatalogs(String query) async {
    final results = <_GlobalSearchResult>[];
    final coins = await repository!.search(query: query, limit: 50);
    results.addAll(coins.map(_GlobalSearchResult.coin));
    try {
      final banknotesById = <String, BanknoteItem>{};
      final rows = await Supabase.instance.client.rpc('search_banknotes', params: {
        'p_query': query,
        'p_denomination': null,
        'p_year': null,
        'p_modification_year': null,
      });
      for (final row in rows as List) {
        final item = BanknoteItem.fromMap(Map<String, dynamic>.from(row));
        banknotesById[item.id] = item;
      }
      final numericYear = int.tryParse(query);
      if (numericYear != null && query.length == 4) {
        final yearRows = await Supabase.instance.client.rpc('search_banknotes', params: {
          'p_query': null,
          'p_denomination': null,
          'p_year': numericYear,
          'p_modification_year': null,
        });
        for (final row in yearRows as List) {
          final item = BanknoteItem.fromMap(Map<String, dynamic>.from(row));
          banknotesById[item.id] = item;
        }
      }
      results.addAll(banknotesById.values.map(_GlobalSearchResult.banknote));
    } catch (_) {
      // Coin results remain available if the banknote RPC/migration is not deployed.
    }
    return results;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NumisRU'),
        actions: [
          IconButton(tooltip: 'Банкноты', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BanknotePage())), icon: const Icon(Icons.payments_outlined)),
          IconButton(tooltip: 'Определить', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const UnifiedRecognitionPage())), icon: const Icon(Icons.auto_awesome)),
          IconButton(
            tooltip: 'Справочник',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const TaxonomyPage()),
              );
            },
            icon: const Icon(Icons.account_tree_outlined),
          ),
          IconButton(
            tooltip: 'Моя коллекция',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CollectionPage()),
              );
            },
            icon: const Icon(Icons.collections_bookmark_outlined),
          ),
          IconButton(
            tooltip: 'Обновить',
            onPressed: repository == null ? null : _search,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: SearchBar(
              controller: searchController,
              hintText: 'Поиск по всем каталогам: название, год, номер',
              leading: const Icon(Icons.search),
              trailing: [
                IconButton(
                  onPressed: _search,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ],
              onSubmitted: (_) => _search(),
            ),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                DropdownButton<int?>(
                  value: selectedYear,
                  hint: const Text('Год'),
                  items: [
                    const DropdownMenuItem<int?>(
                      value: null,
                      child: Text('Все годы'),
                    ),
                    ...List.generate(
                      35,
                      (i) => DropdownMenuItem<int?>(
                        value: 2026 - i,
                        child: Text('${2026 - i}'),
                      ),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() => selectedYear = value);
                    _search();
                  },
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: const Text('Все источники'),
                    selected: selectedSource == null,
                    onSelected: (_) {
                      setState(() => selectedSource = null);
                      _search();
                    },
                  ),
                  const SizedBox(width: 8),
                  ChoiceChip(
                    label: const Text('Банк России'),
                    selected: selectedSource == 'cbr_ru_coins',
                    onSelected: (_) {
                      setState(() => selectedSource = 'cbr_ru_coins');
                      _search();
                    },
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 1),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (repository == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Supabase ещё не подключён.\n\n'
            'Запустите приложение с --dart-define=SUPABASE_URL=... '
            'и --dart-define=SUPABASE_PUBLISHABLE_KEY=...',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    if (_showGlobalResults) {
      return FutureBuilder<List<_GlobalSearchResult>>(
        future: globalSearchFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Ошибка поиска: ${snapshot.error}'),
            ));
          }
          final results = snapshot.data ?? const <_GlobalSearchResult>[];
          if (results.isEmpty) return const Center(child: Text('Ничего не найдено во всех каталогах'));
          return ListView.builder(
            padding: const EdgeInsets.only(top: 8, bottom: 24),
            itemCount: results.length,
            itemBuilder: (context, index) => _GlobalSearchResultTile(result: results[index]),
          );
        },
      );
    }

    return FutureBuilder<List<CatalogItem>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Ошибка загрузки: ${snapshot.error}'),
            ),
          );
        }

        final items = snapshot.data ?? [];
        if (items.isEmpty) {
          return const Center(child: Text('Монеты не найдены'));
        }

        return ListView.builder(
          padding: const EdgeInsets.only(top: 8, bottom: 24),
          itemCount: items.length,
          itemBuilder: (_, index) => _CoinCard(item: items[index]),
        );
      },
    );
  }
}

class _GlobalSearchResult {
  final CatalogItem? coinItem;
  final BanknoteItem? banknoteItem;
  const _GlobalSearchResult._({this.coinItem, this.banknoteItem});
  factory _GlobalSearchResult.coin(CatalogItem item) => _GlobalSearchResult._(coinItem: item);
  factory _GlobalSearchResult.banknote(BanknoteItem item) => _GlobalSearchResult._(banknoteItem: item);
  String get title => coinItem?.name ?? banknoteItem?.name ?? 'Без названия';
  String get kind => coinItem != null ? 'Монета' : 'Банкнота';
  String get subtitle {
    final c = coinItem;
    if (c != null) return [if (c.catalogNumber?.isNotEmpty == true) '№ ${c.catalogNumber}', if (c.year != null) '${c.year}', if (c.sourceName?.isNotEmpty == true) c.sourceName!].join(' • ');
    final b = banknoteItem!;
    return [if (b.catalogNumber?.isNotEmpty == true) '№ ${b.catalogNumber}', if (b.denomination?.isNotEmpty == true) b.denomination!, if (b.year != null) '${b.year}', if (b.sourceName?.isNotEmpty == true) b.sourceName!].join(' • ');
  }
}

class _GlobalSearchResultTile extends StatelessWidget {
  final _GlobalSearchResult result;
  const _GlobalSearchResultTile({required this.result});
  @override
  Widget build(BuildContext context) => Card(
    child: ListTile(
      leading: Icon(result.coinItem != null ? Icons.currency_exchange : Icons.payments_outlined),
      title: Text(result.title),
      subtitle: Text('${result.kind}${result.subtitle.isEmpty ? '' : ' • ${result.subtitle}'}'),
      trailing: const Icon(Icons.open_in_new),
      onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => result.coinItem != null
          ? CatalogDetailPage(catalogItemId: result.coinItem!.id)
          : BanknoteDetailPage(item: result.banknoteItem!),
      )),
    ),
  );
}

class _CoinCard extends StatelessWidget {
  final CatalogItem item;

  const _CoinCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => CatalogDetailPage(catalogItemId: item.id),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: item.photoUrl == null
                    ? const Icon(Icons.currency_exchange, size: 36)
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          item.photoUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              const Icon(Icons.currency_exchange, size: 36),
                        ),
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name ?? 'Без названия',
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (item.year != null) _Chip('${item.year}'),
                        if (item.catalogNumber != null)
                          _Chip('№ ${item.catalogNumber}'),
                        if (item.denomination != null)
                          _Chip(item.denomination!),
                        if (item.sourceName != null) _Chip(item.sourceName!),
                      ],
                    ),
                    if (item.metal != null) ...[
                      const SizedBox(height: 6),
                      Text(item.metal!),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  const _Chip(this.text);

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(text),
      visualDensity: VisualDensity.compact,
      padding: EdgeInsets.zero,
    );
  }
}
