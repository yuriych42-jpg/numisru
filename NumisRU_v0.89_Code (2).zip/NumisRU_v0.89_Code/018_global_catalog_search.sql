-- NumisRU 0.89: global catalog search RPC for coins.
-- SECURITY DEFINER avoids requiring direct client SELECT on catalog_items.
create or replace function public.search_coins(p_query text default null)
returns table (
  id uuid, official_name_ru text, catalog_number text, year int,
  denomination_text_ru text, metal_text_ru text, weight_g numeric,
  diameter_mm numeric, mintage bigint, source jsonb, photo_url text
)
language sql stable security definer set search_path = public
as $$
  select ci.id, ci.official_name_ru, ci.catalog_number, ci.year,
         ci.denomination_text_ru, ci.metal_text_ru, ci.weight_g,
         ci.diameter_mm, ci.mintage,
         jsonb_build_object('code', cs.code, 'name_ru', cs.name_ru) as source,
         (select cip.source_url from public.catalog_item_photos cip
          where cip.catalog_item_id = ci.id order by cip.sort_order limit 1) as photo_url
  from public.catalog_items ci
  join public.catalog_sources cs on cs.id = ci.source_id
  where ci.item_kind = 'coin' and cs.is_active
    and (p_query is null or btrim(p_query) = ''
      or ci.official_name_ru ilike '%' || btrim(p_query) || '%'
      or ci.catalog_number ilike '%' || btrim(p_query) || '%'
      or (btrim(p_query) ~ '^[0-9]{1,4}$' and ci.year = btrim(p_query)::int))
  order by ci.year desc nulls last, ci.official_name_ru
  limit 40;
$$;

grant execute on function public.search_coins(text) to authenticated;
