class CatalogItem {
  final String id;
  final String? itemKind;
  final String? name;
  final String? catalogNumber;
  final int? year;
  final String? denomination;
  final String? metal;
  final double? weight;
  final double? diameter;
  final int? mintage;
  final String? photoUrl;
  final String? sourceCode;
  final String? sourceName;
  final int? modificationYear;
  final double? banknoteWidth;
  final double? banknoteHeight;
  final String? banknoteMaterial;
  final String? banknoteColors;
  final String? serialFormat;

  const CatalogItem({
    required this.id,
    this.itemKind,
    this.name,
    this.catalogNumber,
    this.year,
    this.denomination,
    this.metal,
    this.weight,
    this.diameter,
    this.mintage,
    this.photoUrl,
    this.sourceCode,
    this.sourceName,
    this.modificationYear,
    this.banknoteWidth,
    this.banknoteHeight,
    this.banknoteMaterial,
    this.banknoteColors,
    this.serialFormat,
  });

  factory CatalogItem.fromMap(Map<String, dynamic> map) {
    final source = map['source'];
    return CatalogItem(
      id: map['id'].toString(),
      itemKind: map['item_kind'] as String?,
      name: map['official_name_ru'] as String?,
      catalogNumber: map['catalog_number'] as String?,
      year: (map['year'] as num?)?.toInt(),
      denomination: map['denomination_text_ru'] as String?,
      metal: map['metal_text_ru'] as String?,
      weight: (map['weight_g'] as num?)?.toDouble(),
      diameter: (map['diameter_mm'] as num?)?.toDouble(),
      mintage: (map['mintage'] as num?)?.toInt(),
      photoUrl: map['photo_url'] as String?,
      sourceCode: source is Map ? source['code'] as String? : null,
      sourceName: source is Map ? source['name_ru'] as String? : null,
      modificationYear: (map['banknote_modification_year'] as num?)?.toInt(),
      banknoteWidth: (map['banknote_size_width_mm'] as num?)?.toDouble(),
      banknoteHeight: (map['banknote_size_height_mm'] as num?)?.toDouble(),
      banknoteMaterial: map['banknote_material'] as String?,
      banknoteColors: map['banknote_colors'] as String?,
      serialFormat: map['banknote_serial_format'] as String?,
    );
  }
}
