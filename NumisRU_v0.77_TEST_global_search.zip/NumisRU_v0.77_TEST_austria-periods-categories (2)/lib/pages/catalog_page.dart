import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/catalog_item.dart';
import '../models/banknote_model.dart';
import '../repositories/catalog_repository.dart';
import 'catalog_detail_page.dart';
import 'banknote_detail_page.dart';
import 'collection_page.dart';
import 'taxonomy_page.dart';
import 'banknote_page.dart';
import 'unified_recognition_page.dart';

class CatalogPage extends StatefulWidget {
  const CatalogPage({super.key});

  @override
  State<CatalogPage> createState() => _CatalogPageState();
}

class _CatalogPageState extends State<CatalogPage> {
  final searchController = TextEditingController();
  late final CatalogRepository? repository;
  Future<List<CatalogItem>>? future;

  @override
  void initState() {
    super.initState();
    repository = _hasSupabase ? CatalogRepository(Supabase.instance.client) : null;
    if (repository != null) {
      future = repository!.search();
    }
  }

  bool get _hasSupabase {
    try {
      return Supabase.instance.client.auth.currentSession != null ||
          Supabase.instance.client.rest.url.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _search() {
    if (repository == null) return;
    setState(() {
      future = repository!.search(
        query: searchController.text,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('NumisRU'),
        actions: [
          IconButton(tooltip: 'Банкноты', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BanknotePage())), icon: const Icon(Icons.payments_outlined)),
          IconButton(tooltip: 'Определить', onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const UnifiedRecognitionPage())), icon: const Icon(Icons.auto_awesome)),
          IconButton(
            tooltip: 'Справочник',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const TaxonomyPage()),
              );
            },
            icon: const Icon(Icons.account_tree_outlined),
          ),
          IconButton(
            tooltip: 'Моя коллекция',
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CollectionPage()),
              );
            },
            icon: const Icon(Icons.collections_bookmark_outlined),
          ),
          IconButton(
            tooltip: 'Обновить',
            onPressed: repository == null ? null : _search,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
            child: SearchBar(
              controller: searchController,
              hintText: 'Поиск по всем каталогам: название, номер, номинал',
              leading: const Icon(Icons.search),
              trailing: [
                IconButton(
                  onPressed: _search,
                  icon: const Icon(Icons.arrow_forward),
                ),
              ],
              onSubmitted: (_) => _search(),
            ),
          ),
          const SizedBox(height: 6),
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('Поиск выполняется по монетам и банкнотам из всех подключённых каталогов.'),
            ),
          ),
          const Divider(height: 1),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (repository == null) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Supabase ещё не подключён.\n\n'
            'Запустите приложение с --dart-define=SUPABASE_URL=... '
            'и --dart-define=SUPABASE_PUBLISHABLE_KEY=...',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    return FutureBuilder<List<CatalogItem>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Text('Ошибка загрузки: ${snapshot.error}'),
            ),
          );
        }

        final items = snapshot.data ?? [];
        if (items.isEmpty) {
          return const Center(child: Text('Ничего не найдено во всех каталогах'));
        }

        return ListView.builder(
          padding: const EdgeInsets.only(top: 8, bottom: 24),
          itemCount: items.length,
          itemBuilder: (_, index) => _CatalogResultCard(item: items[index]),
        );
      },
    );
  }
}

class _CatalogResultCard extends StatelessWidget {
  final CatalogItem item;

  const _CatalogResultCard({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          if (item.itemKind == 'banknote') {
            final banknote = BanknoteItem(
              id: item.id, name: item.name, denomination: item.denomination,
              year: item.year, modificationYear: item.modificationYear,
              catalogNumber: item.catalogNumber, sourceCode: item.sourceCode,
              sourceName: item.sourceName, width: item.banknoteWidth,
              height: item.banknoteHeight, material: item.banknoteMaterial,
              colors: item.banknoteColors, serialFormat: item.serialFormat,
              photoUrl: item.photoUrl,
            );
            Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => BanknoteDetailPage(item: banknote),
            ));
          } else {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => CatalogDetailPage(catalogItemId: item.id),
            ));
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: item.photoUrl == null
                    ? Icon(item.itemKind == 'banknote' ? Icons.payments_outlined : Icons.currency_exchange, size: 36)
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(
                          item.photoUrl!,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              const Icon(Icons.currency_exchange, size: 36),
                        ),
                      ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.name ?? 'Без названия',
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (item.year != null) _Chip('${item.year}'),
                        if (item.catalogNumber != null)
                          _Chip('№ ${item.catalogNumber}'),
                        if (item.denomination != null)
                          _Chip(item.denomination!),
                        if (item.sourceName != null) _Chip(item.sourceName!),
                        _Chip(item.itemKind == 'banknote' ? 'Банкнота' : 'Монета'),
                      ],
                    ),
                    if (item.metal != null) ...[
                      const SizedBox(height: 6),
                      Text(item.metal!),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  const _Chip(this.text);

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(text),
      visualDensity: VisualDensity.compact,
      padding: EdgeInsets.zero,
    );
  }
}
