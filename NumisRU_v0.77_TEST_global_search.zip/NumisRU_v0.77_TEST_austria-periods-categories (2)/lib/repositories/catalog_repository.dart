import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/catalog_item.dart';

class CatalogRepository {
  final SupabaseClient client;
  CatalogRepository(this.client);

  Future<List<CatalogItem>> search({
    String query = '',
    String? sourceCode,
    int limit = 100,
  }) async {
    dynamic request = client.from('catalog_items').select('''
      id, item_kind, official_name_ru, catalog_number, year,
      denomination_text_ru, metal_text_ru, weight_g, diameter_mm, mintage,
      banknote_modification_year, banknote_size_width_mm, banknote_size_height_mm,
      banknote_material, banknote_colors, banknote_serial_format,
      source:catalog_sources(code,name_ru)
    ''');

    final q = query.trim().replaceAll(',', ' ');
    if (q.isNotEmpty) {
      final clauses = <String>[
        'official_name_ru.ilike.%$q%',
        'catalog_number.ilike.%$q%',
        'denomination_text_ru.ilike.%$q%',
      ];
      if (RegExp(r'^\d{3,4}$').hasMatch(q)) clauses.add('year.eq.$q');
      request = request.or(clauses.join(','));
    }
    if (sourceCode != null && sourceCode.isNotEmpty) {
      request = request.eq('catalog_sources.code', sourceCode);
    }

    final rows = await request
        .order('year', ascending: false)
        .order('official_name_ru')
        .limit(limit);
    return (rows as List)
        .map((row) => CatalogItem.fromMap(Map<String, dynamic>.from(row)))
        .toList();
  }
}
