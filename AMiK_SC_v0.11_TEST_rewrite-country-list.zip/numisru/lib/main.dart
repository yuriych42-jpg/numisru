import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const AmikScOfflineApp());
    return;
  }
  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      if (Supabase.instance.client.auth.currentSession == null) {
        await Supabase.instance.client.auth.signInAnonymously();
      }
    } catch (_) {}
    runApp(const NumisRuApp());
  } catch (_) {
    runApp(const AmikScOfflineApp());
  }
}

ThemeData _appTheme() => ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174B63)),
  useMaterial3: true,
  cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6)),
);

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const HomeShell());
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [CatalogPage(), CollectionPage(), WishlistPage(), PortfolioPage(), ProfilePage()];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i) => setState(() => _index = i), destinations: _destinations));
}

class AmikScOfflineApp extends StatelessWidget {
  const AmikScOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const ContinentHomePage());
}

class _Region {
  final String name;
  final IconData icon;
  final List<String> countries;
  const _Region(this.name, this.icon, this.countries);
}

// Country/territory names are a first-pass grouping for navigation. The uCoin catalog
// includes current countries as well as historical issuers and territories; this list
// will be refined step-by-step in later versions.
const List<_Region> _regions = [
  _Region('Европа', Icons.account_balance, [
    'Австрия','Албания','Андорра','Беларусь','Бельгия','Болгария','Босния и Герцеговина','Ватикан','Великобритания','Венгрия','Германия','Греция','Дания','Ирландия','Исландия','Испания','Италия','Кипр','Косово','Латвия','Литва','Лихтенштейн','Люксембург','Мальта','Молдова','Монако','Нидерланды','Норвегия','Польша','Португалия','Россия','Румыния','Сан-Марино','Северная Македония','Сербия','Словакия','Словения','Турция','Украина','Финляндия','Франция','Хорватия','Черногория','Чехия','Швейцария','Швеция','Эстония'
  ]),
  _Region('Азия', Icons.temple_buddhist, [
    'Азербайджан','Армения','Афганистан','Бангладеш','Бахрейн','Бруней','Бутан','Вьетнам','Грузия','Израиль','Индия','Индонезия','Иордания','Ирак','Иран','Йемен','Казахстан','Камбоджа','Катар','Кипр','Китай','КНДР','Кувейт','Кыргызстан','Лаос','Ливан','Малайзия','Мальдивы','Монголия','Мьянма','Непал','ОАЭ','Оман','Пакистан','Палестина','Саудовская Аравия','Сингапур','Сирия','Таджикистан','Таиланд','Тайвань','Тимор-Лесте','Туркменистан','Турция','Узбекистан','Филиппины','Шри-Ланка','Южная Корея','Япония'
  ]),
  _Region('Африка', Icons.wb_sunny_outlined, [
    'Алжир','Ангола','Бенин','Ботсвана','Буркина-Фасо','Бурунди','Габон','Гамбия','Гана','Гвинея','Гвинея-Бисау','Демократическая Республика Конго','Джибути','Египет','Замбия','Западная Сахара','Зимбабве','Кабо-Верде','Камерун','Кения','Коморы','Кот-д’Ивуар','Лесото','Либерия','Ливия','Маврикий','Мавритания','Мадагаскар','Малави','Мали','Марокко','Мозамбик','Намибия','Нигер','Нигерия','Республика Конго','Руанда','Сан-Томе и Принсипи','Сейшелы','Сенегал','Сомали','Судан','Сьерра-Леоне','Танзания','Того','Тунис','Уганда','Центральноафриканская Республика','Чад','Экваториальная Гвинея','Эритрея','Эсватини','Эфиопия','ЮАР','Южный Судан'
  ]),
  _Region('Северная Америка', Icons.landscape_outlined, [
    'Антигуа и Барбуда','Багамы','Барбадос','Белиз','Гаити','Гватемала','Гондурас','Гренада','Доминика','Доминиканская Республика','Канада','Коста-Рика','Куба','Мексика','Никарагуа','Панама','Сальвадор','Сент-Винсент и Гренадины','Сент-Китс и Невис','Сент-Люсия','США','Тринидад и Тобаго','Ямайка'
  ]),
  _Region('Южная Америка', Icons.public, [
    'Аргентина','Боливия','Бразилия','Венесуэла','Гайана','Колумбия','Парагвай','Перу','Суринам','Уругвай','Чили','Эквадор','Французская Гвиана'
  ]),
  _Region('Австралия и Океания', Icons.sailing, [
    'Австралия','Вануату','Кирибати','Маршалловы Острова','Микронезия','Науру','Новая Зеландия','Палау','Папуа — Новая Гвинея','Самоа','Соломоновы Острова','Тонга','Тувалу','Фиджи','Французская Полинезия','Американское Самоа','Гуам','Новая Каледония','Острова Кука'
  ]),
  _Region('Исчезнувшие страны', Icons.history_edu, [
    'Австро-Венгрия','Византийская империя','ГДР','Западная Германия','Османская империя','Пруссия','Римская империя','Российская империя','РСФСР','Советский Союз','Югославия','Чехословакия','Королевство Италия','Королевство Пруссия','Веймарская республика'
  ]),
  _Region('Непризнанные территории', Icons.public_off, [
    'Абхазия','Арцах / Нагорный Карабах','Косово','Приднестровье','Северный Кипр','Сомалиленд','Тайвань','Южная Осетия','Западная Сахара','Себорга'
  ]),
  _Region('Избранное', Icons.star_border, []),
];

class ContinentHomePage extends StatelessWidget {
  const ContinentHomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('АМиК SC'), centerTitle: false),
    body: Column(children: [
      Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(12, 8, 12, 4), padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(14)),
        child: const Text('ТЕСТОВАЯ ВЕРСИЯ · Выберите часть света или раздел. Список стран будет уточняться поэтапно.')),
      Expanded(child: GridView.builder(
        padding: const EdgeInsets.all(8), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemCount: _regions.length,
        itemBuilder: (context, index) {
          final region = _regions[index];
          return Card(clipBehavior: Clip.antiAlias, child: InkWell(onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => CountryListPage(region: region))),
            child: Padding(padding: const EdgeInsets.all(10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(region.icon, size: 30, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8),
              Text(region.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
              if (region.name != 'Избранное') Text('${region.countries.length} позиций', style: Theme.of(context).textTheme.labelSmall),
            ]))));
        }))
    ]));
}

class CountryListPage extends StatefulWidget {
  final _Region region;
  const CountryListPage({super.key, required this.region});
  @override
  State<CountryListPage> createState() => _CountryListPageState();
}
class _CountryListPageState extends State<CountryListPage> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final countries = widget.region.countries.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList()..sort((a,b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(appBar: AppBar(title: Text(widget.region.name)), body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SearchBar(leading: const Icon(Icons.search), hintText: 'Поиск страны или территории', onChanged: (v) => setState(() => query = v),)),
      Expanded(
        child: widget.region.name == 'Избранное'
            ? const Center(child: Text('Избранное пока пусто'))
            : countries.isEmpty
                ? const Center(child: Text('Ничего не найдено'))
                : ListView.separated(
                    itemCount: countries.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      return ListTile(
                        leading: const Icon(Icons.flag_outlined),
                        title: Text(countries[index]),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () {
                          showDialog<void>(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: Text(countries[index]),
                              content: const Text(
                                'На следующем этапе сюда будет подключён каталог этой страны на uCoin.',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('Закрыть'),
                                ),
                              ],
                            ),
                          );
                        },
                      );
                    },
                  ),
      ),
    ]));
  }
}
