-- NumisRU v0.85.0: verified starter set for the Russia coin catalog.
-- Source: official Bank of Russia coin database and its 2024/2025/2026 result pages.
-- This is a starter set, not a claim of complete coverage of all Russian coins.
-- Apply after 018_coin_issue_types.sql.

do $$
declare
  src uuid;
  r record;
begin
  select id into src from public.catalog_sources where code = 'cbr_ru_coins';
  if src is null then
    insert into public.catalog_sources(code, name_ru, base_url, scope_code, authority_level, license_note, is_active)
    values ('cbr_ru_coins', 'Банк России — памятные и инвестиционные монеты',
      'https://www.cbr.ru/cash_circulation/memorable_coins/coins_base/',
      'rf_1992_present', 'official',
      'Официальные сведения Банка России; перед зеркалированием изображений проверить условия использования.', true)
    on conflict (code) do update set is_active = true
    returning id into src;
  end if;

  for r in select * from (values
    ('5110-0200-2026','5110-0200',2026,'Скульптор С. Д. Эрьзя, к 150-летию со дня рождения','2 рубля','серебро 925/1000','2026-09-08'::date,'commemorative'),
    ('5110-0196-2026','5110-0196',2026,'Первый Президент Чеченской Республики Ахмат-Хаджи Абдулхамидович Кадыров, к 75-летию со дня рождения','2 рубля','серебро 925/1000','2026-07-14'::date,'commemorative'),
    ('5110-0195-2026','5110-0195',2026,'Хирург Н. Н. Бурденко, к 150-летию со дня рождения','2 рубля','серебро 925/1000','2026-05-22'::date,'commemorative'),
    ('5110-0192-2026','5110-0192',2026,'Писатель М. Е. Салтыков-Щедрин, к 200-летию со дня рождения','2 рубля','серебро 925/1000','2026-01-20'::date,'commemorative'),
    ('5015-0082-2026','5015-0082',2026,'Спартак','25 рублей','медно-никелевый сплав','2026-07-01'::date,'commemorative'),
    ('5015-0083-2026','5015-0083',2026,'Трудовые резервы','25 рублей','медно-никелевый сплав','2026-07-01'::date,'commemorative'),
    ('5111-0178-2025','5111-0178',2025,'Георгий Победоносец','3 рубля','серебро 999/1000','2025-01-10'::date,'investment'),
    ('5216-0060-2025','5216-0060',2025,'Георгий Победоносец','50 рублей','золото 999/1000','2025-01-10'::date,'investment'),
    ('5217-0048-2025','5217-0048',2025,'Георгий Победоносец','100 рублей','золото 999/1000','2025-09-30'::date,'investment'),
    ('5219-0033-2025','5219-0033',2025,'Георгий Победоносец','200 рублей','золото 999/1000','2025-09-30'::date,'investment'),
    ('5221-0036-2025','5221-0036',2025,'Георгий Победоносец','10 000 рублей','золото 999/1000','2025-10-28'::date,'investment'),
    ('5219-0035-2024','5219-0035',2024,'Атомный ледокол «Сибирь»','200 рублей','золото 999/1000','2024-03-12'::date,'commemorative'),
    ('5221-0035-2024','5221-0035',2024,'225-летие со дня рождения А. С. Пушкина','10 000 рублей','золото 999/1000','2024-05-14'::date,'commemorative')
  ) as v(ext_id,cat_no,yr,title,denom,metal,issued,kind)
  loop
    insert into public.catalog_items(
      source_id, source_external_id, item_kind, year, official_name_ru,
      denomination_text_ru, catalog_number, metal_text_ru, issue_date,
      issue_type, official_url, source_updated_at
    ) values (
      src, r.ext_id, 'coin'::public.item_kind, r.yr,
      r.title || ' — ' || r.denom || ', ' || r.yr || ' г.',
      r.denom, r.cat_no, r.metal, r.issued,
      r.kind,
      'https://www.cbr.ru/cash_circulation/memorable_coins/coins_base/', now()
    )
    on conflict (source_id, source_external_id) do update set
      year = excluded.year,
      official_name_ru = excluded.official_name_ru,
      denomination_text_ru = excluded.denomination_text_ru,
      catalog_number = excluded.catalog_number,
      metal_text_ru = excluded.metal_text_ru,
      issue_date = excluded.issue_date,
      issue_type = excluded.issue_type,
      official_url = excluded.official_url,
      source_updated_at = excluded.source_updated_at;
  end loop;
end $$;
