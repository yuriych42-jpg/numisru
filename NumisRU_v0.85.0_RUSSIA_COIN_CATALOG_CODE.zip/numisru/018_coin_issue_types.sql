-- NumisRU v0.84.11: classification for circulation and special-issue coins.
-- Additive migration: existing catalog rows and features are preserved.

alter table public.catalog_items
  add column if not exists issue_type text;

alter table public.catalog_items
  drop constraint if exists catalog_items_issue_type_check;

alter table public.catalog_items
  add constraint catalog_items_issue_type_check
  check (issue_type is null or issue_type in ('regular', 'commemorative', 'investment', 'other'));

create index if not exists idx_catalog_items_issue_type
  on public.catalog_items(issue_type);

comment on column public.catalog_items.issue_type is
  'Тип выпуска: regular — регулярный чекан; commemorative — памятная; investment — инвестиционная; other — прочее. NULL означает, что тип ещё не подтверждён источником.';
