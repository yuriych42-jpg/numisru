# NumisRU v0.83 TEST

- Replaced guessed Austrian euro commemorative/collector denomination-year slots with coin rows read from the selected uCoin category page.
- Added search by coin name, denomination, year and catalogue number; per-coin quantities and JSON export remain available.
- Bumped app version to 0.83.0+83.
- The archive's embedded workflow fallback accepts `NumisRU_v*_CODE*.zip` names, including `_fixed.zip`.

Note: a Flutter/Android build was not run in this environment. Verify the GitHub Actions build before distributing an APK.
