# NumisRU v0.07 TEST — offline start

- App now opens into a demonstration interface if Supabase URL/key are not configured.
- Demo catalog includes sample coin and banknote records with simple search.
- Collection, favorites, statistics and profile tabs show demo placeholders.
- Demo changes are not saved. Live catalog and cloud sync still require Supabase configuration.
