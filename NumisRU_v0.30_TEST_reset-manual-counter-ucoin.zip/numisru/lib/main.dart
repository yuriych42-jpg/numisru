import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:country_flags/country_flags.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const AmikScOfflineApp());
    return;
  }
  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      if (Supabase.instance.client.auth.currentSession == null) {
        await Supabase.instance.client.auth.signInAnonymously();
      }
    } catch (_) {}
    runApp(const NumisRuApp());
  } catch (_) {
    runApp(const AmikScOfflineApp());
  }
}

ThemeData _appTheme() => ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174B63)),
  useMaterial3: true,
  cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6)),
);

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const HomeShell());
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [CatalogPage(), CollectionPage(), WishlistPage(), PortfolioPage(), ProfilePage()];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i) => setState(() => _index = i), destinations: _destinations));
}

class AmikScOfflineApp extends StatelessWidget {
  const AmikScOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const OfflineHomeShell());
}

class OfflineHomeShell extends StatefulWidget {
  const OfflineHomeShell({super.key});
  @override
  State<OfflineHomeShell> createState() => _OfflineHomeShellState();
}

class _OfflineHomeShellState extends State<OfflineHomeShell> {
  int _index = 0;

  static const _destinations = <NavigationDestination>[
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const ContinentHomePage(),
      const _OfflinePlaceholderPage(title: 'Коллекция', icon: Icons.collections_bookmark_outlined,
          message: 'Раздел коллекции будет подключён на следующем этапе.'),
      const _OfflinePlaceholderPage(title: 'Избранное', icon: Icons.bookmark_border,
          message: 'Избранное будет доступно после подключения сохранения монет.'),
      const _OfflinePlaceholderPage(title: 'Статистика', icon: Icons.insights_outlined,
          message: 'Статистика коллекции появится, когда будет доступен учёт собранных монет.'),
      const _OfflinePlaceholderPage(title: 'Профиль', icon: Icons.person_outline,
          message: 'Профиль будет подключён на следующем этапе.'),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: _destinations,
      ),
    );
  }
}

class _OfflinePlaceholderPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String message;
  const _OfflinePlaceholderPage({required this.title, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 52, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(message, textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}

class _Region {
  final String name;
  final IconData icon;
  final List<String> countries;
  const _Region(this.name, this.icon, this.countries);
}

// Country/territory names are a first-pass grouping for navigation. The uCoin catalog
// includes current countries as well as historical issuers and territories; this list
// will be refined step-by-step in later versions.
const List<_Region> _regions = [
  _Region('Европа', Icons.account_balance, [
    'Австрия','Албания','Андорра','Беларусь','Бельгия','Болгария','Босния и Герцеговина','Ватикан','Великобритания','Венгрия','Германия','Греция','Дания','Ирландия','Исландия','Испания','Италия','Кипр','Косово','Латвия','Литва','Лихтенштейн','Люксембург','Мальта','Молдова','Монако','Нидерланды','Норвегия','Польша','Португалия','Россия','Румыния','Сан-Марино','Северная Македония','Сербия','Словакия','Словения','Турция','Украина','Финляндия','Франция','Хорватия','Черногория','Чехия','Швейцария','Швеция','Эстония'
  ]),
  _Region('Азия', Icons.temple_buddhist, [
    'Азербайджан','Армения','Афганистан','Бангладеш','Бахрейн','Бруней','Бутан','Вьетнам','Грузия','Израиль','Индия','Индонезия','Иордания','Ирак','Иран','Йемен','Казахстан','Камбоджа','Катар','Кипр','Китай','КНДР','Кувейт','Кыргызстан','Лаос','Ливан','Малайзия','Мальдивы','Монголия','Мьянма','Непал','ОАЭ','Оман','Пакистан','Палестина','Саудовская Аравия','Сингапур','Сирия','Таджикистан','Таиланд','Тайвань','Тимор-Лесте','Туркменистан','Турция','Узбекистан','Филиппины','Шри-Ланка','Южная Корея','Япония'
  ]),
  _Region('Африка', Icons.wb_sunny_outlined, [
    'Алжир','Ангола','Бенин','Ботсвана','Буркина-Фасо','Бурунди','Габон','Гамбия','Гана','Гвинея','Гвинея-Бисау','Демократическая Республика Конго','Джибути','Египет','Замбия','Западная Сахара','Зимбабве','Кабо-Верде','Камерун','Кения','Коморы','Кот-д’Ивуар','Лесото','Либерия','Ливия','Маврикий','Мавритания','Мадагаскар','Малави','Мали','Марокко','Мозамбик','Намибия','Нигер','Нигерия','Республика Конго','Руанда','Сан-Томе и Принсипи','Сейшелы','Сенегал','Сомали','Судан','Сьерра-Леоне','Танзания','Того','Тунис','Уганда','Центральноафриканская Республика','Чад','Экваториальная Гвинея','Эритрея','Эсватини','Эфиопия','ЮАР','Южный Судан'
  ]),
  _Region('Северная Америка', Icons.landscape_outlined, [
    'Антигуа и Барбуда','Багамы','Барбадос','Белиз','Гаити','Гватемала','Гондурас','Гренада','Доминика','Доминиканская Республика','Канада','Коста-Рика','Куба','Мексика','Никарагуа','Панама','Сальвадор','Сент-Винсент и Гренадины','Сент-Китс и Невис','Сент-Люсия','США','Тринидад и Тобаго','Ямайка'
  ]),
  _Region('Южная Америка', Icons.public, [
    'Аргентина','Боливия','Бразилия','Венесуэла','Гайана','Колумбия','Парагвай','Перу','Суринам','Уругвай','Чили','Эквадор','Французская Гвиана'
  ]),
  _Region('Австралия и Океания', Icons.sailing, [
    'Австралия','Вануату','Кирибати','Маршалловы Острова','Микронезия','Науру','Новая Зеландия','Палау','Папуа — Новая Гвинея','Самоа','Соломоновы Острова','Тонга','Тувалу','Фиджи','Французская Полинезия','Американское Самоа','Гуам','Новая Каледония','Острова Кука'
  ]),
  _Region('Исчезнувшие страны', Icons.history_edu, [
    'Австро-Венгрия','Византийская империя','ГДР','Западная Германия','Османская империя','Пруссия','Римская империя','Российская империя','РСФСР','Советский Союз','Югославия','Чехословакия','Королевство Италия','Королевство Пруссия','Веймарская республика'
  ]),
  _Region('Непризнанные территории', Icons.public_off, [
    'Абхазия','Арцах / Нагорный Карабах','Косово','Приднестровье','Северный Кипр','Сомалиленд','Тайвань','Южная Осетия','Западная Сахара','Себорга'
  ]),
  _Region('Мой каталог', Icons.star_border, []),
];

const String _myCatalogCountriesKey = 'my_catalog_countries_v1';
const String _myCatalogNameKey = 'my_catalog_name_v1';
const String _defaultMyCatalogName = 'Мой каталог';

class ContinentHomePage extends StatefulWidget {
  const ContinentHomePage({super.key});
  @override
  State<ContinentHomePage> createState() => _ContinentHomePageState();
}

class _ContinentHomePageState extends State<ContinentHomePage> {
  String _myCatalogName = _defaultMyCatalogName;
  List<String> _myCountries = [];
  Timer? _holdTimer;
  bool _renameDialogOpened = false;

  @override
  void initState() {
    super.initState();
    _loadCustomData();
  }

  Future<void> _loadCustomData() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _myCatalogName = prefs.getString(_myCatalogNameKey) ?? _defaultMyCatalogName;
      _myCountries = prefs.getStringList(_myCatalogCountriesKey) ?? [];
    });
  }

  Future<void> _renameCatalog() async {
    final controller = TextEditingController(text: _myCatalogName);
    final newName = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Переименовать плитку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Название плитки'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    controller.dispose();
    if (newName == null || newName.trim().isEmpty || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_myCatalogNameKey, newName.trim());
    if (mounted) setState(() => _myCatalogName = newName.trim());
  }

  void _startHoldRename() {
    _holdTimer?.cancel();
    _renameDialogOpened = false;
    _holdTimer = Timer(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      _renameDialogOpened = true;
      _renameCatalog();
    });
  }

  void _cancelHold() => _holdTimer?.cancel();

  Future<void> _openRegion(_Region region) async {
    final customRegion = region.name == 'Мой каталог'
        ? _Region(_myCatalogName, region.icon, List<String>.from(_myCountries))
        : region;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => CountryListPage(
        region: customRegion,
        isMyCatalog: region.name == 'Мой каталог',
      ),
    ));
    await _loadCustomData();
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('АМиК SC'), centerTitle: false, actions: [IconButton(tooltip: 'Настройки', icon: const Icon(Icons.settings), onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AppSettingsPage())))]),
    body: Column(children: [
      Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(12, 8, 12, 4), padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(14)),
        child: const Text('ТЕСТОВАЯ ВЕРСИЯ · Выберите часть света или раздел. Удерживайте плитку «Мой каталог» 1,5 секунды, чтобы переименовать её.')),
      Expanded(child: GridView.builder(
        padding: const EdgeInsets.all(8), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemCount: _regions.length,
        itemBuilder: (context, index) {
          final region = _regions[index];
          final isMyCatalog = region.name == 'Мой каталог';
          final title = isMyCatalog ? _myCatalogName : region.name;
          final count = isMyCatalog ? _myCountries.length : region.countries.length;
          return Card(clipBehavior: Clip.antiAlias, child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: isMyCatalog ? (_) => _startHoldRename() : null,
            onTapUp: isMyCatalog ? (_) => _cancelHold() : null,
            onTapCancel: isMyCatalog ? _cancelHold : null,
            onTap: () {
              if (isMyCatalog && _renameDialogOpened) {
                _renameDialogOpened = false;
                return;
              }
              _cancelHold();
              _openRegion(region);
            },
            child: Padding(padding: const EdgeInsets.all(10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(region.icon, size: 30, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text('$count стран', style: Theme.of(context).textTheme.labelSmall),
            ])),
          ));
        }))
    ]));
}

// ISO 3166-1 alpha-2 codes used to render actual country flag artwork.
const Map<String, String> _countryIsoCodes = {
  'Албания':'AL', 'Андорра':'AD', 'Австрия':'AT', 'Беларусь':'BY', 'Белоруссия':'BY',
  'Бельгия':'BE', 'Болгария':'BG', 'Босния и Герцеговина':'BA', 'Ватикан':'VA',
  'Великобритания':'GB', 'Венгрия':'HU', 'Германия':'DE', 'Греция':'GR', 'Дания':'DK',
  'Ирландия':'IE', 'Исландия':'IS', 'Испания':'ES', 'Италия':'IT', 'Кипр':'CY',
  'Косово':'XK', 'Латвия':'LV', 'Литва':'LT', 'Лихтенштейн':'LI', 'Люксембург':'LU',
  'Мальта':'MT', 'Молдова':'MD', 'Монако':'MC', 'Нидерланды':'NL', 'Норвегия':'NO',
  'Польша':'PL', 'Португалия':'PT', 'Россия':'RU', 'Румыния':'RO', 'Сан-Марино':'SM',
  'Северная Македония':'MK', 'Сербия':'RS', 'Словакия':'SK', 'Словения':'SI',
  'Турция':'TR', 'Украина':'UA', 'Финляндия':'FI', 'Франция':'FR', 'Хорватия':'HR',
  'Черногория':'ME', 'Чехия':'CZ', 'Швейцария':'CH', 'Швеция':'SE', 'Эстония':'EE',
  'Азербайджан':'AZ', 'Армения':'AM', 'Афганистан':'AF', 'Бангладеш':'BD', 'Бахрейн':'BH',
  'Бруней':'BN', 'Бутан':'BT', 'Вьетнам':'VN', 'Грузия':'GE', 'Израиль':'IL', 'Индия':'IN',
  'Индонезия':'ID', 'Иордания':'JO', 'Ирак':'IQ', 'Иран':'IR', 'Йемен':'YE', 'Казахстан':'KZ',
  'Камбоджа':'KH', 'Катар':'QA', 'Китай':'CN', 'КНДР':'KP', 'Кувейт':'KW', 'Кыргызстан':'KG',
  'Лаос':'LA', 'Ливан':'LB', 'Малайзия':'MY', 'Мальдивы':'MV', 'Монголия':'MN', 'Мьянма':'MM',
  'Непал':'NP', 'ОАЭ':'AE', 'Оман':'OM', 'Пакистан':'PK', 'Палестина':'PS',
  'Саудовская Аравия':'SA', 'Сингапур':'SG', 'Сирия':'SY', 'Таджикистан':'TJ', 'Таиланд':'TH',
  'Тайвань':'TW', 'Тимор-Лесте':'TL', 'Туркменистан':'TM', 'Узбекистан':'UZ',
  'Филиппины':'PH', 'Шри-Ланка':'LK', 'Южная Корея':'KR', 'Япония':'JP',
  'Алжир':'DZ', 'Ангола':'AO', 'Бенин':'BJ', 'Ботсвана':'BW', 'Буркина-Фасо':'BF',
  'Бурунди':'BI', 'Габон':'GA', 'Гамбия':'GM', 'Гана':'GH', 'Гвинея':'GN',
  'Гвинея-Бисау':'GW', 'Джибути':'DJ', 'Египет':'EG', 'Замбия':'ZM', 'Зимбабве':'ZW',
  'Кабо-Верде':'CV', 'Камерун':'CM', 'Кения':'KE', 'Коморы':'KM', 'Лесото':'LS',
  'Либерия':'LR', 'Ливия':'LY', 'Маврикий':'MU', 'Мавритания':'MR', 'Мадагаскар':'MG',
  'Малави':'MW', 'Мали':'ML', 'Марокко':'MA', 'Мозамбик':'MZ', 'Намибия':'NA',
  'Нигер':'NE', 'Нигерия':'NG', 'Руанда':'RW', 'Сейшелы':'SC', 'Сенегал':'SN',
  'Сомали':'SO', 'Судан':'SD', 'Сьерра-Леоне':'SL', 'Танзания':'TZ', 'Того':'TG',
  'Тунис':'TN', 'Уганда':'UG', 'Чад':'TD', 'Эритрея':'ER', 'Эсватини':'SZ',
  'Эфиопия':'ET', 'ЮАР':'ZA', 'Южный Судан':'SS',
  'Антигуа и Барбуда':'AG', 'Багамы':'BS', 'Барбадос':'BB', 'Белиз':'BZ', 'Гаити':'HT',
  'Гватемала':'GT', 'Гондурас':'HN', 'Гренада':'GD', 'Доминика':'DM',
  'Доминиканская Республика':'DO', 'Канада':'CA', 'Коста-Рика':'CR', 'Куба':'CU',
  'Мексика':'MX', 'Никарагуа':'NI', 'Панама':'PA', 'Сальвадор':'SV', 'США':'US',
  'Тринидад и Тобаго':'TT', 'Ямайка':'JM', 'Аргентина':'AR', 'Боливия':'BO',
  'Бразилия':'BR', 'Венесуэла':'VE', 'Гайана':'GY', 'Колумбия':'CO', 'Парагвай':'PY',
  'Перу':'PE', 'Суринам':'SR', 'Уругвай':'UY', 'Чили':'CL', 'Эквадор':'EC',
  'Австралия':'AU', 'Вануату':'VU', 'Кирибати':'KI', 'Маршалловы Острова':'MH',
  'Микронезия':'FM', 'Науру':'NR', 'Новая Зеландия':'NZ', 'Палау':'PW',
  'Папуа — Новая Гвинея':'PG', 'Самоа':'WS', 'Соломоновы Острова':'SB', 'Тонга':'TO',
  'Тувалу':'TV', 'Фиджи':'FJ', 'Гуам':'GU', 'Новая Каледония':'NC', 'Острова Кука':'CK',
  'Абхазия':'GE',
};

Widget _countryFlag(String country) {
  final code = _countryIsoCodes[country];
  if (code == null) return const SizedBox(width: 36, height: 24, child: Icon(Icons.flag_outlined));
  return ClipRRect(
    borderRadius: BorderRadius.circular(3),
    child: CountryFlag.fromCountryCode(
      code,
      theme: const ImageTheme(width: 36, height: 24),
    ),
  );
}

class CountryListPage extends StatefulWidget {
  final _Region region;
  final bool isMyCatalog;
  const CountryListPage({super.key, required this.region, this.isMyCatalog = false});
  @override
  State<CountryListPage> createState() => _CountryListPageState();
}

class _CountryListPageState extends State<CountryListPage> {
  String query = '';
  late List<String> _myCountries;

  @override
  void initState() {
    super.initState();
    _myCountries = List<String>.from(widget.region.countries);
    _loadMyCountries();
  }

  Future<void> _loadMyCountries() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _myCountries = prefs.getStringList(_myCatalogCountriesKey) ?? []);
  }

  Future<void> _toggleMyCountry(String country) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_myCatalogCountriesKey) ?? [];
    final alreadyAdded = list.contains(country);
    if (widget.isMyCatalog) {
      list.remove(country);
    } else if (alreadyAdded) {
      list.remove(country);
    } else {
      list.add(country);
    }
    await prefs.setStringList(_myCatalogCountriesKey, list);
    if (!mounted) return;
    setState(() => _myCountries = list);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(widget.isMyCatalog ? 'Страна удалена из Мой каталог' : alreadyAdded ? 'Страна удалена из Мой каталог' : 'Страна добавлена в Мой каталог'),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final sourceCountries = widget.isMyCatalog ? _myCountries : widget.region.countries;
    final countries = sourceCountries.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList()
      ..sort((a,b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(appBar: AppBar(title: Text(widget.region.name)), body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SearchBar(leading: const Icon(Icons.search), hintText: 'Поиск страны или территории', onChanged: (v) => setState(() => query = v),)),
      Expanded(
        child: countries.isEmpty
            ? Center(child: Text(widget.isMyCatalog ? 'Список пуст. Откройте часть света и нажмите + у нужных стран.' : 'Ничего не найдено', textAlign: TextAlign.center))
            : ListView.separated(
                itemCount: countries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final country = countries[index];
                  final isAdded = _myCountries.contains(country);
                  return ListTile(
                    leading: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: country == 'Австрия' ? () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AustriaInfoPage())) : null,
                      child: Padding(padding: const EdgeInsets.all(4), child: _countryFlag(country)),
                    ),
                    title: Text(country),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        tooltip: widget.isMyCatalog ? 'Удалить из моего каталога' : isAdded ? 'Уже в моём каталоге — удалить' : 'Добавить в Мой каталог',
                        icon: Icon(widget.isMyCatalog ? Icons.remove_circle_outline : isAdded ? Icons.check_circle : Icons.add_circle_outline),
                        onPressed: () => _toggleMyCountry(country),
                      ),
                      const Icon(Icons.chevron_right),
                    ]),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => country == 'Австрия' ? const AustriaPeriodsPage() : UcoinCountryPage(country: country))),
                  );
                },
              ),
      ),
    ]));
  }
}



const List<_AustriaPeriod> _austriaPeriods = [
  _AustriaPeriod('Европейский союз (Евро)', '2002 - 2026', 311),
  _AustriaPeriod('ЭКЮ', '1979 - 1998', 759),
  _AustriaPeriod('Вторая Республика', '1946 - 2001', 0),
  _AustriaPeriod('Первая Республика (Шиллинг)', '1925 - 1938', 0),
  _AustriaPeriod('Первая Республика (Крона)', '1923 - 1924', 0),
  _AustriaPeriod('Австро-венгерская крона', '1892 - 1918', 0),
  _AustriaPeriod('Австро-венгерский гульден', '1857 - 1892', 0),
  _AustriaPeriod('Австрийская империя', '1806 - 1857', 0),
  _AustriaPeriod('Священная Римская империя (Крейцер)', '1741 - 1806', 0),
  _AustriaPeriod('Священная Римская империя (Талер)', '1741 - 1805', 0),
  _AustriaPeriod('Священная Римская империя', '1705 - 1740', 0),
  _AustriaPeriod('Священная Римская империя', '1658 - 1704', 0),
  _AustriaPeriod('Священная Римская империя', '1608 - 1657', 0),
  _AustriaPeriod('Священная Римская империя', '1520 - 1607', 0),
];
class _AustriaPeriod { final String name, years; final int ucoinId; const _AustriaPeriod(this.name, this.years, this.ucoinId); }

class AustriaPeriodsPage extends StatefulWidget {
  const AustriaPeriodsPage({super.key});
  @override State<AustriaPeriodsPage> createState() => _AustriaPeriodsPageState();
}

class _AustriaPeriodsPageState extends State<AustriaPeriodsPage> {
  Map<String, int> _ownedByPeriod = {};
  @override void initState() { super.initState(); _loadPeriodCounts(); }
  Future<void> _loadPeriodCounts() async {
    final prefs = await SharedPreferences.getInstance();
    final result = <String, int>{};
    for (final period in _austriaPeriods) {
      final key = 'austria_coin_counts_v2_${period.years}_${period.name}';
      final raw = prefs.getString(key);
      if (raw == null) { result[key] = 0; continue; }
      try {
        final data = jsonDecode(raw) as Map<String, dynamic>;
        result[key] = data.values.where((value) => value is num && value > 0).length;
      } catch (_) { result[key] = 0; }
    }
    if (mounted) setState(() => _ownedByPeriod = result);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Австрия — периоды')),
    body: ListView(padding: const EdgeInsets.all(8), children: [
      const Padding(padding: EdgeInsets.all(8), child: Text('Исторические периоды по каталогу uCoin. Для работы без интернета сохраните каталог кнопкой загрузки рядом с периодом.', style: TextStyle(fontSize: 13))),
      for (final p in _austriaPeriods) Card(child: ListTile(
        title: Text(p.name), subtitle: Text(p.name == 'Европейский союз (Евро)' ? '${p.years}  ·  ${_austriaEuroCoinsByYear().length}/${_ownedByPeriod['austria_coin_counts_v2_${p.years}_${p.name}'] ?? 0}' : '${p.years}  ·  0/0'),
        leading: const Icon(Icons.history),
        trailing: IconButton(tooltip: 'Сохранить каталог для работы офлайн', icon: const Icon(Icons.download_for_offline_outlined), onPressed: () async {
          try { final dir = await _saveAustriaPeriod(p); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Каталог сохранён: $dir'))); }
          catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e'))); }
        }),
        onTap: () async { await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AustriaCoinsPage(period: p))); await _loadPeriodCounts(); },
      )),
      const Padding(padding: EdgeInsets.all(8), child: Text('Источник периодов: ru.ucoin.net/catalog/?country=austria', style: TextStyle(fontSize: 12, color: Colors.black54))),
    ]));
}

// The left period counter is derived from the actual in-app list below, not a hard-coded example.

const _euroDenominations = <_AustriaCoin>[
  _AustriaCoin('1 евроцент', '', 'KM# 3082', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евроцента', '', 'KM# 3083', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('5 евроцентов', '', 'KM# 3084', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('10 евроцентов', '', 'KM# 3085 / 3139', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('20 евроцентов', '', 'KM# 3086 / 3140', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('50 евроцентов', '', 'KM# 3087 / 3141', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('1 евро', '', 'KM# 3088 / 3142', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евро', '', 'KM# 3089 / 3143', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
];
List<_AustriaCoin> _austriaEuroCoinsByYear() => [
  for (var year = 2002; year <= 2026; year++)
    for (final denomination in _euroDenominations)
      _AustriaCoin(denomination.denomination, '$year', denomination.km, denomination.url),
];
int _euroDenominationOrder(String value) { const order=['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро']; final i=order.indexOf(value); return i < 0 ? order.length : i; }
List<String> _austriaEuroDenominations() => const ['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро'];
class _AustriaCoin { final String denomination, years, km, url; const _AustriaCoin(this.denomination,this.years,this.km,this.url); String get reverseImageUrl { switch (denomination) { case '1 евроцент': return 'https://i.ucoin.net/coin/49/394/49394453-2/austria-1-euro-cent-2012.jpg'; case '1 евро': return 'https://i.ucoin.net/coin/66/799/66799270-2/austria-1-euro-2011.jpg'; default: return 'https://ru.ucoin.net/catalog/?country=austria&period=311'; } } }

Future<String> _saveAustriaPeriod(_AustriaPeriod p) async {
  final prefs = await SharedPreferences.getInstance();
  final chosen = prefs.getString('catalog_save_directory_v1');
  Directory base;
  if (chosen != null && chosen.isNotEmpty) { base = Directory(chosen); if (!await base.exists()) await base.create(recursive: true); }
  else { base = await getApplicationDocumentsDirectory(); }
  final safe = '${p.name}_${p.years}'.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё0-9_-]+'), '_');
  final out = Directory('${base.path}/Австрия_$safe'); await out.create(recursive: true);
  final coins = p.name == 'Европейский союз (Евро)' ? _austriaEuroCoinsByYear().map((c) => {'номинал':c.denomination,'год выпуска':c.years,'каталожный номер':c.km,'источник':c.url}).toList() : <Map<String,String>>[];
  final data = {'страна':'Австрия','период':p.name,'годы':p.years,'источник':'https://ru.ucoin.net/catalog/?country=austria${p.ucoinId > 0 ? '&period=${p.ucoinId}' : ''}','монеты':coins,'примечание': coins.isEmpty ? 'Список монет этого исторического периода пока не загружен в приложение.' : 'Каждая комбинация номинала и года вынесена в отдельную строку. Сверяйте фактический выпуск конкретного года с данными uCoin.'};
  await File('${out.path}/catalog.json').writeAsString(const JsonEncoder.withIndent('  ').convert(data), flush:true);
  await File('${out.path}/README.txt').writeAsString('Австрия — ${p.name} (${p.years})\nКаталог монет в catalog.json.\nИсточник: ${data['источник']}\n', flush:true);
  return out.path;
}

class AustriaCoinsPage extends StatefulWidget { final _AustriaPeriod period; const AustriaCoinsPage({super.key, required this.period}); @override State<AustriaCoinsPage> createState()=>_AustriaCoinsPageState(); }
class _AustriaCoinsPageState extends State<AustriaCoinsPage> {
  Map<String,int> counts = {};
  bool sortByYear = false;
  String? selectedDenomination;
  int? selectedYear;
  String get storageKey => 'austria_coin_counts_v2_${widget.period.years}_${widget.period.name}';
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString(storageKey); if(raw!=null){try{final m=jsonDecode(raw) as Map<String,dynamic>; if(mounted)setState(()=>counts=m.map((k,v)=>MapEntry(k,(v as num).toInt())));}catch(_){}} }
  Future<void> _change(String key,int delta) async { final next=(counts[key]??0)+delta; if(next<0)return; final updated=Map<String,int>.from(counts); updated[key]=next; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _setCount(String key, int value) async { final updated=Map<String,int>.from(counts); updated[key]=value < 0 ? 0 : value; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _editCount(String key) async {
    final controller=TextEditingController(text:'${counts[key]??0}');
    final value=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Количество монет'),content:TextField(controller:controller,keyboardType:TextInputType.number,autofocus:true,decoration:const InputDecoration(labelText:'В наличии',border:OutlineInputBorder()),),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Отмена')),FilledButton(onPressed:(){final n=int.tryParse(controller.text.trim()); if(n!=null && n>=0) Navigator.pop(ctx,n);},child:const Text('Сохранить'))]));
    controller.dispose(); if(value!=null) await _setCount(key,value);
  }
  Future<void> _confirmResetAll() async {
    final confirmed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Сбросить количество?'),content:const Text('Количество всех монет во всех периодах Австрии будет установлено в 0. Это действие нельзя отменить.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:Theme.of(ctx).colorScheme.error),child:const Text('Сбросить всё'))]));
    if(confirmed!=true)return;
    final prefs=await SharedPreferences.getInstance();
    final keys=prefs.getKeys().where((k)=>k.startsWith('austria_coin_counts_v2_')).toList();
    for(final key in keys){final raw=prefs.getString(key); if(raw==null)continue; try{final m=jsonDecode(raw) as Map<String,dynamic>; final zeroed=<String,int>{for(final entry in m.entries) entry.key:0}; await prefs.setString(key,jsonEncode(zeroed));}catch(_){}}
    await prefs.setString(storageKey,jsonEncode(<String,int>{for(final key in counts.keys) key:0}));
    if(mounted){setState(()=>counts={for(final key in counts.keys) key:0}); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Количество всех монет сброшено')));}
  }
  Widget _roundCounterButton(IconData icon, VoidCallback? onPressed) => Padding(padding:const EdgeInsets.symmetric(horizontal:8,vertical:1),child:Material(color:onPressed==null?Colors.black12:Theme.of(context).colorScheme.primary,shape:const CircleBorder(),child:InkWell(customBorder:const CircleBorder(),onTap:onPressed,child:SizedBox(width:30,height:30,child:Icon(icon,size:18,color:onPressed==null?Colors.black38:Colors.white)))));
  @override Widget build(BuildContext context) {
    final euro=widget.period.ucoinId==311; final coins=euro?_austriaEuroCoinsByYear():<_AustriaCoin>[];
    if (euro) {
      if (selectedDenomination != null) coins.removeWhere((c) => c.denomination != selectedDenomination);
      if (selectedYear != null) coins.removeWhere((c) => c.years != '$selectedYear');
      coins.sort((a,b) {
        final ya=int.tryParse(a.years)??0, yb=int.tryParse(b.years)??0;
        if (sortByYear) { final byYear=ya.compareTo(yb); return byYear != 0 ? byYear : _euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination)); }
        final byDenomination=_euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination));
        return byDenomination != 0 ? byDenomination : ya.compareTo(yb);
      });
    }
    return Scaffold(appBar:AppBar(title:Text(widget.period.name),actions:[IconButton(tooltip:'Сбросить количество всех монет',icon:const Icon(Icons.delete_sweep_outlined),onPressed:_confirmResetAll)]),body:ListView(padding:const EdgeInsets.all(8),children:[
      Text('Австрия · ${widget.period.years}',style:Theme.of(context).textTheme.titleMedium),
      if(euro) Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Row(children:[ChoiceChip(label:const Text('По номиналу'),selected:!sortByYear,onSelected:(_)=>setState(()=>sortByYear=false)),const SizedBox(width:6),ChoiceChip(label:const Text('По годам'),selected:sortByYear,onSelected:(_)=>setState(()=>sortByYear=true)),const Spacer(),IconButton(tooltip:'Сбросить все фильтры',visualDensity:VisualDensity.compact,padding:EdgeInsets.zero,constraints:const BoxConstraints.tightFor(width:32,height:40),icon:const Icon(Icons.filter_alt_off,size:20),onPressed:()=>setState((){selectedDenomination=null;selectedYear=null;}))]),const SizedBox(height:6),sortByYear ? DropdownButtonFormField<int>(value:selectedYear,decoration:const InputDecoration(labelText:'Год',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все годы'),items:[const DropdownMenuItem<int>(value:null,child:Text('Все годы')),...List.generate(25,(i)=>2002+i).map((y)=>DropdownMenuItem<int>(value:y,child:Text('$y')))],onChanged:(v)=>setState(()=>selectedYear=v)) : DropdownButtonFormField<String>(value:selectedDenomination,decoration:const InputDecoration(labelText:'Номинал',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все номиналы'),items:[const DropdownMenuItem<String>(value:null,child:Text('Все номиналы')),..._austriaEuroDenominations().map((d)=>DropdownMenuItem<String>(value:d,child:Text(d)))],onChanged:(v)=>setState(()=>selectedDenomination=v))])),
      if(!euro) const Padding(padding:EdgeInsets.symmetric(vertical:16),child:Text('Для этого исторического периода полный список монет пока не загружен. Откройте uCoin по ссылке ниже, чтобы просмотреть актуальный каталог.')),
      for(final c in coins) Card(clipBehavior:Clip.antiAlias,child:ListTile(contentPadding:const EdgeInsets.only(left:0,right:8),minLeadingWidth:54,horizontalTitleGap:8,
        leading: SizedBox(width:54,height:54,child:ClipRRect(borderRadius:BorderRadius.circular(27),child:Image.network(c.reverseImageUrl,width:54,height:54,fit:BoxFit.contain,errorBuilder:(_,__,___)=>Container(width:54,height:54,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,shape:BoxShape.circle),child:const Icon(Icons.monetization_on_outlined,size:30))))),
        title:Text('${c.denomination} ${c.years}'),subtitle:null,isThreeLine:false,
        trailing:SizedBox(height:30,child:Row(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.center,children:[_roundCounterButton(Icons.remove, (counts['${c.denomination}_${c.years}']??0)>0?()=>_change('${c.denomination}_${c.years}',-1):null),SizedBox(width:30,height:30,child:Material(color:Colors.transparent,child:InkWell(onTap:()=>_editCount('${c.denomination}_${c.years}'),borderRadius:BorderRadius.circular(6),child:Center(child:FittedBox(fit:BoxFit.scaleDown,child:Text('${counts['${c.denomination}_${c.years}']??0}',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:22,height:1.0))))))),_roundCounterButton(Icons.add,()=>_change('${c.denomination}_${c.years}',1))])),
        onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))),
      )),
      Card(child:ListTile(leading:const Icon(Icons.open_in_new),title:const Text('Полный каталог на uCoin'),subtitle:Text('Австрия · ${widget.period.name} · ${widget.period.years}'),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))))),
      const Padding(padding:EdgeInsets.all(8),child:Text('Изображения загружаются из сети. Количество монет сохраняется на устройстве.',style:TextStyle(fontSize:12,color:Colors.black54))),
    ]));
  }
}

class AppSettingsPage extends StatefulWidget { const AppSettingsPage({super.key}); @override State<AppSettingsPage> createState()=>_AppSettingsPageState(); }
class _AppSettingsPageState extends State<AppSettingsPage> {
 String? path;
 @override void initState(){super.initState(); SharedPreferences.getInstance().then((p){if(mounted)setState(()=>path=p.getString('catalog_save_directory_v1'));});}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Настройки')),body:ListView(padding:const EdgeInsets.all(16),children:[
  const Text('Папка для сохранения офлайн-каталогов',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),
  Text(path??'По умолчанию: папка документов приложения'),const SizedBox(height:12),
  FilledButton.icon(onPressed:() async {final selected=await FilePicker.platform.getDirectoryPath(dialogTitle:'Выберите папку для каталогов'); if(selected!=null){final p=await SharedPreferences.getInstance();await p.setString('catalog_save_directory_v1',selected);if(mounted)setState(()=>path=selected);}},icon:const Icon(Icons.folder_open),label:const Text('Выбрать папку')),
  TextButton.icon(onPressed:() async {final p=await SharedPreferences.getInstance();await p.remove('catalog_save_directory_v1');if(mounted)setState(()=>path=null);},icon:const Icon(Icons.restart_alt),label:const Text('Папка по умолчанию')),
  const Divider(height:32),const Text('Пока полностью подготовлен офлайн-шаблон для евро Австрии. Для остальных исторических периодов структура и ссылки на uCoin доступны, но полные списки и изображения нужно загрузить отдельно.',style:TextStyle(color:Colors.black54)),
 ]));
}

// Country facts for Austria: the short description is loaded from Wikipedia's REST API.
class AustriaInfoPage extends StatefulWidget {
  const AustriaInfoPage({super.key});
  @override
  State<AustriaInfoPage> createState() => _AustriaInfoPageState();
}

class _AustriaInfoPageState extends State<AustriaInfoPage> {
  String? _summary;
  String? _wikiImage;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadWikipedia();
  }

  Future<void> _loadWikipedia() async {
    try {
      final uri = Uri.https('ru.wikipedia.org', '/api/rest_v1/page/summary/Австрия');
      final response = await http.get(uri, headers: {'User-Agent': 'AMiK-SC/0.19 (country information app)'}).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw Exception('Wikipedia ответила кодом ${response.statusCode}');
      final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _summary = data['extract'] as String?;
        final thumbnail = data['thumbnail'];
        if (thumbnail is Map<String, dynamic>) _wikiImage = thumbnail['source'] as String?;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Не удалось загрузить описание из Википедии. Проверьте подключение к интернету.'; });
    }
  }

  Widget _fact(String label, String value, {String? subtitle}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 13, color: Colors.black54)),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      if (subtitle != null) Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );

  Widget _imagePanel(String title, String url, {double height = 150}) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, height: height, child: Image.network(url, fit: BoxFit.contain,
        loadingBuilder: (context, child, progress) => progress == null ? child : const Center(child: CircularProgressIndicator(strokeWidth: 2)),
        errorBuilder: (_, __, ___) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.broken_image_outlined, size: 30), const SizedBox(height: 6), const Text('Изображение недоступно'), TextButton(onPressed: () { (context as Element).markNeedsBuild(); }, child: const Text('Повторить'))])))),
    ])),
  );

  @override
  Widget build(BuildContext context) {
    const wikiUrl = 'https://ru.wikipedia.org/wiki/Австрия';
    return Scaffold(
      appBar: AppBar(title: const Text('Австрия')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Австрийская Республика', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _fact('Официальное название', 'Австрийская Республика (Republik Österreich)'),
          _fact('Столица', 'Вена'),
          _fact('Площадь страны', '83 879 км²', subtitle: '113-е место в мире по данным статьи Википедии'),
          _fact('Население', 'Около 9,2 млн человек', subtitle: 'Место в мире зависит от года оценки и источника'),
          _fact('Дата независимости', '27 июля 1955 года (Государственный договор)'),
          _fact('Официальный язык', 'Немецкий; в отдельных регионах признаны языки меньшинств'),
          _fact('Валюта', 'Евро (EUR)'),
          _fact('Интернет-домен', '.at'),
          _fact('Телефонный код', '+43'),
          _fact('Часовой пояс', 'UTC+1 зимой, UTC+2 летом'),
        ]))),
        if (_loading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
        if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_error!, style: const TextStyle(color: Colors.deepOrange))),
        if (_summary != null) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Описание из Википедии', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), Text(_summary!),
        ]))),
        _imagePanel('Расположение страны в Европе', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_in_European_Union.svg?width=960', height: 190),
        _imagePanel('Флаг Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Flag_of_Austria.svg?width=600', height: 110),
        _imagePanel('Герб Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_Bundesadler.png?width=500', height: 180),
        Card(child: ListTile(leading: const Icon(Icons.open_in_new), title: const Text('Открыть статью в Википедии'), subtitle: const Text('Подробная информация и источники'), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WikipediaArticlePage(url: wikiUrl))))),
        const Padding(padding: EdgeInsets.all(8), child: Text('Рейтинговые места приведены по данным статьи Википедии и могут меняться с обновлением статистики.', style: TextStyle(fontSize: 12, color: Colors.black54))),
      ]),
    );
  }
}

class WikipediaArticlePage extends StatefulWidget {
  final String url;
  const WikipediaArticlePage({super.key, required this.url});
  @override
  State<WikipediaArticlePage> createState() => _WikipediaArticlePageState();
}
class _WikipediaArticlePageState extends State<WikipediaArticlePage> {
  late final WebViewController _controller = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..loadRequest(Uri.parse(widget.url));
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Википедия')), body: WebViewWidget(controller: _controller));
}

// Loads the live uCoin catalog inside the app. uCoin remains the source of truth;
// the app does not copy or cache catalog entries locally.
class UcoinCountryPage extends StatefulWidget {
  final String country;
  const UcoinCountryPage({super.key, required this.country});

  @override
  State<UcoinCountryPage> createState() => _UcoinCountryPageState();
}

class _UcoinCountryPageState extends State<UcoinCountryPage> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _failed = false;

  static const Map<String, String> _slugs = {
    'Австрия': 'austria', 'Албания': 'albania', 'Андорра': 'andorra',
    'Беларусь': 'belarus', 'Бельгия': 'belgium', 'Болгария': 'bulgaria',
    'Босния и Герцеговина': 'bosnia_and_herzegovina', 'Ватикан': 'vatican',
    'Великобритания': 'united_kingdom', 'Венгрия': 'hungary', 'Германия': 'germany',
    'Греция': 'greece', 'Дания': 'denmark', 'Ирландия': 'ireland',
    'Исландия': 'iceland', 'Испания': 'spain', 'Италия': 'italy', 'Кипр': 'cyprus',
    'Косово': 'kosovo', 'Латвия': 'latvia', 'Литва': 'lithuania',
    'Лихтенштейн': 'liechtenstein', 'Люксембург': 'luxembourg', 'Мальта': 'malta',
    'Молдова': 'moldova', 'Монако': 'monaco', 'Нидерланды': 'netherlands',
    'Норвегия': 'norway', 'Польша': 'poland', 'Португалия': 'portugal',
    'Россия': 'russia', 'Румыния': 'romania', 'Сан-Марино': 'san_marino',
    'Северная Македония': 'north_macedonia', 'Сербия': 'serbia',
    'Словакия': 'slovakia', 'Словения': 'slovenia', 'Турция': 'turkey',
    'Украина': 'ukraine', 'Финляндия': 'finland', 'Франция': 'france',
    'Хорватия': 'croatia', 'Черногория': 'montenegro', 'Чехия': 'czech_republic',
    'Швейцария': 'switzerland', 'Швеция': 'sweden', 'Эстония': 'estonia',
  };

  @override
  void initState() {
    super.initState();
    final slug = _slugs[widget.country];
    final uri = slug == null
        ? Uri.https('ru.ucoin.net', '/catalog/', {'country': widget.country})
        : Uri.https('ru.ucoin.net', '/catalog/', {'country': slug});
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; _failed = false; }); },
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() { _loading = false; _failed = true; });
          }
        },
      ))
      ..loadRequest(uri);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.country),
      actions: [IconButton(tooltip: 'Обновить', icon: const Icon(Icons.refresh), onPressed: () => _controller.reload())],
    ),
    body: Stack(children: [
      WebViewWidget(controller: _controller),
      if (_loading) const LinearProgressIndicator(),
      if (_failed) Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off, size: 48),
          const SizedBox(height: 12),
          const Text('Не удалось загрузить каталог uCoin. Проверьте интернет и попробуйте снова.', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh), label: const Text('Повторить')),
        ]),
      )),
    ]),
  );
}
