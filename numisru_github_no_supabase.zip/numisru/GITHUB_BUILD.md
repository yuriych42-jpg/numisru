# NumisRU — сборка APK через GitHub

Для тестовой сборки APK дополнительные GitHub Secrets не нужны.

GitHub Actions собирает приложение командой `flutter build apk --release`.

Supabase можно подключить позже; текущая сборка не требует создания проекта Supabase или добавления Secrets.
