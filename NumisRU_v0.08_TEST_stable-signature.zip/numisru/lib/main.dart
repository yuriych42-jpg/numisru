import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');

  // Run a useful preview when backend credentials have not been configured yet.
  if (url.isEmpty || key.isEmpty) {
    runApp(const NumisRuOfflineApp());
    return;
  }

  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      final auth = Supabase.instance.client.auth;
      if (auth.currentSession == null) {
        await auth.signInAnonymously();
      }
    } catch (_) {
      // The app can still open if anonymous sign-in is not enabled in Supabase.
    }
    runApp(const NumisRuApp());
  } catch (_) {
    // Invalid/unreachable backend configuration should not leave the user at a blank screen.
    runApp(const NumisRuOfflineApp());
  }
}

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NumisRU',
        debugShowCheckedModeBanner: false,
        theme: _appTheme(),
        home: const HomeShell(),
      );
}

ThemeData _appTheme() => ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF263238)),
      useMaterial3: true,
      cardTheme: const CardThemeData(
        margin: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
    );

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [
    CatalogPage(),
    CollectionPage(),
    WishlistPage(),
    PortfolioPage(),
    ProfilePage(),
  ];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Wishlist'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _index, children: _pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() => _index = i),
          destinations: _destinations,
        ),
      );
}

// Self-contained preview mode. It deliberately avoids creating any Supabase-backed pages.
class NumisRuOfflineApp extends StatelessWidget {
  const NumisRuOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'NumisRU — тест',
        debugShowCheckedModeBanner: false,
        theme: _appTheme(),
        home: const OfflineHomeShell(),
      );
}

class _DemoItem {
  final String title;
  final String subtitle;
  final String detail;
  final IconData icon;
  const _DemoItem(this.title, this.subtitle, this.detail, this.icon);
}

const _demoItems = <_DemoItem>[
  _DemoItem('1 рубль 1997 года', 'Россия · регулярный выпуск', 'Сталь с никелевым покрытием · пример каталожной записи', Icons.currency_ruble),
  _DemoItem('5 рублей 1997 года', 'Россия · регулярный выпуск', 'Медно-никелевый сплав · пример каталожной записи', Icons.monetization_on_outlined),
  _DemoItem('10 рублей 2012 года', 'Россия · памятная монета', 'Биметалл · пример каталожной записи', Icons.circle_outlined),
  _DemoItem('Полтинник 1924 года', 'РСФСР · серебро', 'Серебро 900 пробы · пример исторической монеты', Icons.account_balance),
  _DemoItem('Банкнота 100 рублей 1997 года', 'Россия · банкноты', 'Модификации 2001 и 2004 годов · пример записи', Icons.payments_outlined),
  _DemoItem('Банкнота 500 рублей 1997 года', 'Россия · банкноты', 'Изображение памятника Петру I · пример записи', Icons.receipt_long_outlined),
];

class OfflineHomeShell extends StatefulWidget {
  const OfflineHomeShell({super.key});
  @override
  State<OfflineHomeShell> createState() => _OfflineHomeShellState();
}

class _OfflineHomeShellState extends State<OfflineHomeShell> {
  int _index = 0;
  final _search = TextEditingController();
  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Каталог', 'Моя коллекция', 'Избранное', 'Статистика', 'Профиль'];
    return Scaffold(
      appBar: AppBar(
        title: Text('NumisRU · ${titles[_index]}'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: Center(child: Icon(Icons.science_outlined, color: Theme.of(context).colorScheme.primary)),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.secondaryContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.info_outline, size: 20),
              SizedBox(width: 8),
              Expanded(child: Text('ТЕСТОВЫЙ РЕЖИМ · Supabase не подключён. Показаны примеры; изменения не сохраняются.')),
            ]),
          ),
          Expanded(child: IndexedStack(index: _index, children: [
            _buildCatalog(),
            _buildEmpty('Коллекция пока демонстрационная', 'После подключения базы здесь можно будет учитывать монеты и банкноты, состояние, количество и цену.', Icons.collections_bookmark_outlined),
            _buildEmpty('Избранное пока пусто', 'В полной версии сюда можно добавлять интересные позиции каталога.', Icons.bookmark_border),
            _buildStats(),
            _buildProfile(),
          ])),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
          NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
          NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
        ],
      ),
    );
  }

  Widget _buildCatalog() {
    final query = _search.text.trim().toLowerCase();
    final items = _demoItems.where((item) => '${item.title} ${item.subtitle} ${item.detail}'.toLowerCase().contains(query)).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
        child: SearchBar(
          controller: _search,
          hintText: 'Поиск по демонстрационному каталогу',
          leading: const Icon(Icons.search),
          onChanged: (_) => setState(() {}),
          trailing: [if (_search.text.isNotEmpty) IconButton(onPressed: () { _search.clear(); setState(() {}); }, icon: const Icon(Icons.clear))],
        ),
      ),
      Expanded(child: items.isEmpty
          ? const Center(child: Text('Ничего не найдено'))
          : ListView.builder(
              padding: const EdgeInsets.only(bottom: 12),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(child: ListTile(
                  leading: CircleAvatar(child: Icon(item.icon)),
                  title: Text(item.title),
                  subtitle: Text('${item.subtitle}\n${item.detail}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => showDialog<void>(context: context, builder: (context) => AlertDialog(
                    title: Text(item.title),
                    content: Text('${item.subtitle}\n\n${item.detail}\n\nЭто демонстрационная запись, не проверенная каталожная оценка.'),
                    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Закрыть'))],
                  )),
                ));
              },
            )),
    ]);
  }

  Widget _buildEmpty(String title, String body, IconData icon) => Center(
        child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(title, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
          const SizedBox(height: 8),
          Text(body, textAlign: TextAlign.center),
        ])),
      );

  Widget _buildStats() => ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: ListTile(leading: const Icon(Icons.inventory_2_outlined), title: const Text('Позиции в коллекции'), trailing: const Text('0'))),
        Card(child: ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Оценка коллекции'), trailing: const Text('—'))),
        Card(child: ListTile(leading: const Icon(Icons.show_chart), title: const Text('История стоимости'), subtitle: const Text('Появится после подключения базы и внесения данных'))),
      ]);

  Widget _buildProfile() => ListView(padding: const EdgeInsets.all(12), children: [
        const Card(child: ListTile(leading: Icon(Icons.person_outline), title: Text('Профиль коллекционера'), subtitle: Text('Демонстрационный профиль'))),
        const Card(child: ListTile(leading: Icon(Icons.storage_outlined), title: Text('Хранилище данных'), subtitle: Text('Локальный просмотр без подключения к серверу'))),
        const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('О NumisRU'), subtitle: Text('Тестовый интерфейс каталога монет и банкнот. Данные примеры.'))),
      ]);
}
