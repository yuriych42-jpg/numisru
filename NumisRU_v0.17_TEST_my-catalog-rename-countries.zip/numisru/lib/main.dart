import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:country_flags/country_flags.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const AmikScOfflineApp());
    return;
  }
  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      if (Supabase.instance.client.auth.currentSession == null) {
        await Supabase.instance.client.auth.signInAnonymously();
      }
    } catch (_) {}
    runApp(const NumisRuApp());
  } catch (_) {
    runApp(const AmikScOfflineApp());
  }
}

ThemeData _appTheme() => ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174B63)),
  useMaterial3: true,
  cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6)),
);

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const HomeShell());
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [CatalogPage(), CollectionPage(), WishlistPage(), PortfolioPage(), ProfilePage()];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i) => setState(() => _index = i), destinations: _destinations));
}

class AmikScOfflineApp extends StatelessWidget {
  const AmikScOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const OfflineHomeShell());
}

class OfflineHomeShell extends StatefulWidget {
  const OfflineHomeShell({super.key});
  @override
  State<OfflineHomeShell> createState() => _OfflineHomeShellState();
}

class _OfflineHomeShellState extends State<OfflineHomeShell> {
  int _index = 0;

  static const _destinations = <NavigationDestination>[
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const ContinentHomePage(),
      const _OfflinePlaceholderPage(title: 'Коллекция', icon: Icons.collections_bookmark_outlined,
          message: 'Раздел коллекции будет подключён на следующем этапе.'),
      const _OfflinePlaceholderPage(title: 'Избранное', icon: Icons.bookmark_border,
          message: 'Избранное будет доступно после подключения сохранения монет.'),
      const _OfflinePlaceholderPage(title: 'Статистика', icon: Icons.insights_outlined,
          message: 'Статистика коллекции появится, когда будет доступен учёт собранных монет.'),
      const _OfflinePlaceholderPage(title: 'Профиль', icon: Icons.person_outline,
          message: 'Профиль будет подключён на следующем этапе.'),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: _destinations,
      ),
    );
  }
}

class _OfflinePlaceholderPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String message;
  const _OfflinePlaceholderPage({required this.title, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 52, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(message, textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}

class _Region {
  final String name;
  final IconData icon;
  final List<String> countries;
  const _Region(this.name, this.icon, this.countries);
}

// Country/territory names are a first-pass grouping for navigation. The uCoin catalog
// includes current countries as well as historical issuers and territories; this list
// will be refined step-by-step in later versions.
const List<_Region> _regions = [
  _Region('Европа', Icons.account_balance, [
    'Австрия','Албания','Андорра','Беларусь','Бельгия','Болгария','Босния и Герцеговина','Ватикан','Великобритания','Венгрия','Германия','Греция','Дания','Ирландия','Исландия','Испания','Италия','Кипр','Косово','Латвия','Литва','Лихтенштейн','Люксембург','Мальта','Молдова','Монако','Нидерланды','Норвегия','Польша','Португалия','Россия','Румыния','Сан-Марино','Северная Македония','Сербия','Словакия','Словения','Турция','Украина','Финляндия','Франция','Хорватия','Черногория','Чехия','Швейцария','Швеция','Эстония'
  ]),
  _Region('Азия', Icons.temple_buddhist, [
    'Азербайджан','Армения','Афганистан','Бангладеш','Бахрейн','Бруней','Бутан','Вьетнам','Грузия','Израиль','Индия','Индонезия','Иордания','Ирак','Иран','Йемен','Казахстан','Камбоджа','Катар','Кипр','Китай','КНДР','Кувейт','Кыргызстан','Лаос','Ливан','Малайзия','Мальдивы','Монголия','Мьянма','Непал','ОАЭ','Оман','Пакистан','Палестина','Саудовская Аравия','Сингапур','Сирия','Таджикистан','Таиланд','Тайвань','Тимор-Лесте','Туркменистан','Турция','Узбекистан','Филиппины','Шри-Ланка','Южная Корея','Япония'
  ]),
  _Region('Африка', Icons.wb_sunny_outlined, [
    'Алжир','Ангола','Бенин','Ботсвана','Буркина-Фасо','Бурунди','Габон','Гамбия','Гана','Гвинея','Гвинея-Бисау','Демократическая Республика Конго','Джибути','Египет','Замбия','Западная Сахара','Зимбабве','Кабо-Верде','Камерун','Кения','Коморы','Кот-д’Ивуар','Лесото','Либерия','Ливия','Маврикий','Мавритания','Мадагаскар','Малави','Мали','Марокко','Мозамбик','Намибия','Нигер','Нигерия','Республика Конго','Руанда','Сан-Томе и Принсипи','Сейшелы','Сенегал','Сомали','Судан','Сьерра-Леоне','Танзания','Того','Тунис','Уганда','Центральноафриканская Республика','Чад','Экваториальная Гвинея','Эритрея','Эсватини','Эфиопия','ЮАР','Южный Судан'
  ]),
  _Region('Северная Америка', Icons.landscape_outlined, [
    'Антигуа и Барбуда','Багамы','Барбадос','Белиз','Гаити','Гватемала','Гондурас','Гренада','Доминика','Доминиканская Республика','Канада','Коста-Рика','Куба','Мексика','Никарагуа','Панама','Сальвадор','Сент-Винсент и Гренадины','Сент-Китс и Невис','Сент-Люсия','США','Тринидад и Тобаго','Ямайка'
  ]),
  _Region('Южная Америка', Icons.public, [
    'Аргентина','Боливия','Бразилия','Венесуэла','Гайана','Колумбия','Парагвай','Перу','Суринам','Уругвай','Чили','Эквадор','Французская Гвиана'
  ]),
  _Region('Австралия и Океания', Icons.sailing, [
    'Австралия','Вануату','Кирибати','Маршалловы Острова','Микронезия','Науру','Новая Зеландия','Палау','Папуа — Новая Гвинея','Самоа','Соломоновы Острова','Тонга','Тувалу','Фиджи','Французская Полинезия','Американское Самоа','Гуам','Новая Каледония','Острова Кука'
  ]),
  _Region('Исчезнувшие страны', Icons.history_edu, [
    'Австро-Венгрия','Византийская империя','ГДР','Западная Германия','Османская империя','Пруссия','Римская империя','Российская империя','РСФСР','Советский Союз','Югославия','Чехословакия','Королевство Италия','Королевство Пруссия','Веймарская республика'
  ]),
  _Region('Непризнанные территории', Icons.public_off, [
    'Абхазия','Арцах / Нагорный Карабах','Косово','Приднестровье','Северный Кипр','Сомалиленд','Тайвань','Южная Осетия','Западная Сахара','Себорга'
  ]),
  _Region('Мой каталог', Icons.star_border, []),
];

const String _myCatalogCountriesKey = 'my_catalog_countries_v1';
const String _myCatalogNameKey = 'my_catalog_name_v1';
const String _defaultMyCatalogName = 'Мой каталог';

class ContinentHomePage extends StatefulWidget {
  const ContinentHomePage({super.key});
  @override
  State<ContinentHomePage> createState() => _ContinentHomePageState();
}

class _ContinentHomePageState extends State<ContinentHomePage> {
  String _myCatalogName = _defaultMyCatalogName;
  List<String> _myCountries = [];
  Timer? _holdTimer;
  bool _renameDialogOpened = false;

  @override
  void initState() {
    super.initState();
    _loadCustomData();
  }

  Future<void> _loadCustomData() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _myCatalogName = prefs.getString(_myCatalogNameKey) ?? _defaultMyCatalogName;
      _myCountries = prefs.getStringList(_myCatalogCountriesKey) ?? [];
    });
  }

  Future<void> _renameCatalog() async {
    final controller = TextEditingController(text: _myCatalogName);
    final newName = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Переименовать плитку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Название плитки'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    controller.dispose();
    if (newName == null || newName.trim().isEmpty || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_myCatalogNameKey, newName.trim());
    if (mounted) setState(() => _myCatalogName = newName.trim());
  }

  void _startHoldRename() {
    _holdTimer?.cancel();
    _renameDialogOpened = false;
    _holdTimer = Timer(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      _renameDialogOpened = true;
      _renameCatalog();
    });
  }

  void _cancelHold() => _holdTimer?.cancel();

  Future<void> _openRegion(_Region region) async {
    final customRegion = region.name == 'Мой каталог'
        ? _Region(_myCatalogName, region.icon, List<String>.from(_myCountries))
        : region;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => CountryListPage(
        region: customRegion,
        isMyCatalog: region.name == 'Мой каталог',
      ),
    ));
    await _loadCustomData();
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('АМиК SC'), centerTitle: false),
    body: Column(children: [
      Container(width: double.infinity, margin: const EdgeInsets.fromLTRB(12, 8, 12, 4), padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Theme.of(context).colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(14)),
        child: const Text('ТЕСТОВАЯ ВЕРСИЯ · Выберите часть света или раздел. Удерживайте плитку «Мой каталог» 1,5 секунды, чтобы переименовать её.')),
      Expanded(child: GridView.builder(
        padding: const EdgeInsets.all(8), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemCount: _regions.length,
        itemBuilder: (context, index) {
          final region = _regions[index];
          final isMyCatalog = region.name == 'Мой каталог';
          final title = isMyCatalog ? _myCatalogName : region.name;
          final count = isMyCatalog ? _myCountries.length : region.countries.length;
          return Card(clipBehavior: Clip.antiAlias, child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: isMyCatalog ? (_) => _startHoldRename() : null,
            onTapUp: isMyCatalog ? (_) => _cancelHold() : null,
            onTapCancel: isMyCatalog ? _cancelHold : null,
            onTap: () {
              if (isMyCatalog && _renameDialogOpened) {
                _renameDialogOpened = false;
                return;
              }
              _cancelHold();
              _openRegion(region);
            },
            child: Padding(padding: const EdgeInsets.all(10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(region.icon, size: 30, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8),
              Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text('$count стран', style: Theme.of(context).textTheme.labelSmall),
            ])),
          ));
        }))
    ]));
}

// ISO 3166-1 alpha-2 codes used to render actual country flag artwork.
const Map<String, String> _countryIsoCodes = {
  'Албания':'AL', 'Андорра':'AD', 'Австрия':'AT', 'Беларусь':'BY', 'Белоруссия':'BY',
  'Бельгия':'BE', 'Болгария':'BG', 'Босния и Герцеговина':'BA', 'Ватикан':'VA',
  'Великобритания':'GB', 'Венгрия':'HU', 'Германия':'DE', 'Греция':'GR', 'Дания':'DK',
  'Ирландия':'IE', 'Исландия':'IS', 'Испания':'ES', 'Италия':'IT', 'Кипр':'CY',
  'Косово':'XK', 'Латвия':'LV', 'Литва':'LT', 'Лихтенштейн':'LI', 'Люксембург':'LU',
  'Мальта':'MT', 'Молдова':'MD', 'Монако':'MC', 'Нидерланды':'NL', 'Норвегия':'NO',
  'Польша':'PL', 'Португалия':'PT', 'Россия':'RU', 'Румыния':'RO', 'Сан-Марино':'SM',
  'Северная Македония':'MK', 'Сербия':'RS', 'Словакия':'SK', 'Словения':'SI',
  'Турция':'TR', 'Украина':'UA', 'Финляндия':'FI', 'Франция':'FR', 'Хорватия':'HR',
  'Черногория':'ME', 'Чехия':'CZ', 'Швейцария':'CH', 'Швеция':'SE', 'Эстония':'EE',
  'Азербайджан':'AZ', 'Армения':'AM', 'Афганистан':'AF', 'Бангладеш':'BD', 'Бахрейн':'BH',
  'Бруней':'BN', 'Бутан':'BT', 'Вьетнам':'VN', 'Грузия':'GE', 'Израиль':'IL', 'Индия':'IN',
  'Индонезия':'ID', 'Иордания':'JO', 'Ирак':'IQ', 'Иран':'IR', 'Йемен':'YE', 'Казахстан':'KZ',
  'Камбоджа':'KH', 'Катар':'QA', 'Китай':'CN', 'КНДР':'KP', 'Кувейт':'KW', 'Кыргызстан':'KG',
  'Лаос':'LA', 'Ливан':'LB', 'Малайзия':'MY', 'Мальдивы':'MV', 'Монголия':'MN', 'Мьянма':'MM',
  'Непал':'NP', 'ОАЭ':'AE', 'Оман':'OM', 'Пакистан':'PK', 'Палестина':'PS',
  'Саудовская Аравия':'SA', 'Сингапур':'SG', 'Сирия':'SY', 'Таджикистан':'TJ', 'Таиланд':'TH',
  'Тайвань':'TW', 'Тимор-Лесте':'TL', 'Туркменистан':'TM', 'Узбекистан':'UZ',
  'Филиппины':'PH', 'Шри-Ланка':'LK', 'Южная Корея':'KR', 'Япония':'JP',
  'Алжир':'DZ', 'Ангола':'AO', 'Бенин':'BJ', 'Ботсвана':'BW', 'Буркина-Фасо':'BF',
  'Бурунди':'BI', 'Габон':'GA', 'Гамбия':'GM', 'Гана':'GH', 'Гвинея':'GN',
  'Гвинея-Бисау':'GW', 'Джибути':'DJ', 'Египет':'EG', 'Замбия':'ZM', 'Зимбабве':'ZW',
  'Кабо-Верде':'CV', 'Камерун':'CM', 'Кения':'KE', 'Коморы':'KM', 'Лесото':'LS',
  'Либерия':'LR', 'Ливия':'LY', 'Маврикий':'MU', 'Мавритания':'MR', 'Мадагаскар':'MG',
  'Малави':'MW', 'Мали':'ML', 'Марокко':'MA', 'Мозамбик':'MZ', 'Намибия':'NA',
  'Нигер':'NE', 'Нигерия':'NG', 'Руанда':'RW', 'Сейшелы':'SC', 'Сенегал':'SN',
  'Сомали':'SO', 'Судан':'SD', 'Сьерра-Леоне':'SL', 'Танзания':'TZ', 'Того':'TG',
  'Тунис':'TN', 'Уганда':'UG', 'Чад':'TD', 'Эритрея':'ER', 'Эсватини':'SZ',
  'Эфиопия':'ET', 'ЮАР':'ZA', 'Южный Судан':'SS',
  'Антигуа и Барбуда':'AG', 'Багамы':'BS', 'Барбадос':'BB', 'Белиз':'BZ', 'Гаити':'HT',
  'Гватемала':'GT', 'Гондурас':'HN', 'Гренада':'GD', 'Доминика':'DM',
  'Доминиканская Республика':'DO', 'Канада':'CA', 'Коста-Рика':'CR', 'Куба':'CU',
  'Мексика':'MX', 'Никарагуа':'NI', 'Панама':'PA', 'Сальвадор':'SV', 'США':'US',
  'Тринидад и Тобаго':'TT', 'Ямайка':'JM', 'Аргентина':'AR', 'Боливия':'BO',
  'Бразилия':'BR', 'Венесуэла':'VE', 'Гайана':'GY', 'Колумбия':'CO', 'Парагвай':'PY',
  'Перу':'PE', 'Суринам':'SR', 'Уругвай':'UY', 'Чили':'CL', 'Эквадор':'EC',
  'Австралия':'AU', 'Вануату':'VU', 'Кирибати':'KI', 'Маршалловы Острова':'MH',
  'Микронезия':'FM', 'Науру':'NR', 'Новая Зеландия':'NZ', 'Палау':'PW',
  'Папуа — Новая Гвинея':'PG', 'Самоа':'WS', 'Соломоновы Острова':'SB', 'Тонга':'TO',
  'Тувалу':'TV', 'Фиджи':'FJ', 'Гуам':'GU', 'Новая Каледония':'NC', 'Острова Кука':'CK',
  'Абхазия':'GE',
};

Widget _countryFlag(String country) {
  final code = _countryIsoCodes[country];
  if (code == null) return const SizedBox(width: 36, height: 24, child: Icon(Icons.flag_outlined));
  return ClipRRect(
    borderRadius: BorderRadius.circular(3),
    child: CountryFlag.fromCountryCode(
      code,
      theme: const ImageTheme(width: 36, height: 24),
    ),
  );
}

class CountryListPage extends StatefulWidget {
  final _Region region;
  final bool isMyCatalog;
  const CountryListPage({super.key, required this.region, this.isMyCatalog = false});
  @override
  State<CountryListPage> createState() => _CountryListPageState();
}

class _CountryListPageState extends State<CountryListPage> {
  String query = '';
  late List<String> _myCountries;

  @override
  void initState() {
    super.initState();
    _myCountries = List<String>.from(widget.region.countries);
    _loadMyCountries();
  }

  Future<void> _loadMyCountries() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _myCountries = prefs.getStringList(_myCatalogCountriesKey) ?? []);
  }

  Future<void> _toggleMyCountry(String country) async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList(_myCatalogCountriesKey) ?? [];
    final alreadyAdded = list.contains(country);
    if (widget.isMyCatalog) {
      list.remove(country);
    } else if (alreadyAdded) {
      list.remove(country);
    } else {
      list.add(country);
    }
    await prefs.setStringList(_myCatalogCountriesKey, list);
    if (!mounted) return;
    setState(() => _myCountries = list);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(widget.isMyCatalog ? 'Страна удалена из Мой каталог' : alreadyAdded ? 'Страна удалена из Мой каталог' : 'Страна добавлена в Мой каталог'),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final sourceCountries = widget.isMyCatalog ? _myCountries : widget.region.countries;
    final countries = sourceCountries.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList()
      ..sort((a,b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(appBar: AppBar(title: Text(widget.region.name)), body: Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SearchBar(leading: const Icon(Icons.search), hintText: 'Поиск страны или территории', onChanged: (v) => setState(() => query = v),)),
      Expanded(
        child: countries.isEmpty
            ? Center(child: Text(widget.isMyCatalog ? 'Список пуст. Откройте часть света и нажмите + у нужных стран.' : 'Ничего не найдено', textAlign: TextAlign.center))
            : ListView.separated(
                itemCount: countries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final country = countries[index];
                  final isAdded = _myCountries.contains(country);
                  return ListTile(
                    leading: _countryFlag(country),
                    title: Text(country),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      IconButton(
                        tooltip: widget.isMyCatalog ? 'Удалить из моего каталога' : isAdded ? 'Уже в моём каталоге — удалить' : 'Добавить в Мой каталог',
                        icon: Icon(widget.isMyCatalog ? Icons.remove_circle_outline : isAdded ? Icons.check_circle : Icons.add_circle_outline),
                        onPressed: () => _toggleMyCountry(country),
                      ),
                      const Icon(Icons.chevron_right),
                    ]),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => UcoinCountryPage(country: country))),
                  );
                },
              ),
      ),
    ]));
  }
}


// Loads the live uCoin catalog inside the app. uCoin remains the source of truth;
// the app does not copy or cache catalog entries locally.
class UcoinCountryPage extends StatefulWidget {
  final String country;
  const UcoinCountryPage({super.key, required this.country});

  @override
  State<UcoinCountryPage> createState() => _UcoinCountryPageState();
}

class _UcoinCountryPageState extends State<UcoinCountryPage> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _failed = false;

  static const Map<String, String> _slugs = {
    'Австрия': 'austria', 'Албания': 'albania', 'Андорра': 'andorra',
    'Беларусь': 'belarus', 'Бельгия': 'belgium', 'Болгария': 'bulgaria',
    'Босния и Герцеговина': 'bosnia_and_herzegovina', 'Ватикан': 'vatican',
    'Великобритания': 'united_kingdom', 'Венгрия': 'hungary', 'Германия': 'germany',
    'Греция': 'greece', 'Дания': 'denmark', 'Ирландия': 'ireland',
    'Исландия': 'iceland', 'Испания': 'spain', 'Италия': 'italy', 'Кипр': 'cyprus',
    'Косово': 'kosovo', 'Латвия': 'latvia', 'Литва': 'lithuania',
    'Лихтенштейн': 'liechtenstein', 'Люксембург': 'luxembourg', 'Мальта': 'malta',
    'Молдова': 'moldova', 'Монако': 'monaco', 'Нидерланды': 'netherlands',
    'Норвегия': 'norway', 'Польша': 'poland', 'Португалия': 'portugal',
    'Россия': 'russia', 'Румыния': 'romania', 'Сан-Марино': 'san_marino',
    'Северная Македония': 'north_macedonia', 'Сербия': 'serbia',
    'Словакия': 'slovakia', 'Словения': 'slovenia', 'Турция': 'turkey',
    'Украина': 'ukraine', 'Финляндия': 'finland', 'Франция': 'france',
    'Хорватия': 'croatia', 'Черногория': 'montenegro', 'Чехия': 'czech_republic',
    'Швейцария': 'switzerland', 'Швеция': 'sweden', 'Эстония': 'estonia',
  };

  @override
  void initState() {
    super.initState();
    final slug = _slugs[widget.country];
    final uri = slug == null
        ? Uri.https('ru.ucoin.net', '/catalog/', {'country': widget.country})
        : Uri.https('ru.ucoin.net', '/catalog/', {'country': slug});
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; _failed = false; }); },
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() { _loading = false; _failed = true; });
          }
        },
      ))
      ..loadRequest(uri);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.country),
      actions: [IconButton(tooltip: 'Обновить', icon: const Icon(Icons.refresh), onPressed: () => _controller.reload())],
    ),
    body: Stack(children: [
      WebViewWidget(controller: _controller),
      if (_loading) const LinearProgressIndicator(),
      if (_failed) Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off, size: 48),
          const SizedBox(height: 12),
          const Text('Не удалось загрузить каталог uCoin. Проверьте интернет и попробуйте снова.', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh), label: const Text('Повторить')),
        ]),
      )),
    ]),
  );
}
