import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';

// Version label supplied by CI from pubspec.yaml.
const String appVersion = String.fromEnvironment('APP_VERSION', defaultValue: '0.84.4');
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:country_flags/country_flags.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'pages/catalog_page.dart';
import 'pages/collection_page.dart';
import 'pages/profile_page.dart';
import 'pages/portfolio_page.dart';
import 'pages/wishlist_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isEmpty || key.isEmpty) {
    runApp(const AmikScOfflineApp());
    return;
  }
  try {
    await Supabase.initialize(url: url, publishableKey: key);
    try {
      if (Supabase.instance.client.auth.currentSession == null) {
        await Supabase.instance.client.auth.signInAnonymously();
      }
    } catch (_) {}
    runApp(const NumisRuApp());
  } catch (_) {
    runApp(const AmikScOfflineApp());
  }
}

ThemeData _appTheme() => ThemeData(
  colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF174B63)),
  useMaterial3: true,
  cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 8, vertical: 6)),
);

class NumisRuApp extends StatelessWidget {
  const NumisRuApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const HomeShell());
}

class _HoneycombClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) => Path()
    ..moveTo(size.width * .25, 0)
    ..lineTo(size.width * .75, 0)
    ..lineTo(size.width, size.height * .5)
    ..lineTo(size.width * .75, size.height)
    ..lineTo(size.width * .25, size.height)
    ..lineTo(0, size.height * .5)
    ..close();

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) => false;
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int _index = 0;
  final _pages = const [CatalogPage(), CollectionPage(), WishlistPage(), PortfolioPage(), ProfilePage()];
  final _destinations = const [
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: _index, children: _pages),
    bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (i) => setState(() => _index = i), destinations: _destinations));
}

class AmikScOfflineApp extends StatelessWidget {
  const AmikScOfflineApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'АМиК SC', debugShowCheckedModeBanner: false, theme: _appTheme(), home: const OfflineHomeShell());
}

class OfflineHomeShell extends StatefulWidget {
  const OfflineHomeShell({super.key});
  @override
  State<OfflineHomeShell> createState() => _OfflineHomeShellState();
}

class _OfflineHomeShellState extends State<OfflineHomeShell> {
  int _index = 0;

  static const _destinations = <NavigationDestination>[
    NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Каталог'),
    NavigationDestination(icon: Icon(Icons.collections_bookmark_outlined), selectedIcon: Icon(Icons.collections_bookmark), label: 'Коллекция'),
    NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Избранное'),
    NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Статистика'),
    NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Профиль'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const ContinentHomePage(),
      const _OfflinePlaceholderPage(title: 'Коллекция', icon: Icons.collections_bookmark_outlined,
          message: 'Раздел коллекции будет подключён на следующем этапе.'),
      const _OfflinePlaceholderPage(title: 'Избранное', icon: Icons.bookmark_border,
          message: 'Избранное будет доступно после подключения сохранения монет.'),
      const _OfflinePlaceholderPage(title: 'Статистика', icon: Icons.insights_outlined,
          message: 'Статистика коллекции появится, когда будет доступен учёт собранных монет.'),
      const _OfflinePlaceholderPage(title: 'Профиль', icon: Icons.person_outline,
          message: 'Профиль будет подключён на следующем этапе.'),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: _destinations,
      ),
    );
  }
}

class _OfflinePlaceholderPage extends StatelessWidget {
  final String title;
  final IconData icon;
  final String message;
  const _OfflinePlaceholderPage({required this.title, required this.icon, required this.message});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 52, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(message, textAlign: TextAlign.center),
        ]),
      ),
    ),
  );
}

class _Region {
  final String name;
  final IconData icon;
  final List<String> countries;
  const _Region(this.name, this.icon, this.countries);
}

// Country/territory names are a first-pass grouping for navigation. The uCoin catalog
// includes current countries as well as historical issuers and territories; this list
// will be refined step-by-step in later versions.
const List<_Region> _regions = [
  _Region('Европа', Icons.account_balance, [
    'Австрия','Албания','Андорра','Беларусь','Бельгия','Болгария','Босния и Герцеговина','Ватикан','Великобритания','Венгрия','Германия','Греция','Дания','Ирландия','Исландия','Испания','Италия','Кипр','Косово','Латвия','Литва','Лихтенштейн','Люксембург','Мальта','Молдова','Монако','Нидерланды','Норвегия','Польша','Португалия','Россия','Румыния','Сан-Марино','Северная Македония','Сербия','Словакия','Словения','Турция','Украина','Финляндия','Франция','Хорватия','Черногория','Чехия','Швейцария','Швеция','Эстония'
  ]),
  _Region('Азия', Icons.temple_buddhist, [
    'Азербайджан','Армения','Афганистан','Бангладеш','Бахрейн','Бруней','Бутан','Вьетнам','Грузия','Израиль','Индия','Индонезия','Иордания','Ирак','Иран','Йемен','Казахстан','Камбоджа','Катар','Кипр','Китай','КНДР','Кувейт','Кыргызстан','Лаос','Ливан','Малайзия','Мальдивы','Монголия','Мьянма','Непал','ОАЭ','Оман','Пакистан','Палестина','Саудовская Аравия','Сингапур','Сирия','Таджикистан','Таиланд','Тайвань','Тимор-Лесте','Туркменистан','Турция','Узбекистан','Филиппины','Шри-Ланка','Южная Корея','Япония'
  ]),
  _Region('Африка', Icons.wb_sunny_outlined, [
    'Алжир','Ангола','Бенин','Ботсвана','Буркина-Фасо','Бурунди','Габон','Гамбия','Гана','Гвинея','Гвинея-Бисау','Демократическая Республика Конго','Джибути','Египет','Замбия','Западная Сахара','Зимбабве','Кабо-Верде','Камерун','Кения','Коморы','Кот-д’Ивуар','Лесото','Либерия','Ливия','Маврикий','Мавритания','Мадагаскар','Малави','Мали','Марокко','Мозамбик','Намибия','Нигер','Нигерия','Республика Конго','Руанда','Сан-Томе и Принсипи','Сейшелы','Сенегал','Сомали','Судан','Сьерра-Леоне','Танзания','Того','Тунис','Уганда','Центральноафриканская Республика','Чад','Экваториальная Гвинея','Эритрея','Эсватини','Эфиопия','ЮАР','Южный Судан'
  ]),
  _Region('Северная Америка', Icons.landscape_outlined, [
    'Антигуа и Барбуда','Багамы','Барбадос','Белиз','Гаити','Гватемала','Гондурас','Гренада','Доминика','Доминиканская Республика','Канада','Коста-Рика','Куба','Мексика','Никарагуа','Панама','Сальвадор','Сент-Винсент и Гренадины','Сент-Китс и Невис','Сент-Люсия','США','Тринидад и Тобаго','Ямайка'
  ]),
  _Region('Южная Америка', Icons.public, [
    'Аргентина','Боливия','Бразилия','Венесуэла','Гайана','Колумбия','Парагвай','Перу','Суринам','Уругвай','Чили','Эквадор','Французская Гвиана'
  ]),
  _Region('Австралия и Океания', Icons.sailing, [
    'Австралия','Вануату','Кирибати','Маршалловы Острова','Микронезия','Науру','Новая Зеландия','Палау','Папуа — Новая Гвинея','Самоа','Соломоновы Острова','Тонга','Тувалу','Фиджи','Французская Полинезия','Американское Самоа','Гуам','Новая Каледония','Острова Кука'
  ]),
  _Region('Исчезнувшие страны', Icons.history_edu, [
    'Австро-Венгрия','Византийская империя','ГДР','Западная Германия','Османская империя','Пруссия','Римская империя','Российская империя','РСФСР','Советский Союз','Югославия','Чехословакия','Королевство Италия','Королевство Пруссия','Веймарская республика'
  ]),
  _Region('Непризнанные территории', Icons.public_off, [
    'Абхазия','Арцах / Нагорный Карабах','Косово','Приднестровье','Северный Кипр','Сомалиленд','Тайвань','Южная Осетия','Западная Сахара','Себорга'
  ]),
  _Region('Мой каталог', Icons.star_border, []),
];

const String _myCatalogCountriesKey = 'my_catalog_countries_v1';
String _catalogCountriesKey(String name) => 'my_catalog_countries_v2_${Uri.encodeComponent(name)}';
const String _myCatalogNameKey = 'my_catalog_name_v1';
const String _defaultMyCatalogName = 'Мой каталог';
const String _myCatalogNamesKey = 'my_catalog_names_v2';
const String _tileOrderKey = 'home_tile_order_v1';
const String _homeSortModeKey = 'home_catalog_sort_mode_v1';
String _catalogCreatedAtKey(String name) => 'home_catalog_created_at_v1_${Uri.encodeComponent(name)}';
const String _homeViewModeKey = 'home_view_mode_v1';
const String _standardTileColorKey = 'home_standard_tile_color_v1';
const String _customTileColorKey = 'home_custom_tile_color_v1';
const String _addCatalogTileColorKey = 'home_add_catalog_tile_color_v1';
const String _legacyHomeTileColorKey = 'home_tile_color_v1';
const List<int> _homeTileColorOptions = [0xFFF5F5F5, 0xFFE8F1F5, 0xFFF1EBDD, 0xFFE8F0E6, 0xFFF2E8EF, 0xFFECE9F7, 0xFFFFF3D9];

class ContinentHomePage extends StatefulWidget {
  const ContinentHomePage({super.key});
  @override
  State<ContinentHomePage> createState() => _ContinentHomePageState();
}

class _ContinentHomePageState extends State<ContinentHomePage> {
  String _myCatalogName = _defaultMyCatalogName;
  List<String> _myCountries = [];
  List<String> _catalogNames = [_defaultMyCatalogName];
  Map<String, List<String>> _catalogCountries = {}; 
  Timer? _holdTimer;
  bool _renameDialogOpened = false;
  bool _catalogSelectionMode = false;
  bool _holdActivated = false;
  final Set<String> _selectedCatalogs = <String>{};
  List<String> _tileOrder = <String>[];
  bool _currentDragMoved = false;
  final ScrollController _homeScrollController = ScrollController();
  int? _standardTileColorValue;
  int? _customTileColorValue;
  int? _addCatalogTileColorValue;
  String _homeViewMode = 'tiles';
  String _homeSortMode = 'created';
  Map<String, int> _catalogCreatedAt = <String, int>{};

  @override
  void initState() {
    super.initState();
    _loadCustomData();
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    _homeScrollController.dispose();
    super.dispose();
  }

  Future<void> _loadCustomData() async {
    final prefs = await SharedPreferences.getInstance();
    final myCatalogName = prefs.getString(_myCatalogNameKey) ?? _defaultMyCatalogName;
    final catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? [myCatalogName];
    final savedTileOrder = prefs.getStringList(_tileOrderKey) ?? <String>[];
    final savedStandardTileColor = prefs.getInt(_standardTileColorKey) ?? prefs.getInt(_legacyHomeTileColorKey);
    final savedCustomTileColor = prefs.getInt(_customTileColorKey);
    final savedAddCatalogTileColor = prefs.getInt(_addCatalogTileColorKey);
    final savedHomeViewMode = prefs.getString(_homeViewModeKey) ?? 'tiles';
    final savedSortMode = prefs.getString(_homeSortModeKey) ?? 'created';
    final createdAt = <String, int>{};
    var legacyCreationTime = DateTime.now().millisecondsSinceEpoch - catalogNames.length;
    for (final name in catalogNames) {
      var created = prefs.getInt(_catalogCreatedAtKey(name));
      if (created == null) {
        created = legacyCreationTime++;
        await prefs.setInt(_catalogCreatedAtKey(name), created);
      }
      createdAt[name] = created;
    }
    if (prefs.containsKey(_legacyHomeTileColorKey) && !prefs.containsKey(_standardTileColorKey)) {
      await prefs.setInt(_standardTileColorKey, savedStandardTileColor ?? _homeTileColorOptions.first);
      await prefs.remove(_legacyHomeTileColorKey);
    }
    // Migrate the old shared list into the original catalog only once.
    final legacy = prefs.getStringList(_myCatalogCountriesKey);
    if (legacy != null && prefs.getStringList(_catalogCountriesKey(_defaultMyCatalogName)) == null) {
      await prefs.setStringList(_catalogCountriesKey(_defaultMyCatalogName), legacy);
      await prefs.remove(_myCatalogCountriesKey);
    }
    final catalogCountries = <String, List<String>>{
      for (final name in catalogNames)
        name: prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[],
    };
    if (!mounted) return;
    setState(() {
      _myCatalogName = myCatalogName;
      _catalogNames = catalogNames;
      _tileOrder = savedTileOrder;
      _standardTileColorValue = savedStandardTileColor;
      _customTileColorValue = savedCustomTileColor;
      _addCatalogTileColorValue = savedAddCatalogTileColor;
      _homeViewMode = savedHomeViewMode;
      _homeSortMode = savedSortMode;
      _catalogCreatedAt = createdAt;
      _catalogCountries = catalogCountries;
      _myCountries = _catalogCountries[_myCatalogName] ?? <String>[];
    });
  }

  Future<void> _setHomeSortMode(String mode) async {
    final prefs = await SharedPreferences.getInstance();
    if (mode == 'manual' && _tileOrder.isEmpty) {
      final order = _orderedHomeRegions().map((r) => r.name).toList();
      await prefs.setStringList(_tileOrderKey, order);
      if (mounted) _tileOrder = order;
    }
    await prefs.setString(_homeSortModeKey, mode);
    if (mounted) setState(() => _homeSortMode = mode);
  }

  List<_Region> _sortHomeRegions(List<_Region> source) {
    final items = List<_Region>.from(source);
    final addTile = items.where((r) => r.name == '__add_catalog__').toList();
    items.removeWhere((r) => r.name == '__add_catalog__');
    int countOf(_Region r) => _catalogNames.contains(r.name)
        ? (_catalogCountries[r.name]?.length ?? 0) : r.countries.length;
    switch (_homeSortMode) {
      case 'countAsc':
        items.sort((a, b) { final c = countOf(a).compareTo(countOf(b)); return c != 0 ? c : a.name.toLowerCase().compareTo(b.name.toLowerCase()); });
        break;
      case 'countDesc':
        items.sort((a, b) { final c = countOf(b).compareTo(countOf(a)); return c != 0 ? c : a.name.toLowerCase().compareTo(b.name.toLowerCase()); });
        break;
      case 'nameAsc':
        items.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case 'nameDesc':
        items.sort((a, b) => b.name.toLowerCase().compareTo(a.name.toLowerCase()));
        break;
      case 'default':
      case 'created':
      case 'createdDesc':
      default:
        // Standard catalogs retain their installation order; only user catalogs
        // are ordered by their original creation timestamp.
        final standards = items.where((r) => !_catalogNames.contains(r.name)).toList();
        final customs = items.where((r) => _catalogNames.contains(r.name)).toList();
        customs.sort((a, b) => _homeSortMode == 'createdDesc'
            ? (_catalogCreatedAt[b.name] ?? 0).compareTo(_catalogCreatedAt[a.name] ?? 0)
            : (_catalogCreatedAt[a.name] ?? 0).compareTo(_catalogCreatedAt[b.name] ?? 0));
        items..clear()..addAll(standards)..addAll(customs);
        break;
    }
    items.addAll(addTile);
    return items;
  }

  Future<void> _moveTile(String draggedName, String targetName) async {
    if (draggedName == targetName || draggedName == '__add_catalog__') return;
    // When a non-manual sort is active, start from the order the user is
    // currently seeing. Dropping a catalog switches to manual mode and keeps
    // this visible order (with only the dragged/target items swapped), rather
    // than restoring a stale manual order from an earlier session.
    final order = _orderedHomeRegions().map((r) => r.name).toList();
    final from = order.indexOf(draggedName);
    if (from < 0 || !order.contains(targetName)) return;
    // Swap the dragged tile with the target tile instead of shifting the tiles
    // between their old and new positions. The add-catalog tile stays pinned
    // to the bottom, so dropping onto it swaps with the last movable tile.
    var to = order.indexOf(targetName);
    if (to < 0) return;
    if (targetName == '__add_catalog__') {
      to = order.length - 2;
      if (to < 0 || from == to) return;
    }
    final displacedName = order[to];
    order[to] = draggedName;
    order[from] = displacedName;
    order.remove('__add_catalog__');
    order.add('__add_catalog__');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_tileOrderKey, order);
    await prefs.setString(_homeSortModeKey, 'manual');
    if (mounted) setState(() { _tileOrder = order; _homeSortMode = 'manual'; });
  }

  Future<void> _renameCatalog(String oldName) async {
    final controller = TextEditingController(text: oldName);
    final newName = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Переименовать плитку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          textCapitalization: TextCapitalization.sentences,
          decoration: const InputDecoration(labelText: 'Название плитки'),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    controller.dispose();
    if (newName == null || newName.trim().isEmpty || !mounted) return;
    final prefs = await SharedPreferences.getInstance();
    final renamed = newName.trim();
    if (renamed != oldName && _catalogNames.contains(renamed)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Каталог с таким названием уже существует')));
      return;
    }
    final names = List<String>.from(_catalogNames);
    final index = names.indexOf(oldName);
    if (index >= 0) names[index] = renamed;
    if (index < 0) return;
    final countries = prefs.getStringList(_catalogCountriesKey(oldName)) ?? <String>[];
    await prefs.setStringList(_catalogCountriesKey(renamed), countries);
    await prefs.remove(_catalogCountriesKey(oldName));
    final oldCreatedAt = prefs.getInt(_catalogCreatedAtKey(oldName));
    if (oldCreatedAt != null) { await prefs.setInt(_catalogCreatedAtKey(renamed), oldCreatedAt); await prefs.remove(_catalogCreatedAtKey(oldName)); }
    await prefs.setString(_myCatalogNameKey, renamed);
    await prefs.setStringList(_myCatalogNamesKey, names);
    if (mounted) setState(() { if (_myCatalogName == oldName) _myCatalogName = renamed; _catalogNames = names; _catalogCountries.remove(oldName); _catalogCountries[renamed] = countries; if (oldCreatedAt != null) { _catalogCreatedAt.remove(oldName); _catalogCreatedAt[renamed] = oldCreatedAt; } _myCountries = _catalogCountries[_myCatalogName] ?? <String>[]; });
  }

  void _startHoldSelection(String catalogName) {
    _holdTimer?.cancel();
    _renameDialogOpened = false;
    _holdActivated = false;
    _holdTimer = Timer(const Duration(milliseconds: 500), () {
      if (!mounted) return;
      _holdActivated = true;
      setState(() {
        _catalogSelectionMode = true;
        _selectedCatalogs.add(catalogName);
      });
    });
  }

  void _cancelHold() => _holdTimer?.cancel();

  void _toggleCatalogSelection(String name) {
    setState(() {
      if (_selectedCatalogs.contains(name)) {
        _selectedCatalogs.remove(name);
      } else {
        _selectedCatalogs.add(name);
      }
      if (_selectedCatalogs.isEmpty) _catalogSelectionMode = false;
    });
  }

  Future<void> _deleteSelectedCatalogs() async {
    final selected = _catalogNames.where(_selectedCatalogs.contains).toList();
    if (selected.isEmpty) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Удалить выбранные каталоги?'),
      content: Text('Будут удалены ${selected.length} плиток и списки стран внутри них. Это действие нельзя отменить.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить'))],
    ));
    if (ok != true) return;
    final prefs = await SharedPreferences.getInstance();
    final names = List<String>.from(_catalogNames)..removeWhere(_selectedCatalogs.contains);
    for (final name in selected) { await prefs.remove(_catalogCountriesKey(name)); await prefs.remove(_catalogCreatedAtKey(name)); }
    await prefs.setStringList(_myCatalogNamesKey, names);
    if (_selectedCatalogs.contains(_myCatalogName)) {
      _myCatalogName = names.isNotEmpty ? names.first : _defaultMyCatalogName;
      await prefs.setString(_myCatalogNameKey, _myCatalogName);
    }
    if (mounted) setState(() {
      for (final name in selected) { _catalogCountries.remove(name); _catalogCreatedAt.remove(name); }
      _catalogNames = names;
      _myCountries = _catalogCountries[_myCatalogName] ?? <String>[];
      _selectedCatalogs.clear();
      _catalogSelectionMode = false;
    });
  }

  Future<void> _addCatalog() async {
    final controller = TextEditingController(text: 'Мой каталог ${_catalogNames.length + 1}');
    final name = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(title: const Text('Новый каталог'), content: TextField(controller: controller, autofocus: true, maxLength: 32, decoration: const InputDecoration(labelText: 'Название плитки')), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Добавить'))]));
    controller.dispose();
    if (name == null || name.trim().isEmpty) return;
    var uniqueName = name.trim();
    if (_catalogNames.contains(uniqueName)) {
      var suffix = 2;
      while (_catalogNames.contains('$uniqueName ($suffix)')) { suffix++; }
      uniqueName = '$uniqueName ($suffix)';
    }
    final names = [..._catalogNames, uniqueName];
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_myCatalogNamesKey, names);
    await prefs.setStringList(_catalogCountriesKey(uniqueName), <String>[]);
    final createdAt = DateTime.now().millisecondsSinceEpoch;
    await prefs.setInt(_catalogCreatedAtKey(uniqueName), createdAt);
    if (mounted) {
      setState(() { _catalogNames = names; _catalogCountries[uniqueName] = <String>[]; _catalogCreatedAt[uniqueName] = createdAt; });
      // Keep the newly-created tile in view instead of rebuilding the grid at the top.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _homeScrollController.hasClients) {
          _homeScrollController.animateTo(
            _homeScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeOutCubic,
          );
        }
      });
    }
  }

  Future<void> _deleteCatalog(String name) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Удалить каталог?'),
      content: Text('Плитка «$name» и список стран внутри неё будут удалены. Это действие нельзя отменить.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Удалить'))],
    ));
    if (ok != true) return;
    final names = List<String>.from(_catalogNames)..remove(name);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_myCatalogNamesKey, names);
    await prefs.remove(_catalogCountriesKey(name));
    await prefs.remove(_catalogCreatedAtKey(name));
    if (_myCatalogName == name) {
      _myCatalogName = names.isNotEmpty ? names.first : _defaultMyCatalogName;
      await prefs.setString(_myCatalogNameKey, _myCatalogName);
    }
    if (mounted) setState(() { _catalogNames = names; _catalogCountries.remove(name); _catalogCreatedAt.remove(name); _myCountries = _catalogCountries[_myCatalogName] ?? <String>[]; });
  }

  Future<void> _openRegion(_Region region) async {
    final isCatalog = _catalogNames.contains(region.name) || region.name == 'Мой каталог';
    final catalogName = isCatalog ? region.name : null;
    final customRegion = isCatalog
        ? _Region(region.name, region.icon, List<String>.from(_catalogCountries[region.name] ?? <String>[]))
        : region;
    await Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => CountryListPage(
        region: customRegion,
        isMyCatalog: isCatalog,
        catalogName: catalogName,
      ),
    ));
    await _loadCustomData();
  }

  List<_Region> _orderedHomeRegions() {
    final items = [..._regions.where((r) => r.name != 'Мой каталог'), ..._catalogNames.map((name) => _Region(name, Icons.star_border, [])), _Region('__add_catalog__', Icons.add, [])];
    if (_homeSortMode == 'manual' && _tileOrder.isNotEmpty) {
      items.sort((a, b) {
        final ai = _tileOrder.indexOf(a.name); final bi = _tileOrder.indexOf(b.name);
        if (ai < 0 && bi < 0) return 0; if (ai < 0) return 1; if (bi < 0) return -1; return ai.compareTo(bi);
      });
      final addTile = items.firstWhere((r) => r.name == '__add_catalog__');
      items.removeWhere((r) => r.name == '__add_catalog__');
      items.add(addTile);
      return items;
    }
    return _sortHomeRegions(items);
  }

  Widget _buildAlternateHomeView() {
    final items = _orderedHomeRegions();
    Widget itemFor(_Region region) {
      final isAdd = region.name == '__add_catalog__';
      final isCustom = _catalogNames.contains(region.name);
      final title = isCustom ? region.name : isAdd ? 'Добавить каталог' : region.name;
      final count = isCustom ? (_catalogCountries[region.name]?.length ?? 0) : region.countries.length;
      final selected = _selectedCatalogs.contains(region.name);
      final colorValue = isAdd ? _addCatalogTileColorValue : isCustom ? _customTileColorValue : _standardTileColorValue;
      final tileColor = selected ? Theme.of(context).colorScheme.secondaryContainer : colorValue == null ? null : Color(colorValue);
      final content = _homeViewMode == 'list'
          ? Card(color: tileColor, child: ListTile(
              leading: CircleAvatar(child: Icon(selected ? Icons.check : region.icon)),
              title: Text(title, maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: isAdd ? null : Text('$count стран'),
              trailing: isCustom ? IconButton(icon: const Icon(Icons.close), tooltip: 'Удалить каталог', onPressed: () { if (_catalogSelectionMode && selected) { _deleteSelectedCatalogs(); } else { _deleteCatalog(region.name); } }) : null,
              selected: selected,
              
              onTap: () {
                if (_catalogSelectionMode) {
                  if (isCustom) { _toggleCatalogSelection(region.name); }
                  else { setState(() { _selectedCatalogs.clear(); _catalogSelectionMode = false; }); }
                } else if (isAdd) { _addCatalog(); } else { _openRegion(region); }
              },
            ))
          : SizedBox(width: _homeViewMode == 'honeycomb' ? 100 : 94, child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onDoubleTap: isCustom && !_catalogSelectionMode ? () => _renameCatalog(region.name) : null,
              
              onTap: () {
                if (_catalogSelectionMode) {
                  if (isCustom) { _toggleCatalogSelection(region.name); }
                  else { setState(() { _selectedCatalogs.clear(); _catalogSelectionMode = false; }); }
                } else if (isAdd) { _addCatalog(); } else { _openRegion(region); }
              },
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                _homeViewMode == 'honeycomb'
                    ? ClipPath(clipper: _HoneycombClipper(), child: Container(
                        width: 76, height: 70,
                        decoration: BoxDecoration(
                          color: tileColor ?? Theme.of(context).colorScheme.surfaceContainerHighest,
                          boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 5, offset: Offset(0, 2))],
                        ),
                        child: Center(child: Icon(selected ? Icons.check : region.icon, size: 30, color: Theme.of(context).colorScheme.primary)),
                      ))
                    : Container(width: 68, height: 68, decoration: BoxDecoration(
                        color: tileColor ?? Theme.of(context).colorScheme.surfaceContainerHighest,
                        shape: BoxShape.circle, border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
                        boxShadow: const [BoxShadow(color: Color(0x18000000), blurRadius: 5, offset: Offset(0, 2))],
                      ), child: Icon(selected ? Icons.check : region.icon, size: 30, color: Theme.of(context).colorScheme.primary)),
                const SizedBox(height: 5),
                Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                if (!isAdd) Text('$count', style: Theme.of(context).textTheme.labelSmall),
                if (isCustom) IconButton(visualDensity: VisualDensity.compact, constraints: const BoxConstraints.tightFor(width: 28, height: 28), iconSize: 16, tooltip: 'Удалить каталог', onPressed: () { if (_catalogSelectionMode && selected) { _deleteSelectedCatalogs(); } else { _deleteCatalog(region.name); } }, icon: const Icon(Icons.close)),
              ]),
            ));
      final interactiveContent = _homeViewMode == 'list'
          ? GestureDetector(onDoubleTap: isCustom && !_catalogSelectionMode ? () => _renameCatalog(region.name) : null, child: content)
          : content;
      // Keep drag-and-drop reordering available in every home-screen layout.
      return KeyedSubtree(key: ValueKey<String>('alternate-${region.name}'), child: DragTarget<String>(
        onWillAcceptWithDetails: (d) => d.data != region.name && d.data != '__add_catalog__',
        onAcceptWithDetails: (d) => _moveTile(d.data, region.name),
        builder: (context, candidates, rejected) => LongPressDraggable<String>(
          data: region.name,
          delay: const Duration(milliseconds: 500),
          maxSimultaneousDrags: 1,
          onDragStarted: () { _currentDragMoved = false; _holdTimer?.cancel(); },
          onDragUpdate: (details) { if (details.delta.distance > 2) _currentDragMoved = true; },
          onDragEnd: (details) {
            // As in tile mode, a long press without movement selects the catalog;
            // actual movement reorders the item via DragTarget.
            if (isCustom && !_currentDragMoved && mounted) {
              setState(() { _catalogSelectionMode = true; _selectedCatalogs.add(region.name); });
            }
          },
          feedback: Material(color: Colors.transparent, child: Opacity(opacity: .9, child: SizedBox(width: _homeViewMode == 'list' ? 280 : (_homeViewMode == 'honeycomb' ? 100 : 94), child: interactiveContent))),
          childWhenDragging: Opacity(opacity: .25, child: interactiveContent),
          child: interactiveContent,
        ),
      ));
    }
    if (_homeViewMode == 'list') {
      return ListView(padding: const EdgeInsets.all(8), children: items.map(itemFor).toList());
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(12, 18, 12, 24),
      child: Center(child: Wrap(alignment: WrapAlignment.center, spacing: 12, runSpacing: 18, children: items.map(itemFor).toList())),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Row(mainAxisSize: MainAxisSize.min, children: [Text('АМиК SC'), SizedBox(width: 8), Text('v$appVersion TEST', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500))]), centerTitle: false, actions: [PopupMenuButton<String>(tooltip: 'Сортировка каталогов', icon: const Icon(Icons.sort), initialValue: _homeSortMode, onSelected: _setHomeSortMode, itemBuilder: (context) => const [PopupMenuItem(value: 'countAsc', child: Text('По количеству стран: по возрастанию')), PopupMenuItem(value: 'countDesc', child: Text('По количеству стран: по убыванию')), PopupMenuItem(value: 'nameAsc', child: Text('По имени: А–Я')), PopupMenuItem(value: 'nameDesc', child: Text('По имени: Я–А')), PopupMenuItem(value: 'default', child: Text('По умолчанию')), PopupMenuItem(value: 'created', child: Text('По дате создания (сначала старые)')), PopupMenuItem(value: 'createdDesc', child: Text('По дате создания (сначала новые)')), PopupMenuItem(value: 'manual', child: Text('Вручную'))]), IconButton(tooltip: 'Настройки', icon: const Icon(Icons.settings), onPressed: () async { await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AppSettingsPage())); await _loadCustomData(); })]),
    body: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        if (_catalogSelectionMode) {
          setState(() {
            _selectedCatalogs.clear();
            _catalogSelectionMode = false;
          });
        }
      },
      child: Column(children: [
      Expanded(child: _homeViewMode == 'tiles' ? GridView.builder(
        controller: _homeScrollController,
        key: const ValueKey<String>('home-catalog-grid'),
        padding: const EdgeInsets.all(8), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 4, mainAxisSpacing: 4),
        itemCount: _regions.length - 1 + _catalogNames.length + 1,
        itemBuilder: (context, index) {
          final regionsWithCatalogs = _orderedHomeRegions();
          final region = regionsWithCatalogs[index];
          final isAddCatalog = region.name == '__add_catalog__';
          final isMyCatalog = _catalogNames.contains(region.name);
          final title = isMyCatalog ? region.name : isAddCatalog ? 'Добавить каталог' : region.name;
          final count = isMyCatalog ? (_catalogCountries[region.name]?.length ?? 0) : region.countries.length;
          final isSelected = _selectedCatalogs.contains(region.name);
          final tileBaseColorValue = isAddCatalog ? _addCatalogTileColorValue : isMyCatalog ? _customTileColorValue : _standardTileColorValue;
          final tileBaseColor = tileBaseColorValue == null ? null : Color(tileBaseColorValue);
          return KeyedSubtree(key: ValueKey<String>(region.name), child: DragTarget<String>(
            onWillAcceptWithDetails: (details) {
              if (details.data == region.name) return false;
              return true;
            },
            onAcceptWithDetails: (details) => _moveTile(details.data, region.name),
            builder: (context, candidates, rejected) => LongPressDraggable<String>(
              data: region.name,
              delay: const Duration(milliseconds: 500),
              maxSimultaneousDrags: 1,
              onDragStarted: () { _currentDragMoved = false; _holdTimer?.cancel(); },
              onDragUpdate: (details) {
                if (details.delta.distance > 2) _currentDragMoved = true;
              },
              onDragEnd: (details) {
                if (isMyCatalog && !_currentDragMoved && mounted) {
                  _holdActivated = false;
                  setState(() { _catalogSelectionMode = true; _selectedCatalogs.add(region.name); });
                }
              },
              feedback: Material(color: Colors.transparent, child: SizedBox(width: (MediaQuery.of(context).size.width - 20) / 2, height: ((MediaQuery.of(context).size.width - 20) / 2) / 1.55, child: Card(elevation: 8, color: tileBaseColor, child: Padding(padding: const EdgeInsets.fromLTRB(28, 10, 10, 10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(region.icon, size: 30), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)), if (!isAddCatalog) Text('$count стран')]))))),
              childWhenDragging: Opacity(opacity: 0.25, child: Card(child: const SizedBox.expand())),
              child: Card(clipBehavior: Clip.antiAlias, color: candidates.isNotEmpty ? Theme.of(context).colorScheme.primaryContainer : isSelected ? Theme.of(context).colorScheme.secondaryContainer : tileBaseColor, child: Stack(children: [
            Positioned.fill(child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onDoubleTap: isMyCatalog && !_catalogSelectionMode ? () => _renameCatalog(region.name) : null,
              onTap: () {
                _cancelHold();
                if (isMyCatalog && _holdActivated) { _holdActivated = false; return; }
                if (_catalogSelectionMode) {
                  if (isMyCatalog) {
                    // In selection mode, taps on custom catalog tiles toggle only that tile.
                    // Keep selection mode active even when the last selected tile is unchecked.
                    _toggleCatalogSelection(region.name);
                  } else {
                    // Tapping anywhere outside custom catalog tiles clears all selections
                    // and exits selection mode.
                    setState(() {
                      _selectedCatalogs.clear();
                      _catalogSelectionMode = false;
                    });
                  }
                  return;
                }
                if (isAddCatalog) { _addCatalog(); return; }
                _openRegion(region);
              },
              child: Padding(padding: const EdgeInsets.fromLTRB(28, 10, 10, 10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(region.icon, size: 30, color: Theme.of(context).colorScheme.primary), const SizedBox(height: 8),
                Text(title, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                if (!isAddCatalog) Text('$count стран', style: Theme.of(context).textTheme.labelSmall),
                if (isSelected) const Padding(padding: EdgeInsets.only(top: 4), child: Icon(Icons.check_circle, size: 20)),
              ])),
            )),
            if (isMyCatalog) Positioned(top: 0, right: 0, child: IconButton(
              padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 30),
              visualDensity: VisualDensity.compact, tooltip: 'Удалить каталог',
              icon: Icon(Icons.close, size: 16, color: Theme.of(context).colorScheme.error),
              onPressed: () { if (_catalogSelectionMode && isSelected) { _deleteSelectedCatalogs(); } else { _deleteCatalog(region.name); } },
            )),
          ])),
            ),
          ));
        }) : _buildAlternateHomeView()),
    ]),
    ),
  );
}

// ISO 3166-1 alpha-2 codes used to render actual country flag artwork.
const Map<String, String> _countryIsoCodes = {
  'Албания':'AL', 'Андорра':'AD', 'Австрия':'AT', 'Беларусь':'BY', 'Белоруссия':'BY',
  'Бельгия':'BE', 'Болгария':'BG', 'Босния и Герцеговина':'BA', 'Ватикан':'VA',
  'Великобритания':'GB', 'Венгрия':'HU', 'Германия':'DE', 'Греция':'GR', 'Дания':'DK',
  'Ирландия':'IE', 'Исландия':'IS', 'Испания':'ES', 'Италия':'IT', 'Кипр':'CY',
  'Косово':'XK', 'Латвия':'LV', 'Литва':'LT', 'Лихтенштейн':'LI', 'Люксембург':'LU',
  'Мальта':'MT', 'Молдова':'MD', 'Монако':'MC', 'Нидерланды':'NL', 'Норвегия':'NO',
  'Польша':'PL', 'Португалия':'PT', 'Россия':'RU', 'Румыния':'RO', 'Сан-Марино':'SM',
  'Северная Македония':'MK', 'Сербия':'RS', 'Словакия':'SK', 'Словения':'SI',
  'Турция':'TR', 'Украина':'UA', 'Финляндия':'FI', 'Франция':'FR', 'Хорватия':'HR',
  'Черногория':'ME', 'Чехия':'CZ', 'Швейцария':'CH', 'Швеция':'SE', 'Эстония':'EE',
  'Азербайджан':'AZ', 'Армения':'AM', 'Афганистан':'AF', 'Бангладеш':'BD', 'Бахрейн':'BH',
  'Бруней':'BN', 'Бутан':'BT', 'Вьетнам':'VN', 'Грузия':'GE', 'Израиль':'IL', 'Индия':'IN',
  'Индонезия':'ID', 'Иордания':'JO', 'Ирак':'IQ', 'Иран':'IR', 'Йемен':'YE', 'Казахстан':'KZ',
  'Камбоджа':'KH', 'Катар':'QA', 'Китай':'CN', 'КНДР':'KP', 'Кувейт':'KW', 'Кыргызстан':'KG',
  'Лаос':'LA', 'Ливан':'LB', 'Малайзия':'MY', 'Мальдивы':'MV', 'Монголия':'MN', 'Мьянма':'MM',
  'Непал':'NP', 'ОАЭ':'AE', 'Оман':'OM', 'Пакистан':'PK', 'Палестина':'PS',
  'Саудовская Аравия':'SA', 'Сингапур':'SG', 'Сирия':'SY', 'Таджикистан':'TJ', 'Таиланд':'TH',
  'Тайвань':'TW', 'Тимор-Лесте':'TL', 'Туркменистан':'TM', 'Узбекистан':'UZ',
  'Филиппины':'PH', 'Шри-Ланка':'LK', 'Южная Корея':'KR', 'Япония':'JP',
  'Алжир':'DZ', 'Ангола':'AO', 'Бенин':'BJ', 'Ботсвана':'BW', 'Буркина-Фасо':'BF',
  'Бурунди':'BI', 'Габон':'GA', 'Гамбия':'GM', 'Гана':'GH', 'Гвинея':'GN',
  'Гвинея-Бисау':'GW', 'Джибути':'DJ', 'Египет':'EG', 'Замбия':'ZM', 'Зимбабве':'ZW',
  'Кабо-Верде':'CV', 'Камерун':'CM', 'Кения':'KE', 'Коморы':'KM', 'Лесото':'LS',
  'Либерия':'LR', 'Ливия':'LY', 'Маврикий':'MU', 'Мавритания':'MR', 'Мадагаскар':'MG',
  'Малави':'MW', 'Мали':'ML', 'Марокко':'MA', 'Мозамбик':'MZ', 'Намибия':'NA',
  'Нигер':'NE', 'Нигерия':'NG', 'Руанда':'RW', 'Сейшелы':'SC', 'Сенегал':'SN',
  'Сомали':'SO', 'Судан':'SD', 'Сьерра-Леоне':'SL', 'Танзания':'TZ', 'Того':'TG',
  'Тунис':'TN', 'Уганда':'UG', 'Чад':'TD', 'Эритрея':'ER', 'Эсватини':'SZ',
  'Эфиопия':'ET', 'ЮАР':'ZA', 'Южный Судан':'SS',
  'Антигуа и Барбуда':'AG', 'Багамы':'BS', 'Барбадос':'BB', 'Белиз':'BZ', 'Гаити':'HT',
  'Гватемала':'GT', 'Гондурас':'HN', 'Гренада':'GD', 'Доминика':'DM',
  'Доминиканская Республика':'DO', 'Канада':'CA', 'Коста-Рика':'CR', 'Куба':'CU',
  'Мексика':'MX', 'Никарагуа':'NI', 'Панама':'PA', 'Сальвадор':'SV', 'США':'US',
  'Тринидад и Тобаго':'TT', 'Ямайка':'JM', 'Аргентина':'AR', 'Боливия':'BO',
  'Бразилия':'BR', 'Венесуэла':'VE', 'Гайана':'GY', 'Колумбия':'CO', 'Парагвай':'PY',
  'Перу':'PE', 'Суринам':'SR', 'Уругвай':'UY', 'Чили':'CL', 'Эквадор':'EC',
  'Австралия':'AU', 'Вануату':'VU', 'Кирибати':'KI', 'Маршалловы Острова':'MH',
  'Микронезия':'FM', 'Науру':'NR', 'Новая Зеландия':'NZ', 'Палау':'PW',
  'Папуа — Новая Гвинея':'PG', 'Самоа':'WS', 'Соломоновы Острова':'SB', 'Тонга':'TO',
  'Тувалу':'TV', 'Фиджи':'FJ', 'Гуам':'GU', 'Новая Каледония':'NC', 'Острова Кука':'CK',
  'Абхазия':'GE',
};

Widget _countryFlag(String country) {
  final code = _countryIsoCodes[country];
  if (code == null) return const SizedBox(width: 36, height: 24, child: Icon(Icons.flag_outlined));
  return ClipRRect(
    borderRadius: BorderRadius.circular(3),
    child: CountryFlag.fromCountryCode(
      code,
      theme: const ImageTheme(width: 36, height: 24),
    ),
  );
}

class CountryListPage extends StatefulWidget {
  final _Region region;
  final bool isMyCatalog;
  final String? catalogName;
  const CountryListPage({super.key, required this.region, this.isMyCatalog = false, this.catalogName});
  @override
  State<CountryListPage> createState() => _CountryListPageState();
}

class _CountryListPageState extends State<CountryListPage> {
  String query = '';
  late List<String> _myCountries;
  List<String> _catalogNames = [_defaultMyCatalogName];
  Set<String> _allCatalogCountries = {};
  Map<String, List<String>> _countryCatalogMembership = {};
  OverlayEntry? _membershipOverlay;
  Timer? _membershipHideTimer;
  Timer? _membershipPressTimer;
  bool _membershipPressActivated = false;

  @override
  void initState() {
    super.initState();
    _myCountries = List<String>.from(widget.region.countries);
    _loadMyCountries();
  }

  Future<void> _loadMyCountries() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _myCountries = prefs.getStringList(_catalogCountriesKey(widget.catalogName ?? _defaultMyCatalogName)) ?? [];
      _catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? [_defaultMyCatalogName];
      _countryCatalogMembership = {
        for (final country in widget.region.countries)
          country: _catalogNames.where((n) => (prefs.getStringList(_catalogCountriesKey(n)) ?? <String>[]).contains(country)).toList(),
      };
      _allCatalogCountries = _countryCatalogMembership.entries.where((e) => e.value.isNotEmpty).map((e) => e.key).toSet();
    });
  }

  void _showMembershipOverlay(String country, BuildContext anchorContext) {
    _membershipHideTimer?.cancel();
    _membershipPressTimer?.cancel();
    _membershipOverlay?.remove();
    _membershipOverlay = null;
    final catalogs = _countryCatalogMembership[country] ?? <String>[];
    if (catalogs.isEmpty) return;
    final box = anchorContext.findRenderObject() as RenderBox?;
    final overlay = Overlay.of(context);
    if (box == null || !box.hasSize) return;
    final origin = box.localToGlobal(Offset.zero);
    final screen = MediaQuery.of(context).size;
    final left = (origin.dx - 210).clamp(8.0, screen.width - 240.0);
    final top = (origin.dy - 8).clamp(8.0, screen.height - 180.0);
    _membershipOverlay = OverlayEntry(builder: (context) => Positioned(
      left: left,
      top: top,
      child: Material(
        color: Colors.transparent,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 230, maxHeight: screen.height * 0.45),
          child: Card(
            elevation: 10,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('«$country» добавлена в:', style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Flexible(child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final name in catalogs) Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Text('• $name'))]))),
              ]),
            ),
          ),
        ),
      ),
    ));
    overlay.insert(_membershipOverlay!);
  }

  void _finishMembershipPress() {
    _membershipHideTimer?.cancel();
    _membershipHideTimer = Timer(const Duration(seconds: 2), _hideMembershipOverlay);
  }

  void _hideMembershipOverlay() {
    _membershipOverlay?.remove();
    _membershipOverlay = null;
  }

  Future<void> _toggleMyCountry(String country) async {
    final prefs = await SharedPreferences.getInstance();
    String? targetName = widget.catalogName;
    var removeMembership = false;
    if (!widget.isMyCatalog) {
      _catalogNames = prefs.getStringList(_myCatalogNamesKey) ?? _catalogNames;
      final currentMembership = _catalogNames.where((name) => (prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[]).contains(country)).toSet();
      final action = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
        title: Text('Добавить «$country» в каталог'),
        content: SizedBox(width: double.maxFinite, child: ListView(shrinkWrap: true, children: [
          for (final name in _catalogNames) ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(name),
            trailing: currentMembership.contains(name)
                ? IconButton(tooltip: 'Исключить страну из $name', icon: const Icon(Icons.delete_outline), onPressed: () => Navigator.pop(ctx, 'remove|$name'))
                : const Icon(Icons.add_circle_outline),
            onTap: currentMembership.contains(name) ? null : () => Navigator.pop(ctx, 'add|$name'),
            subtitle: currentMembership.contains(name) ? const Text('Страна уже добавлена') : null,
          ),
        ])),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, '__cancel__'), child: const Text('Закрыть'))],
      ));
      if (action == null || action == '__cancel__') return;
      final parts = action.split('|');
      if (parts.length != 2) return;
      removeMembership = parts[0] == 'remove';
      targetName = parts[1];
    }
    final key = _catalogCountriesKey(targetName ?? _defaultMyCatalogName);
    final list = prefs.getStringList(key) ?? <String>[];
    if (widget.isMyCatalog || removeMembership || list.contains(country)) {
      list.remove(country);
    } else {
      list.add(country);
    }
    await prefs.setStringList(key, list);
    final refreshedMembership = <String>[];
    for (final name in _catalogNames) {
      if ((prefs.getStringList(_catalogCountriesKey(name)) ?? <String>[]).contains(country)) refreshedMembership.add(name);
    }
    if (!mounted) return;
    setState(() {
      if (widget.isMyCatalog) _myCountries = list;
      _countryCatalogMembership[country] = refreshedMembership;
      if (refreshedMembership.isEmpty) { _allCatalogCountries.remove(country); } else { _allCatalogCountries.add(country); }
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(widget.isMyCatalog || removeMembership || !list.contains(country) ? 'Страна удалена из «${targetName ?? _defaultMyCatalogName}»' : 'Страна добавлена в «$targetName»'),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  void dispose() {
    _membershipHideTimer?.cancel();
    _membershipPressTimer?.cancel();
    _hideMembershipOverlay();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final sourceCountries = widget.isMyCatalog ? _myCountries : widget.region.countries;
    final countries = sourceCountries.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList()
      ..sort((a,b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return Scaffold(appBar: AppBar(title: Text(widget.region.name)), body: Column(children: [
      if (widget.isMyCatalog) Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () async { final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Очистить Мой каталог?'), content: const Text('Все страны будут удалены из этого списка.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Убрать все'))])); if (ok == true) { final prefs = await SharedPreferences.getInstance(); await prefs.setStringList(_catalogCountriesKey(widget.catalogName ?? _defaultMyCatalogName), []); if (mounted) setState(() => _myCountries = []); } }, icon: const Icon(Icons.delete_sweep_outlined), label: const Text('Убрать все страны')))),
      Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 4), child: SearchBar(leading: const Icon(Icons.search), hintText: 'Поиск страны или территории', onChanged: (v) => setState(() => query = v),)),
      Expanded(
        child: countries.isEmpty
            ? Center(child: Text(widget.isMyCatalog ? 'Список пуст. Откройте часть света и нажмите + у нужных стран.' : 'Ничего не найдено', textAlign: TextAlign.center))
            : ListView.separated(
                itemCount: countries.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (context, index) {
                  final country = countries[index];
                  final isAdded = _allCatalogCountries.contains(country);
                  return ListTile(
                    leading: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: country == 'Австрия' ? () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const AustriaInfoPage())) : null,
                      child: Padding(padding: const EdgeInsets.all(4), child: _countryFlag(country)),
                    ),
                    title: Text(country),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Builder(builder: (iconContext) => GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapDown: isAdded && !widget.isMyCatalog ? (_) {
                          _membershipPressActivated = false;
                          _membershipPressTimer?.cancel();
                          _membershipPressTimer = Timer(const Duration(milliseconds: 500), () {
                            if (!mounted) return;
                            _membershipPressActivated = true;
                            _showMembershipOverlay(country, iconContext);
                          });
                        } : null,
                        onTapUp: isAdded && !widget.isMyCatalog ? (_) {
                          _membershipPressTimer?.cancel();
                          if (_membershipPressActivated) _finishMembershipPress();
                        } : null,
                        onTapCancel: isAdded && !widget.isMyCatalog ? () {
                          _membershipPressTimer?.cancel();
                          if (_membershipPressActivated) _finishMembershipPress();
                        } : null,
                        onTap: () {
                          if (_membershipPressActivated) { _membershipPressActivated = false; return; }
                          _toggleMyCountry(country);
                        },
                        child: SizedBox(width: 48, height: 48, child: Center(child: Icon(
                          widget.isMyCatalog ? Icons.remove_circle_outline : isAdded ? Icons.check_circle : Icons.add_circle_outline,
                          color: isAdded && !widget.isMyCatalog ? Theme.of(context).colorScheme.primary : null,
                        ))),
                      )),
                      const Icon(Icons.chevron_right),
                    ]),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => country == 'Австрия' ? const AustriaPeriodsPage() : UcoinCountryPage(country: country))),
                  );
                },
              ),
      ),
    ]));
  }
}



const List<_AustriaPeriod> _austriaPeriods = [
  _AustriaPeriod('Европейский союз (Евро)', '2002 - 2026', 311),
  _AustriaPeriod('ЭКЮ', '1979 - 1998', 759),
  _AustriaPeriod('Вторая Республика', '1946 - 2001', 59),
  _AustriaPeriod('Первая Республика (Шиллинг)', '1925 - 1938', 242),
  _AustriaPeriod('Первая Республика (Крона)', '1923 - 1924', 0),
  _AustriaPeriod('Австро-венгерская крона', '1892 - 1918', 299),
  _AustriaPeriod('Австро-венгерский гульден', '1857 - 1892', 548),
  _AustriaPeriod('Австрийская империя', '1806 - 1857', 675),
  _AustriaPeriod('Священная Римская империя (Крейцер)', '1741 - 1806', 0),
  _AustriaPeriod('Священная Римская империя (Талер)', '1741 - 1805', 858),
  _AustriaPeriod('Священная Римская империя', '1705 - 1740', 0),
  _AustriaPeriod('Священная Римская империя', '1658 - 1704', 1043),
  _AustriaPeriod('Священная Римская империя', '1608 - 1657', 0),
  _AustriaPeriod('Священная Римская империя', '1520 - 1607', 1341),
];
class _AustriaPeriod { final String name, years; final int ucoinId; const _AustriaPeriod(this.name, this.years, this.ucoinId); }

class AustriaPeriodsPage extends StatefulWidget {
  const AustriaPeriodsPage({super.key});
  @override State<AustriaPeriodsPage> createState() => _AustriaPeriodsPageState();
}

class _AustriaPeriodsPageState extends State<AustriaPeriodsPage> {
  Map<String, int> _ownedByPeriod = {};
  @override void initState() { super.initState(); _loadPeriodCounts(); }
  Future<void> _loadPeriodCounts() async {
    final prefs = await SharedPreferences.getInstance();
    final result = <String, int>{};
    for (final period in _austriaPeriods) {
      final key = 'austria_coin_counts_v2_${period.years}_${period.name}';
      final raw = prefs.getString(key);
      if (raw == null) { result[key] = 0; continue; }
      try { final data = jsonDecode(raw) as Map<String, dynamic>; result[key] = data.values.where((value) => value is num && value > 0).length; }
      catch (_) { result[key] = 0; }
    }
    if (mounted) setState(() => _ownedByPeriod = result);
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Австрия — периоды')),
    body: ListView(padding: const EdgeInsets.all(8), children: [
      for (final p in _austriaPeriods) Card(child: ListTile(
        title: Text(p.name), subtitle: Text(p.years),
        leading: IconButton(tooltip: 'Сохранить каталог для работы офлайн', icon: const Icon(Icons.download_for_offline_outlined), onPressed: () async {
          try { final dir = await _saveAustriaPeriod(p); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Каталог сохранён: $dir'))); }
          catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось сохранить: $e'))); }
        }),
        trailing: Text('${p.ucoinId == 311 ? _austriaEuroCoinsByYear().length : 0}/${_ownedByPeriod['austria_coin_counts_v2_${p.years}_${p.name}'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w700)),
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => AustriaCategoriesPage(period: p))),
      )),
      const Padding(padding: EdgeInsets.all(8), child: Text('Источник периодов и категорий: ru.ucoin.net/catalog/?country=austria', style: TextStyle(fontSize: 12, color: Colors.black54))),
    ]));
}

class AustriaCategoriesPage extends StatelessWidget {
  final _AustriaPeriod period;
  const AustriaCategoriesPage({super.key, required this.period});
  static const _categories = <(String, int)>[
    ('Регулярный чекан', 1), ('Юбилейные монеты', 2), ('Коллекционные монеты', 3),
  ];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('Австрия — ${period.name}')),
    body: ListView(padding: const EdgeInsets.all(8), children: [
      Padding(padding: const EdgeInsets.all(8), child: Text(period.years, style: Theme.of(context).textTheme.titleMedium)),
      for (final category in _categories) Card(child: ListTile(
        leading: const Icon(Icons.monetization_on_outlined),
        title: Text(category.$1),
        subtitle: Text(period.ucoinId == 311 ? (category.$2 == 1 ? '13 разновидностей регулярного чекана' : category.$2 == 2 ? 'Отдельный учёт памятных выпусков' : 'Отдельный учёт коллекционных выпусков') : 'Каталог uCoin: название, номинал и год выпуска' ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) =>
          period.ucoinId == 311
            ? (category.$2 == 1 ? AustriaCoinsPage(period: period) : AustriaEuroCategoryTrackerPage(period: period, categoryType: category.$2, categoryName: category.$1))
            : (period.ucoinId > 0
                ? AustriaHistoricalCategoryPage(period: period, categoryType: category.$2, categoryName: category.$1)
                : UcoinCountryPage(country: 'Австрия', categoryType: category.$2)))),
      )),
      const Padding(padding: EdgeInsets.all(8), child: Text('Для периода евро сохранены существующие трекеры без изменений. Для остальных периодов открывается соответствующая категория каталога uCoin; список выпусков зависит от данных источника.', style: TextStyle(fontSize: 12, color: Colors.black54))),
    ]));
}


// Live uCoin list for Austrian commemorative and collector coins.
// Each visible row is extracted from the selected uCoin category, rather than
// generating guessed denomination/year slots.
class AustriaEuroCategoryTrackerPage extends StatefulWidget {
  final _AustriaPeriod period;
  final int categoryType;
  final String categoryName;
  const AustriaEuroCategoryTrackerPage({super.key, required this.period, required this.categoryType, required this.categoryName});
  @override State<AustriaEuroCategoryTrackerPage> createState() => _AustriaEuroCategoryTrackerPageState();
}
class _AustriaEuroCategoryTrackerPageState extends State<AustriaEuroCategoryTrackerPage> {
  Map<String,int> counts = {};
  List<Map<String,String>> coins = [];
  bool sortByYear = false;
  bool loading = true;
  String? error;
  late final WebViewController _web;
  String get storageKey => 'austria_euro_category_${widget.period.years}_${widget.categoryType}_counts_v3';
  String get catalogCacheKey => 'austria_euro_category_catalog_${widget.categoryType}_v1';
  String get ucoinUrl => 'https://ru.ucoin.net/catalog/?country=austria&period=311&type=${widget.categoryType}';

  @override void initState() {
    super.initState();
    _loadCachedCoins();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) => _extractCoins(),
        onWebResourceError: (e) { if (e.isForMainFrame == true && mounted) setState(() { loading = false; error = 'Не удалось загрузить uCoin. Проверьте интернет и нажмите «Обновить».'; }); },
      ))
      ..loadRequest(Uri.parse(ucoinUrl));
    _loadCounts();
  }

  List<Map<String,String>> _offlineSeedCoins() {
    final source = 'https://ru.ucoin.net/catalog/?country=austria&period=311&type=${widget.categoryType}';
    final raw = widget.categoryType == 2
      ? <List<String>>[
          ['2 евро','2005','Договор о нейтралитете Австрии',''],
          ['2 евро','2007','Римский договор',''],
          ['2 евро','2009','Экономический и валютный союз',''],
          ['2 евро','2012','10 лет наличному евро',''],
          ['2 евро','2015','30 лет флагу Европейского союза',''],
          ['2 евро','2016','200 лет Национальному банку Австрии',''],
          ['2 евро','2022','35 лет программе Erasmus',''],
          ['2 евро','2025','75 лет декларации Шумана',''],
        ]
      : <List<String>>[
          ['1½ евро','2008–2026','Венская филармония','KM# 3159'],
          ['1½ евро','2019','Леопольд V','UC# 233'],
          ['1½ евро','2019','Винер-Нойштадт','UC# 234'],
          ['1½ евро','2019','Робин Гуд','UC# 247'],
          ['3 евро','2016','Летучая мышь','KM# 3256'],
          ['3 евро','2017','Тигр','KM# 3262'],
          ['3 евро','2017','Крокодил','KM# 3263'],
          ['3 евро','2017','Зимородок обыкновенный','KM# 3264'],
          ['3 евро','2017','Волк','KM# 3265'],
          ['3 евро','2018','Попугай','UC# 218'],
          ['3 евро','2018','Акула','UC# 223'],
          ['3 евро','2018','Сова','UC# 226'],
          ['3 евро','2018','Лягушка','UC# 227'],
          ['3 евро','2019','Черепаха','UC# 232'],
          ['3 евро','2019','Выдра','UC# 239'],
          ['3 евро','2019','Речной рак','UC# 243'],
          ['3 евро','2019','Спинозавр','UC# 248'],
          ['3 евро','2020','Мозазавр','UC# 252'],
          ['3 евро','2020','Арамбургиана','UC# 266'],
          ['3 евро','2020','Анкилозавр','UC# 268'],
          ['3 евро','2020','Тираннозавр Рекс','UC# 272'],
          ['3 евро','2021','Теризинозавр','UC# 279'],
          ['3 евро','2021','Дейноних','UC# 290'],
          ['3 евро','2021','Стиракозавр','UC# 291'],
          ['3 евро','2021','Аргентинозавр','UC# 298'],
          ['3 евро','2022','Микрораптор','UC# 303'],
          ['3 евро','2022','Пахицефалозавр','UC# 311'],
          ['3 евро','2022','Орнитомим','UC# 339'],
          ['3 евро','2022','Синекольчатый осьминог','UC# 342'],
          ['3 евро','2023','Калифорнийская раздувающаяся акула','UC# 348'],
          ['3 евро','2023','Антарктический криль','UC# 359'],
          ['3 евро','2023','Глубоководный удильщик','UC# 360'],
          ['3 евро','2023','Каменный коралл','UC# 366'],
          ['3 евро','2024','Светящаяся медуза','UC# 373'],
          ['3 евро','2024','Голубая рыба-хирург','UC# 386'],
          ['3 евро','2024','Гавайский кальмар','UC# 389'],
          ['3 евро','2024','Жёлтый скат','UC# 393'],
          ['3 евро','2025','Кальмар-светлячок','UC# 418'],
          ['3 евро','2025','Голожаберный моллюск','UC# 427'],
          ['3 евро','2025','Дьявольский скорпенопсис','UC# 431'],
          ['3 евро','2025','Тролль','UC# 433'],
          ['3 евро','2026','Гиппокампус','UC# 439'],
          ['3 евро','2026','Эльф','UC# 455'],
          ['4 евро','2014–2026','Венская филармония (золото)','KM# 3226'],
          ['4 евро','2017–2026','Венская филармония (платина)','KM# 3276'],
        ];
    return [for (var i=0; i<raw.length; i++) {
      'id':'offline_${widget.categoryType}_${i}_${raw[i][1]}_${raw[i][2]}',
      'title':raw[i][2], 'subject':raw[i][2], 'denomination':raw[i][0],
      'year':raw[i][1], 'catalog':raw[i][3], 'text':'${raw[i][0]} ${raw[i][1]} · ${raw[i][2]}',
      'url':source
    }];
  }

  Future<void> _loadCachedCoins() async {
    final prefs = await SharedPreferences.getInstance();
    final cached = prefs.getString(catalogCacheKey);
    if (cached != null) {
      try {
        final decoded = jsonDecode(cached) as List<dynamic>;
        final parsed = decoded.whereType<Map>().map((e) => e.map((k,v) => MapEntry('$k','$v'))).toList();
        if (parsed.isNotEmpty && mounted) setState(() { coins = parsed; loading = false; error = 'Офлайн-каталог: сохранённые данные uCoin'; });
        return;
      } catch (_) {}
    }
    if (mounted && coins.isEmpty) setState(() { coins = _offlineSeedCoins(); loading = false; error = 'Показан встроенный офлайн-список. Подключитесь к интернету, чтобы обновить данные uCoin и сохранить их на устройстве.'; });
  }

  Future<void> _loadCounts() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(storageKey);
    if (raw == null) return;
    try {
      final m = (jsonDecode(raw) as Map<String,dynamic>).map((k,v) => MapEntry(k, (v as num).toInt()));
      if (mounted) setState(() => counts = m);
    } catch (_) {}
  }

  Future<void> _extractCoins() async {
    try {
      await _web.runJavaScript(r'''(async () => {
        const clean = s => (s || '').replace(/\s+/g, ' ').trim();
        const current = new URL(location.href);
        const parseDoc = (doc, pageUrl) => {
          const out = [], seen = new Set();
          for (const a of Array.from(doc.querySelectorAll('a[href]')).filter(x => /\/(coin|coins)\//i.test(x.getAttribute('href') || ''))) {
            const href = new URL(a.getAttribute('href'), pageUrl).href;
            if (!href || seen.has(href)) continue;
            const card = a.closest('article,li,.coin,.coin-item,.catalog-item,.item') || a.parentElement?.parentElement || a.parentElement;
            const raw = (card && (card.innerText || card.textContent)) || a.innerText || a.textContent || '';
            const lines = raw.split(/\n+/).map(clean).filter(Boolean);
            const text = clean(raw);
            if (!text || text.length < 4) continue;
            seen.add(href);
            const denomLine = lines.find(line => /\d+(?:[.,]\d+)?\s*(?:евроцентов?|евроцент|евро|цент(?:ов)?|копеек?|руб(?:лей|ля|ль)?)/i.test(line) && /\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b/.test(line));
            const year = (denomLine || text).match(/\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b/);
            const denom = (denomLine || text).match(/\d+(?:[.,]\d+)?\s*(?:евроцентов?|евроцент|евро|цент(?:ов)?|копеек?|руб(?:лей|ля|ль)?)/i);
            const cat = text.match(/\b(?:KM|UC|Y|C|N|H|M)\s*#?\s*[A-Z0-9.\/-]+/i);
            const yearValue = year ? year[0] : '';
            const denomValue = denom ? denom[0].replace(/\s+/g,' ') : '';
            const titleLine = clean(a.getAttribute('title') || a.innerText || a.textContent);
            const detailLine = lines.find(line => line !== titleLine && !/\d+(?:[.,]\d+)?\s*(?:евроцентов?|евроцент|евро|цент(?:ов)?|копеек?|руб(?:лей|ля|ль)?)/i.test(line) && !/\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b/.test(line) && !/\b(?:KM|UC|Y|C|N|H|M)\s*#?/i.test(line) && line.length > 3);
            const subject = (titleLine && !/\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b/.test(titleLine) && !/\d+(?:[.,]\d+)?\s*(?:евроцентов?|евроцент|евро)/i.test(titleLine)) ? titleLine : (detailLine || titleLine || '');
            out.push({id:href,title:subject || 'Монета',subject:subject || 'Монета',year:yearValue,denomination:denomValue,catalog:cat?cat[0]:'',text:text.slice(0,300),url:href});
          }
          return out;
        };
        const pageSet = new Set([location.href]);
        for (const a of Array.from(document.querySelectorAll('a[href]'))) {
          if (!/^\d+$/.test(clean(a.textContent))) continue;
          try {
            const u = new URL(a.getAttribute('href'), location.href);
            if (u.pathname !== current.pathname) continue;
            for (const key of ['country','period','type']) if (!u.searchParams.has(key) && current.searchParams.has(key)) u.searchParams.set(key,current.searchParams.get(key));
            if (u.searchParams.get('country') === current.searchParams.get('country') && u.searchParams.get('period') === current.searchParams.get('period') && u.searchParams.get('type') === current.searchParams.get('type')) pageSet.add(u.href);
          } catch (_) {}
        }
        const pages = Array.from(pageSet).slice(0, 10);
        const all = new Map();
        for (const url of pages) {
          try {
            let doc;
            if (url === location.href) doc = document;
            else { const response = await fetch(url, {credentials:'same-origin'}); if (!response.ok) continue; doc = new DOMParser().parseFromString(await response.text(),'text/html'); }
            for (const row of parseDoc(doc,url)) if (!all.has(row.id)) all.set(row.id,row);
          } catch (_) {}
        }
        window.__numisUcoinRows = Array.from(all.values());
        window.__numisUcoinReady = true;
      })().catch(() => { window.__numisUcoinRows = []; window.__numisUcoinReady = true; });''');
      List<Map<String,String>> rows = [];
      for (var attempt = 0; attempt < 30; attempt++) {
        await Future<void>.delayed(const Duration(milliseconds: 500));
        final result = await _web.runJavaScriptReturningResult("JSON.stringify(window.__numisUcoinReady ? (window.__numisUcoinRows || []) : null)");
        var decoded = result.toString();
        if (decoded.startsWith('"') && decoded.endsWith('"')) { try { decoded = jsonDecode(decoded) as String; } catch (_) {} }
        if (decoded == 'null' || decoded.isEmpty) continue;
        try {
          final data = jsonDecode(decoded);
          if (data is List) rows = data.whereType<Map>().map((e) => e.map((k,v) => MapEntry('$k','$v'))).where((e) => (e['text']??'').isNotEmpty).toList();
        } catch (_) {}
        break;
      }
      if (rows.isNotEmpty) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(catalogCacheKey, jsonEncode(rows));
      }
      if (mounted) setState(() { if (rows.isNotEmpty) coins = rows; loading = false; error = rows.isEmpty ? 'Не удалось загрузить каталог uCoin. Используется встроенный или сохранённый офлайн-список.' : null; });
    } catch (_) {
      if (mounted) setState(() { loading = false; error = 'Не удалось прочитать uCoin. Используется встроенный или сохранённый офлайн-список.'; });
    }
  }

  String _id(Map<String,String> c) => c['id'] ?? c['url'] ?? '${c['title']}_${c['year']}';
  Future<void> _setCount(String id, int value) async {
    final next = Map<String,int>.from(counts)..[id] = value < 0 ? 0 : value;
    setState(() => counts = next);
    final p = await SharedPreferences.getInstance(); await p.setString(storageKey, jsonEncode(next));
  }
  Future<void> _edit(String id) async {
    final c = TextEditingController(text: '${counts[id]??0}');
    final n = await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Количество монет'),content:TextField(controller:c,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'В наличии')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Отмена')),FilledButton(onPressed:(){final v=int.tryParse(c.text);if(v!=null&&v>=0)Navigator.pop(ctx,v);},child:const Text('Сохранить'))]));
    c.dispose(); if (n != null) await _setCount(id,n);
  }
  Future<void> _reset() async {
    final yes = await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Сбросить количество?'),content:Text('Будут обнулены отметки только в категории «${widget.categoryName}». '),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Сбросить'))]));
    if (yes != true) return;
    final p = await SharedPreferences.getInstance(); await p.remove(storageKey);
    if (mounted) setState(() => counts = {});
  }
  Future<void> _export(List<Map<String,String>> rows) async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Австрия_Евро_${widget.categoryType==2?'Юбилейные':'Коллекционные'}'); await dir.create(recursive:true);
    final data = {'страна':'Австрия','период':widget.period.name,'категория':widget.categoryName,'источник':ucoinUrl,'монеты':rows.map((c)=>{'название':c['title'],'номинал':c['denomination'],'год':c['year'],'каталожный номер':c['catalog'],'количество':counts[_id(c)]??0,'uCoin':c['url']}).toList()};
    await File('${dir.path}/catalog.json').writeAsString(const JsonEncoder.withIndent('  ').convert(data),flush:true);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Каталог сохранён: ${dir.path}')));
  }

  @override Widget build(BuildContext context) {
    final rows = List<Map<String,String>>.from(coins);
    rows.sort((a,b) => sortByYear ? (a['year']??'').compareTo(b['year']??'') : (a['denomination']??'').compareTo(b['denomination']??''));
    final total = counts.values.fold<int>(0,(a,b)=>a+b);
    return Scaffold(appBar:AppBar(title:Text('Австрия — ${widget.categoryName}'),actions:[IconButton(tooltip:'Обновить uCoin',onPressed:()=>_web.reload(),icon:const Icon(Icons.refresh)),IconButton(tooltip:'Открыть uCoin',onPressed:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:311,categoryType:widget.categoryType))),icon:const Icon(Icons.open_in_new))]),
      body:Stack(children:[ListView(padding:const EdgeInsets.all(8),children:[Text('Евро · 2002–2026',style:Theme.of(context).textTheme.titleMedium),Text('Источник: uCoin · позиций: ${coins.length} · отмечено: ${counts.values.where((v)=>v>0).length} · экземпляров: $total'),if(error!=null)Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(error!,style:const TextStyle(color:Colors.deepOrange))),const SizedBox(height:6),Wrap(spacing:8,children:[ChoiceChip(label:const Text('По номиналу'),selected:!sortByYear,onSelected:(_)=>setState(()=>sortByYear=false)),ChoiceChip(label:const Text('По годам'),selected:sortByYear,onSelected:(_)=>setState(()=>sortByYear=true)),OutlinedButton.icon(onPressed:_reset,icon:const Icon(Icons.delete_sweep_outlined),label:const Text('Сбросить количество')),OutlinedButton.icon(onPressed:()=>_export(rows),icon:const Icon(Icons.download),label:const Text('Экспорт JSON'))]),const SizedBox(height:4),if(!loading&&rows.isEmpty)const Padding(padding:EdgeInsets.all(16),child:Text('Монеты не найдены. Обновите список или откройте uCoin.')),for(final c in rows)Builder(builder:(context){final id=_id(c);final n=counts[id]??0;final subject=(c['subject']??c['title']??'').trim().isEmpty?'Монета':(c['subject']??c['title']!);final denomination=(c['denomination']??'').trim();final year=(c['year']??'').trim();final fullTitle='${denomination.isEmpty?'Монета':denomination}${year.isEmpty?'':' $year'}\n$subject';final meta=[if((c['catalog']??'').isNotEmpty)c['catalog']].join(' · ');return Card(child:ListTile(leading:const Icon(Icons.monetization_on_outlined),title:Text(fullTitle),subtitle:Text(meta.isEmpty?(c['text']??''):meta),trailing:SizedBox(width:132,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[IconButton(onPressed:n>0?()=>_setCount(id,n-1):null,icon:const Icon(Icons.remove_circle_outline)),GestureDetector(onTap:()=>_edit(id),child:Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:Text('$n',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)))),IconButton(onPressed:()=>_setCount(id,n+1),icon:const Icon(Icons.add_circle_outline))])),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:311,categoryType:widget.categoryType)))));}),Card(child:ListTile(leading:const Icon(Icons.open_in_new),title:const Text('Открыть полный каталог uCoin'),subtitle:const Text('Фактические выпуски, изображения и каталожные номера'),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:311,categoryType:widget.categoryType)))))]),if(loading)const LinearProgressIndicator(),Offstage(offstage:true,child:SizedBox(height:1,child:WebViewWidget(controller:_web))) ]));
  }
}

// The left period counter is derived from the actual in-app list below, not a hard-coded example.

const _euroDenominations = <_AustriaCoin>[
  _AustriaCoin('1 евроцент', '', 'KM# 3082', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евроцента', '', 'KM# 3083', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('5 евроцентов', '', 'KM# 3084', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('10 евроцентов', '', 'KM# 3085 / 3139', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('20 евроцентов', '', 'KM# 3086 / 3140', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('50 евроцентов', '', 'KM# 3087 / 3141', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('1 евро', '', 'KM# 3088 / 3142', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
  _AustriaCoin('2 евро', '', 'KM# 3089 / 3143', 'https://ru.ucoin.net/catalog/?country=austria&period=311'),
];
List<_AustriaCoin> _austriaEuroCoinsByYear() => [
  for (var year = 2002; year <= 2026; year++)
    for (final denomination in _euroDenominations)
      _AustriaCoin(denomination.denomination, '$year', denomination.km, denomination.url),
];
int _euroDenominationOrder(String value) { const order=['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро']; final i=order.indexOf(value); return i < 0 ? order.length : i; }
List<String> _austriaEuroDenominations() => const ['1 евроцент','2 евроцента','5 евроцентов','10 евроцентов','20 евроцентов','50 евроцентов','1 евро','2 евро'];
class _AustriaCoin { final String denomination, years, km, url; const _AustriaCoin(this.denomination,this.years,this.km,this.url); String? get reverseImageUrl { switch (denomination) { case '1 евроцент': return 'https://i.ucoin.net/coin/49/394/49394453-2/austria-1-euro-cent-2012.jpg'; case '1 евро': return 'https://i.ucoin.net/coin/66/799/66799270-2/austria-1-euro-2011.jpg'; default: return null; } } }

Future<String> _saveAustriaPeriod(_AustriaPeriod p) async {
  final prefs = await SharedPreferences.getInstance();
  final chosen = prefs.getString('catalog_save_directory_v1');
  Directory base;
  if (chosen != null && chosen.isNotEmpty) { base = Directory(chosen); if (!await base.exists()) await base.create(recursive: true); }
  else { base = await getApplicationDocumentsDirectory(); }
  final safe = '${p.name}_${p.years}'.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё0-9_-]+'), '_');
  final out = Directory('${base.path}/Австрия_$safe'); await out.create(recursive: true);
  final coins = p.name == 'Европейский союз (Евро)' ? _austriaEuroCoinsByYear().map((c) => {'номинал':c.denomination,'год выпуска':c.years,'каталожный номер':c.km,'источник':c.url}).toList() : <Map<String,String>>[];
  final data = {'страна':'Австрия','период':p.name,'годы':p.years,'источник':'https://ru.ucoin.net/catalog/?country=austria${p.ucoinId > 0 ? '&period=${p.ucoinId}' : ''}','монеты':coins,'примечание': coins.isEmpty ? 'Список монет этого исторического периода пока не загружен в приложение.' : 'Каждая комбинация номинала и года вынесена в отдельную строку. Сверяйте фактический выпуск конкретного года с данными uCoin.'};
  await File('${out.path}/catalog.json').writeAsString(const JsonEncoder.withIndent('  ').convert(data), flush:true);
  await File('${out.path}/README.txt').writeAsString('Австрия — ${p.name} (${p.years})\nКаталог монет в catalog.json.\nИсточник: ${data['источник']}\n', flush:true);
  return out.path;
}

class AustriaCoinsPage extends StatefulWidget { final _AustriaPeriod period; const AustriaCoinsPage({super.key, required this.period}); @override State<AustriaCoinsPage> createState()=>_AustriaCoinsPageState(); }
class _AustriaCoinsPageState extends State<AustriaCoinsPage> {
  Map<String,int> counts = {};
  bool sortByYear = false;
  bool saveReverseImages = false;
  String? selectedDenomination;
  int? selectedYear;
  String get storageKey => 'austria_coin_counts_v2_${widget.period.years}_${widget.period.name}';
  @override void initState(){ super.initState(); _load(); _loadImageSetting(); }
  String get imageSettingKey => 'save_reverse_images_v1_${widget.period.years}_${widget.period.name}';
  String get imageFolderKey => '${widget.period.years}_${widget.period.name}'.replaceAll(RegExp(r'[^A-Za-zА-Яа-яЁё0-9_-]+'), '_');
  Future<void> _loadImageSetting() async { final p=await SharedPreferences.getInstance(); if(mounted)setState(()=>saveReverseImages=p.getBool(imageSettingKey)??false); }
  Future<Directory> _reverseImageDirectory() async { final base=await getApplicationSupportDirectory(); final d=Directory('${base.path}/coin_images/${imageFolderKey}'); await d.create(recursive:true); return d; }
  Future<void> _deleteReverseImages() async { final d=await _reverseImageDirectory(); if(await d.exists()) await d.delete(recursive:true); if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Сохранённые изображения этого подраздела удалены'))); }
  Future<void> _setSaveReverseImages(bool value) async { final p=await SharedPreferences.getInstance(); await p.setBool(imageSettingKey,value); if(mounted)setState(()=>saveReverseImages=value); if(value) await _cacheReverseImages(_austriaEuroCoinsByYear()); }
  Future<void> _cacheReverseImages(List<_AustriaCoin> list) async { final dir=await _reverseImageDirectory(); for(final c in list) { final url=c.reverseImageUrl; if(url==null) continue; final file=File('${dir.path}/${c.denomination}_${c.years}.jpg'.replaceAll(' ', '_')); if(await file.exists()) continue; try { final response=await http.get(Uri.parse(url)).timeout(const Duration(seconds:12)); final type=response.headers['content-type']??''; if(response.statusCode==200 && type.startsWith('image/')) await file.writeAsBytes(response.bodyBytes,flush:true); } catch(_) {} } }
  Future<void> _openImageSettingCacheIfEnabled(List<_AustriaCoin> list) async { if(saveReverseImages) await _cacheReverseImages(list); }
  Widget _coinImage(_AustriaCoin c) { return FutureBuilder<File?>(future: _localCoinImage(c), builder:(context,snapshot) { final file=snapshot.data; final url=c.reverseImageUrl; if(file!=null) return Image.file(file,width:54,height:54,fit:BoxFit.contain); if(url!=null) return Image.network(url,width:54,height:54,fit:BoxFit.contain,errorBuilder:(_,__,___)=>_coinFallback()); return _coinFallback(); }); }
  Widget _coinFallback()=>Container(width:54,height:54,decoration:BoxDecoration(color:Theme.of(context).colorScheme.surfaceContainerHighest,shape:BoxShape.circle),child:const Icon(Icons.monetization_on_outlined,size:30));
  Future<File?> _localCoinImage(_AustriaCoin c) async { final d=await _reverseImageDirectory(); final f=File('${d.path}/${c.denomination}_${c.years}.jpg'.replaceAll(' ', '_')); return await f.exists()?f:null; }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); final raw=p.getString(storageKey); if(raw!=null){try{final m=jsonDecode(raw) as Map<String,dynamic>; final loaded=m.map((k,v)=>MapEntry(k,(v as num).toInt())); if(mounted)setState(()=>counts=loaded);}catch(_){}} }
  Future<void> _change(String key,int delta) async { final next=(counts[key]??0)+delta; if(next<0)return; final updated=Map<String,int>.from(counts); updated[key]=next; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _setCount(String key, int value) async { final updated=Map<String,int>.from(counts); updated[key]=value < 0 ? 0 : value; setState(()=>counts=updated); final p=await SharedPreferences.getInstance(); await p.setString(storageKey,jsonEncode(updated)); }
  Future<void> _editCount(String key) async {
    final controller=TextEditingController(text:'${counts[key]??0}');
    final value=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Количество монет'),content:TextField(controller:controller,keyboardType:TextInputType.number,autofocus:true,decoration:const InputDecoration(labelText:'В наличии',border:OutlineInputBorder()),),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Отмена')),FilledButton(onPressed:(){final n=int.tryParse(controller.text.trim()); if(n!=null && n>=0) Navigator.pop(ctx,n);},child:const Text('Сохранить'))]));
    controller.dispose(); if(value!=null) await _setCount(key,value);
  }
  Future<void> _confirmResetPeriod() async {
    final confirmed=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Сбросить количество?'),content:Text('Количество монет периода «${widget.period.name}» будет установлено в 0. Другие периоды не изменятся.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:Theme.of(ctx).colorScheme.error),child:const Text('Сбросить'))]));
    if(confirmed!=true)return;
    final prefs=await SharedPreferences.getInstance();
    final zeroed=<String,int>{for(final key in counts.keys) key:0};
    await prefs.setString(storageKey,jsonEncode(zeroed));
    if(mounted){setState(()=>counts=zeroed); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Количество монет этого периода сброшено')));}
  }
  Widget _roundCounterButton(IconData icon, VoidCallback? onPressed, {required bool outwardLeft}) {
    return SizedBox(
      width: 38,
      height: 46,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onPressed,
        child: Padding(
          padding: EdgeInsets.only(
            left: outwardLeft ? 8 : 0,
            right: outwardLeft ? 0 : 8,
          ),
          child: Center(
            child: Material(
              color: onPressed == null
                  ? Colors.black12
                  : Theme.of(context).colorScheme.primary,
              shape: const CircleBorder(),
              child: SizedBox(
                width: 30,
                height: 30,
                child: Icon(
                  icon,
                  size: 18,
                  color: onPressed == null ? Colors.black38 : Colors.white,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
  @override Widget build(BuildContext context) {
    final euro=widget.period.ucoinId==311; final coins=euro?_austriaEuroCoinsByYear():<_AustriaCoin>[];
    if (euro) {
      _openImageSettingCacheIfEnabled(coins);
      if (selectedDenomination != null) coins.removeWhere((c) => c.denomination != selectedDenomination);
      if (selectedYear != null) coins.removeWhere((c) => c.years != '$selectedYear');
      coins.sort((a,b) {
        final ya=int.tryParse(a.years)??0, yb=int.tryParse(b.years)??0;
        if (sortByYear) { final byYear=ya.compareTo(yb); return byYear != 0 ? byYear : _euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination)); }
        final byDenomination=_euroDenominationOrder(a.denomination).compareTo(_euroDenominationOrder(b.denomination));
        return byDenomination != 0 ? byDenomination : ya.compareTo(yb);
      });
    }
    return Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisSize:MainAxisSize.min,children:[const Text('Австрия',style:TextStyle(fontSize:18)),Text('${widget.period.name} (${widget.period.years})',style:const TextStyle(fontSize:13,fontWeight:FontWeight.normal))])),body:ListView(padding:const EdgeInsets.all(8),children:[
      if(euro) Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Row(children:[ChoiceChip(label:const Text('По номиналу'),selected:!sortByYear,onSelected:(_)=>setState(()=>sortByYear=false)),const SizedBox(width:6),ChoiceChip(label:const Text('По годам'),selected:sortByYear,onSelected:(_)=>setState(()=>sortByYear=true)),const Spacer(),IconButton(tooltip:'Сбросить все фильтры',visualDensity:VisualDensity.compact,padding:EdgeInsets.zero,constraints:const BoxConstraints.tightFor(width:32,height:40),icon:const Icon(Icons.filter_alt_off,size:20),onPressed:()=>setState((){selectedDenomination=null;selectedYear=null;}))]),const SizedBox(height:6),sortByYear ? DropdownButtonFormField<int>(value:selectedYear,decoration:const InputDecoration(labelText:'Год',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все годы'),items:[const DropdownMenuItem<int>(value:null,child:Text('Все годы')),...List.generate(25,(i)=>2002+i).map((y)=>DropdownMenuItem<int>(value:y,child:Text('$y')))],onChanged:(v)=>setState(()=>selectedYear=v)) : DropdownButtonFormField<String>(value:selectedDenomination,decoration:const InputDecoration(labelText:'Номинал',isDense:true,contentPadding:EdgeInsets.symmetric(horizontal:10,vertical:10),border:OutlineInputBorder()),hint:const Text('Все номиналы'),items:[const DropdownMenuItem<String>(value:null,child:Text('Все номиналы')),..._austriaEuroDenominations().map((d)=>DropdownMenuItem<String>(value:d,child:Text(d)))],onChanged:(v)=>setState(()=>selectedDenomination=v))])),
      if(!euro) const Padding(padding:EdgeInsets.symmetric(vertical:16),child:Text('Для этого исторического периода полный список монет пока не загружен. Откройте uCoin по ссылке ниже, чтобы просмотреть актуальный каталог.')),
      if(euro) Row(children:[IconButton(tooltip:saveReverseImages?'Не сохранять изображения автоматически':'Сохранять изображения этого подраздела',icon:Icon(saveReverseImages?Icons.image:Icons.image_outlined),onPressed:()=>_setSaveReverseImages(!saveReverseImages)),IconButton(tooltip:'Удалить сохранённые изображения этого подраздела',icon:const Icon(Icons.delete_outline),onPressed:_deleteReverseImages),const Spacer(),IconButton(tooltip:'Сбросить количество монет этого периода',icon:const Icon(Icons.delete_sweep_outlined),onPressed:_confirmResetPeriod)]),
      for(final c in coins) Card(clipBehavior:Clip.antiAlias,child:ListTile(contentPadding:const EdgeInsets.only(left:0,right:8),minLeadingWidth:54,horizontalTitleGap:8,
        leading: SizedBox(width:54,height:54,child:ClipRRect(borderRadius:BorderRadius.circular(27),child:_coinImage(c))),
        title:Text('${c.denomination} ${c.years}'),subtitle:null,isThreeLine:false,
        trailing:SizedBox(height:30,child:Row(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.center,children:[_roundCounterButton(Icons.remove, (counts['${c.denomination}_${c.years}']??0)>0?()=>_change('${c.denomination}_${c.years}',-1):null, outwardLeft:true),SizedBox(width:30,height:30,child:Material(color:Colors.transparent,child:InkWell(onTap:()=>_editCount('${c.denomination}_${c.years}'),borderRadius:BorderRadius.circular(6),child:Center(child:FittedBox(fit:BoxFit.scaleDown,child:Text('${counts['${c.denomination}_${c.years}']??0}',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:22,height:1.0))))))),_roundCounterButton(Icons.add,()=>_change('${c.denomination}_${c.years}',1), outwardLeft:false)])),
        onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))),
      )),
      Card(child:ListTile(leading:const Icon(Icons.open_in_new),title:const Text('Полный каталог на uCoin'),subtitle:Text('Австрия · ${widget.period.name} · ${widget.period.years}'),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия'))))),
      const Padding(padding:EdgeInsets.all(8),child:Text('Изображения загружаются из сети. Количество монет сохраняется на устройстве.',style:TextStyle(fontSize:12,color:Colors.black54))),
    ]));
  }
}

class _ContinuousColorPalettePainter extends CustomPainter {
  const _ContinuousColorPalettePainter({required this.saturation, required this.markerX, required this.markerY});
  final double saturation;
  final double markerX;
  final double markerY;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final huePaint = Paint()..shader = const LinearGradient(colors: [
      Color(0xFFFF0000), Color(0xFFFFFF00), Color(0xFF00FF00),
      Color(0xFF00FFFF), Color(0xFF0000FF), Color(0xFFFF00FF), Color(0xFFFF0000),
    ]).createShader(rect);
    canvas.drawRect(rect, huePaint);
    if (saturation < 1) {
      canvas.drawRect(rect, Paint()..color = Colors.white.withOpacity(1 - saturation));
    }
    final shadePaint = Paint()..shader = const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black]).createShader(rect);
    canvas.drawRect(rect, shadePaint);
    final point = Offset(markerX.clamp(0.0, size.width), markerY.clamp(0.0, size.height));
    canvas.drawCircle(point, 9, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 3);
    canvas.drawCircle(point, 9, Paint()..color = Colors.black..style = PaintingStyle.stroke..strokeWidth = 1);
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(8)), Paint()..color = Colors.black26..style = PaintingStyle.stroke..strokeWidth = 1);
  }

  @override
  bool shouldRepaint(covariant _ContinuousColorPalettePainter oldDelegate) => saturation != oldDelegate.saturation || markerX != oldDelegate.markerX || markerY != oldDelegate.markerY;
}

class _AnyTileColorDialog extends StatefulWidget {
  const _AnyTileColorDialog({required this.initialColor});
  final Color initialColor;
  @override
  State<_AnyTileColorDialog> createState() => _AnyTileColorDialogState();
}

class _AnyTileColorDialogState extends State<_AnyTileColorDialog> {
  late double hue;
  late double smoothSaturation;
  late double gridSaturation;
  late double value;
  bool useClassicGrid = false;
  List<int> recentColors = [];
  static const String _recentColorsKey = 'any_color_palette_recent_v1';
  static const String _smoothSaturationKey = 'any_color_palette_smooth_saturation_v1';
  static const String _gridSaturationKey = 'any_color_palette_grid_saturation_v1';

  @override
  void initState() {
    super.initState();
    final hsv = HSVColor.fromColor(widget.initialColor);
    hue = hsv.hue;
    smoothSaturation = hsv.saturation;
    gridSaturation = hsv.saturation;
    value = hsv.value;
    SharedPreferences.getInstance().then((prefs) {
      if (!mounted) return;
      setState(() {
        recentColors = prefs.getStringList(_recentColorsKey)
            ?.map((e) => int.tryParse(e)).whereType<int>().take(8).toList() ?? [];
        smoothSaturation = (prefs.getDouble(_smoothSaturationKey) ?? smoothSaturation).clamp(0.0, 1.0).toDouble();
        gridSaturation = (prefs.getDouble(_gridSaturationKey) ?? gridSaturation).clamp(0.0, 1.0).toDouble();
      });
    });
  }

  double get saturation => useClassicGrid ? gridSaturation : smoothSaturation;
  Color get selectedColor => HSVColor.fromAHSV(1, hue, saturation, value).toColor();

  void _selectRecent(int colorValue) {
    final hsv = HSVColor.fromColor(Color(colorValue));
    setState(() {
      hue = hsv.hue;
      value = hsv.value;
      if (useClassicGrid) { gridSaturation = hsv.saturation; } else { smoothSaturation = hsv.saturation; }
    });
  }

  Future<void> _confirmColor() async {
    final colorValue = selectedColor.value;
    final updated = <int>[colorValue, ...recentColors.where((c) => c != colorValue)].take(8).toList();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_recentColorsKey, updated.map((c) => c.toString()).toList());
    await prefs.setDouble(_smoothSaturationKey, smoothSaturation);
    await prefs.setDouble(_gridSaturationKey, gridSaturation);
    if (mounted) Navigator.of(context).pop(Color(colorValue));
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Палитра любого цвета'),
    content: SizedBox(
      width: 360,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(height: 42, decoration: BoxDecoration(color: selectedColor, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.black26))),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: ChoiceChip(label: const Text('Плавная'), selected: !useClassicGrid, onSelected: (_) => setState(() => useClassicGrid = false))),
          const SizedBox(width: 8),
          Expanded(child: ChoiceChip(label: const Text('Сетка'), selected: useClassicGrid, onSelected: (_) => setState(() => useClassicGrid = true))),
        ]),
        if (recentColors.isNotEmpty) ...[
          Row(children: [
            const Expanded(child: Align(alignment: Alignment.centerLeft, child: Text('8 последних выбранных цветов'))),
            TextButton(onPressed: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove(_recentColorsKey);
              if (mounted) setState(() => recentColors.clear());
            }, child: const Text('Очистить все')),
          ]),
          const SizedBox(height: 5),
          Wrap(spacing: 6, runSpacing: 6, children: [
            for (final colorValue in recentColors)
              GestureDetector(
                onTap: () => _selectRecent(colorValue),
                onDoubleTap: () async {
                  final prefs = await SharedPreferences.getInstance();
                  final updated = recentColors.where((c) => c != colorValue).toList();
                  await prefs.setStringList(_recentColorsKey, updated.map((c) => c.toString()).toList());
                  if (mounted) setState(() => recentColors = updated);
                },
                child: Container(width: 27, height: 27, decoration: BoxDecoration(color: Color(colorValue), borderRadius: BorderRadius.circular(6), border: Border.all(color: colorValue == selectedColor.value ? Colors.black : Colors.black26, width: colorValue == selectedColor.value ? 2 : 1))),
              ),
          ]),
          const SizedBox(height: 4),
        ],
        if (!useClassicGrid) ...[
          const Align(alignment: Alignment.centerLeft, child: Text('Слева направо — оттенок, вверх — ярче, вниз — темнее')),
          const SizedBox(height: 8),
          SizedBox(
            height: 190,
            width: double.infinity,
            child: LayoutBuilder(builder: (context, constraints) {
              void updateFromPosition(Offset local) {
                setState(() {
                  hue = (local.dx / constraints.maxWidth * 360).clamp(0.0, 359.99);
                  value = (1 - local.dy / constraints.maxHeight).clamp(0.05, 1.0);
                });
              }
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapDown: (details) => updateFromPosition(details.localPosition),
                onPanDown: (details) => updateFromPosition(details.localPosition),
                onPanUpdate: (details) => updateFromPosition(details.localPosition),
                child: CustomPaint(
                  painter: _ContinuousColorPalettePainter(saturation: saturation, markerX: hue / 360 * constraints.maxWidth, markerY: (1 - value) * constraints.maxHeight),
                  child: const SizedBox.expand(),
                ),
              );
            }),
          ),
        ] else ...[
          const Align(alignment: Alignment.centerLeft, child: Text('Набор цветов')),
          const SizedBox(height: 6),
          SizedBox(height: 292, child: GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: 12 * 11,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 12, crossAxisSpacing: 3, mainAxisSpacing: 3, childAspectRatio: 1.0),
            itemBuilder: (context, index) {
              final column = index % 12;
              final row = index ~/ 12;
              final cellHue = column * 30.0;
              final cellSaturation = 1.0 - row / 10.0;
              final cellColor = HSVColor.fromAHSV(1, cellHue, cellSaturation, value).toColor();
              final selected = (hue - cellHue).abs() < 15 && (saturation - cellSaturation).abs() < 0.07;
              return InkWell(
                onTap: () => setState(() { hue = cellHue; gridSaturation = cellSaturation; }),
                borderRadius: BorderRadius.circular(4),
                child: Container(decoration: BoxDecoration(color: cellColor, borderRadius: BorderRadius.circular(4), border: Border.all(color: selected ? Colors.black : Colors.black12, width: selected ? 2.5 : 0.6))),
              );
            },
          )),
          const SizedBox(height: 8),
          SizedBox(
            height: 58,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Насыщенность'),
              Expanded(child: Slider(
                min: 0, max: 1, divisions: 100, value: saturation, activeColor: selectedColor,
                onChanged: (v) => setState(() { gridSaturation = v; }),
              )),
            ]),
          ),
        ],
        if (!useClassicGrid) ...[
          const SizedBox(height: 8),
          SizedBox(
            height: 58,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Насыщенность'),
              Expanded(child: Slider(
                min: 0, max: 1, divisions: 100, value: saturation, activeColor: selectedColor,
                onChanged: (v) => setState(() { smoothSaturation = v; }),
              )),
            ]),
          ),
        ],
        Text('#${selectedColor.value.toRadixString(16).substring(2).toUpperCase()}'),
      ]),
    ),
    actions: [
      TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Отмена')),
      FilledButton(onPressed: _confirmColor, child: const Text('Выбрать')),
    ],
  );
}

class AppSettingsPage extends StatefulWidget {
  const AppSettingsPage({super.key});
  @override
  State<AppSettingsPage> createState() => _AppSettingsPageState();
}

class _AppSettingsPageState extends State<AppSettingsPage> {
  String? path;
  bool saveInfoImages = true;
  int? standardTileColor;
  int? customTileColor;
  int? addCatalogTileColor;
  int? addCatalogCustomColor;
  int? standardCustomColor;
  int? userCustomColor;
  String colorTabTitle = 'Цвет';
  String storageTabTitle = 'Хранение данных';
  String homeViewTabTitle = 'Вид главного экрана';
  int selectedTab = 0;
  String homeViewMode = 'tiles';
  static const _homeViewModeKey = 'home_view_mode_v1';
  DateTime? _lastTabTap;
  static const _colorTabKey = 'settings_tab_color_title_v1';
  static const _storageTabKey = 'settings_tab_storage_title_v1';
  static const _homeViewTabKey = 'settings_tab_home_view_title_v1';
  static const _standardCustomColorKey = 'home_standard_custom_color_v1';
  static const _userCustomColorKey = 'home_user_custom_color_v1';
  static const _addCatalogCustomColorKey = 'home_add_catalog_custom_color_v1';
  static const List<int> _extraColors = [
    0xFFE3F2FD, 0xFFBBDEFB, 0xFFD7CCC8, 0xFFFFE0B2, 0xFFFFCDD2,
    0xFFF8BBD0, 0xFFE1BEE7, 0xFFD1C4E9, 0xFFC5CAE9, 0xFFC8E6C9,
    0xFFDCEDC8, 0xFFF0F4C3, 0xFFFFF9C4, 0xFFB2DFDB, 0xFFB2EBF2,
    0xFFCFD8DC, 0xFFEEEEEE, 0xFFB0BEC5, 0xFFD7E3FC, 0xFFFCE4EC,
  ];

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        path = p.getString('catalog_save_directory_v1');
        saveInfoImages = p.getBool('save_country_info_images_v1') ?? true;
        standardTileColor = p.getInt(_standardTileColorKey) ?? p.getInt(_legacyHomeTileColorKey);
        customTileColor = p.getInt(_customTileColorKey);
        addCatalogTileColor = p.getInt(_addCatalogTileColorKey);
        addCatalogCustomColor = p.getInt(_addCatalogCustomColorKey);
        standardCustomColor = p.getInt(_standardCustomColorKey);
        userCustomColor = p.getInt(_userCustomColorKey);
        colorTabTitle = p.getString(_colorTabKey) ?? 'Цвет';
        storageTabTitle = p.getString(_storageTabKey) ?? 'Хранение данных';
        homeViewTabTitle = p.getString(_homeViewTabKey) ?? 'Вид главного экрана';
        homeViewMode = p.getString(_homeViewModeKey) ?? 'tiles';
      });
    });
  }

  Future<void> _renameTab(int tabIndex) async {
    final currentTitle = tabIndex == 0 ? colorTabTitle : tabIndex == 1 ? storageTabTitle : homeViewTabTitle;
    final controller = TextEditingController(text: currentTitle);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Переименовать вкладку'),
        content: TextField(
          controller: controller,
          autofocus: true,
          maxLength: 32,
          decoration: const InputDecoration(labelText: 'Название'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Сохранить')),
        ],
      ),
    );
    final name = result?.trim();
    if (name == null || name.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    if (tabIndex == 0) { await prefs.setString(_colorTabKey, name); }
    else if (tabIndex == 1) { await prefs.setString(_storageTabKey, name); }
    else { await prefs.setString(_homeViewTabKey, name); }
    if (mounted) setState(() {
      if (tabIndex == 0) { colorTabTitle = name; }
      else if (tabIndex == 1) { storageTabTitle = name; }
      else { homeViewTabTitle = name; }
    });
  }

  void _handleTabTap(int index) {
    final now = DateTime.now();
    final isDoubleTap = _lastTabTap != null &&
        now.difference(_lastTabTap!) < const Duration(milliseconds: 450) &&
        selectedTab == index;
    _lastTabTap = now;
    if (isDoubleTap) {
      _lastTabTap = null;
      _renameTab(index);
    } else {
      setState(() => selectedTab = index);
    }
  }

  Widget _colorPalette({
    required String title,
    required int? selected,
    required int? customSelected,
    required Future<void> Function(int?, {bool custom}) onSelect,
  }) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 10),
      Wrap(
        spacing: 12,
        runSpacing: 12,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          InkWell(
            onTap: () => onSelect(null, custom: false),
            borderRadius: BorderRadius.circular(24),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                shape: BoxShape.circle,
                border: Border.all(color: selected == null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == null ? 3 : 1),
              ),
              child: const Icon(Icons.palette_outlined, size: 20),
            ),
          ),
          for (final value in [..._homeTileColorOptions, ..._extraColors])
            InkWell(
              onTap: () => onSelect(value, custom: false),
              borderRadius: BorderRadius.circular(24),
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(
                  color: Color(value), shape: BoxShape.circle,
                  border: Border.all(color: selected == value && customSelected == null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == value && customSelected == null ? 3 : 1),
                ),
              ),
            ),
          if (customSelected != null)
            InkWell(
              onTap: () => onSelect(customSelected, custom: true),
              borderRadius: BorderRadius.circular(24),
              child: Container(
                width: 42, height: 42,
                decoration: BoxDecoration(color: Color(customSelected), shape: BoxShape.circle, border: Border.all(color: selected == customSelected && customSelected != null ? Theme.of(context).colorScheme.primary : Colors.black26, width: selected == customSelected ? 3 : 1)),
                child: const Icon(Icons.check, size: 18, color: Colors.black54),
              ),
            ),
          InkWell(
            onTap: () async {
              final picked = await showDialog<Color>(
                context: context,
                builder: (_) => _AnyTileColorDialog(initialColor: Color(selected ?? _homeTileColorOptions.first)),
              );
              if (picked != null) await onSelect(picked.value, custom: true);
            },
            borderRadius: BorderRadius.circular(24),
            child: Container(
              width: 42, height: 42,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const SweepGradient(colors: [Colors.red, Colors.yellow, Colors.green, Colors.cyan, Colors.blue, Colors.purple, Colors.red]),
                border: Border.all(color: Theme.of(context).colorScheme.outline, width: 1.5),
              ),
              child: const Icon(Icons.colorize, size: 20, color: Colors.white),
            ),
          ),
        ],
      ),
      const SizedBox(height: 6),
      const Text('Первый круг — цвет по умолчанию. Радужный круг открывает отдельное окно выбора оттенка, насыщенности и яркости. Пользовательский цвет хранится отдельно от палитры.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ],
  );

  Future<void> _setTileColor({required int target, required int? value, required bool custom}) async {
    final prefs = await SharedPreferences.getInstance();
    final baseKey = target == 0 ? _standardTileColorKey : target == 1 ? _customTileColorKey : _addCatalogTileColorKey;
    final customKey = target == 0 ? _standardCustomColorKey : target == 1 ? _userCustomColorKey : _addCatalogCustomColorKey;
    if (value == null && !custom) {
      await prefs.remove(baseKey);
      await prefs.remove(customKey);
      if (target == 0) await prefs.remove(_legacyHomeTileColorKey);
    } else {
      await prefs.setInt(baseKey, value!);
      if (custom) {
        await prefs.setInt(customKey, value);
      } else {
        await prefs.remove(customKey);
      }
      if (target == 0) await prefs.remove(_legacyHomeTileColorKey);
    }
    if (mounted) setState(() {
      if (target == 0) {
        standardTileColor = value;
        standardCustomColor = custom ? value : null;
      } else if (target == 1) {
        customTileColor = value;
        userCustomColor = custom ? value : null;
      } else {
        addCatalogTileColor = value;
        addCatalogCustomColor = custom ? value : null;
      }
    });
  }

  Widget _colorSettings() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      _colorPalette(
        title: 'Стандартные плитки',
        selected: standardTileColor,
        customSelected: standardCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 0, value: value, custom: custom),
      ),
      const SizedBox(height: 24),
      _colorPalette(
        title: 'Пользовательские плитки «Мой каталог»',
        selected: customTileColor,
        customSelected: userCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 1, value: value, custom: custom),
      ),
      const SizedBox(height: 24),
      _colorPalette(
        title: 'Плитка «Добавить каталог»',
        selected: addCatalogTileColor,
        customSelected: addCatalogCustomColor,
        onSelect: (value, {custom = false}) => _setTileColor(target: 2, value: value, custom: custom),
      ),
    ],
  );

  Widget _homeViewSettings() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Вид каталогов на главном экране', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Выбери, как отображать каталоги. Настройка сохраняется на устройстве.'),
      const SizedBox(height: 12),
      RadioListTile<String>(value: 'tiles', groupValue: homeViewMode, title: const Text('В виде плиток'), subtitle: const Text('Текущий вид, по умолчанию'), secondary: const Icon(Icons.dashboard_outlined), onChanged: _setHomeViewMode),
      RadioListTile<String>(value: 'watch', groupValue: homeViewMode, title: const Text('Круглые значки — как на Apple Watch'), subtitle: const Text('Компактное поле значков с подписями'), secondary: const Icon(Icons.apps), onChanged: _setHomeViewMode),
      RadioListTile<String>(value: 'list', groupValue: homeViewMode, title: const Text('Список'), subtitle: const Text('Каталоги строками с количеством стран'), secondary: const Icon(Icons.view_list), onChanged: _setHomeViewMode),
      RadioListTile<String>(value: 'honeycomb', groupValue: homeViewMode, title: const Text('Соты'), subtitle: const Text('Каталоги в виде шестиугольных значков'), secondary: const Icon(Icons.hexagon_outlined), onChanged: _setHomeViewMode),
    ],
  );

  Future<void> _setHomeViewMode(String? value) async {
    if (value == null) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_homeViewModeKey, value);
    if (mounted) setState(() => homeViewMode = value);
  }

  Widget _storageSettings() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Сохранять флаги, гербы и фото стран'),
        subtitle: const Text('При включении изображения загружаются в память приложения при открытии страницы с интернетом и доступны офлайн.'),
        value: saveInfoImages,
        onChanged: (v) async {
          final p = await SharedPreferences.getInstance();
          await p.setBool('save_country_info_images_v1', v);
          if (mounted) setState(() => saveInfoImages = v);
        },
      ),
      const Divider(height: 32),
      const Text('Папка для сохранения офлайн-каталогов', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(path ?? 'По умолчанию: папка документов приложения'),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: () async {
          final selected = await FilePicker.platform.getDirectoryPath(dialogTitle: 'Выберите папку для каталогов');
          if (selected != null) {
            final p = await SharedPreferences.getInstance();
            await p.setString('catalog_save_directory_v1', selected);
            if (mounted) setState(() => path = selected);
          }
        },
        icon: const Icon(Icons.folder_open),
        label: const Text('Выбрать папку'),
      ),
      TextButton.icon(
        onPressed: () async {
          final p = await SharedPreferences.getInstance();
          await p.remove('catalog_save_directory_v1');
          if (mounted) setState(() => path = null);
        },
        icon: const Icon(Icons.restart_alt),
        label: const Text('Папка по умолчанию'),
      ),
      const Divider(height: 32),
      const Text('Пока полностью подготовлен офлайн-шаблон для евро Австрии. Для остальных исторических периодов структура и ссылки на uCoin доступны, но полные списки и изображения нужно загрузить отдельно.', style: TextStyle(color: Colors.black54)),
    ],
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Настройки'),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Row(children: [
          Expanded(child: GestureDetector(
            onTap: () => _handleTabTap(0),
            onDoubleTap: () => _renameTab(0),
            child: Container(height: 48, alignment: Alignment.center, decoration: BoxDecoration(border: Border(bottom: BorderSide(color: selectedTab == 0 ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3))),
              child: Text(colorTabTitle, style: TextStyle(fontWeight: selectedTab == 0 ? FontWeight.bold : FontWeight.normal, color: selectedTab == 0 ? Theme.of(context).colorScheme.primary : null))),
          )),
          Expanded(child: GestureDetector(
            onTap: () => _handleTabTap(1),
            onDoubleTap: () => _renameTab(1),
            child: Container(height: 48, alignment: Alignment.center, decoration: BoxDecoration(border: Border(bottom: BorderSide(color: selectedTab == 1 ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3))),
              child: Text(storageTabTitle, style: TextStyle(fontWeight: selectedTab == 1 ? FontWeight.bold : FontWeight.normal, color: selectedTab == 1 ? Theme.of(context).colorScheme.primary : null))),
          )),
          Expanded(child: GestureDetector(
            onTap: () => _handleTabTap(2),
            onDoubleTap: () => _renameTab(2),
            child: Container(height: 48, alignment: Alignment.center, padding: const EdgeInsets.symmetric(horizontal: 4), decoration: BoxDecoration(border: Border(bottom: BorderSide(color: selectedTab == 2 ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 3))),
              child: Text(homeViewTabTitle, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: selectedTab == 2 ? FontWeight.bold : FontWeight.normal, color: selectedTab == 2 ? Theme.of(context).colorScheme.primary : null))),
          )),
        ]),
      ),
    ),
    body: IndexedStack(index: selectedTab, children: [_colorSettings(), _storageSettings(), _homeViewSettings()]),
  );
}

// Country facts for Austria: the short description is loaded from Wikipedia's REST API.
class AustriaInfoPage extends StatefulWidget {
  const AustriaInfoPage({super.key});
  @override
  State<AustriaInfoPage> createState() => _AustriaInfoPageState();
}

class _AustriaInfoPageState extends State<AustriaInfoPage> {
  String? _summary;
  String? _wikiImage;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadWikipedia();
  }

  Future<void> _loadWikipedia() async {
    try {
      final uri = Uri.https('ru.wikipedia.org', '/api/rest_v1/page/summary/Австрия');
      final response = await http.get(uri, headers: {'User-Agent': 'AMiK-SC/0.19 (country information app)'}).timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw Exception('Wikipedia ответила кодом ${response.statusCode}');
      final data = jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() {
        _summary = data['extract'] as String?;
        final thumbnail = data['thumbnail'];
        if (thumbnail is Map<String, dynamic>) _wikiImage = thumbnail['source'] as String?;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() { _loading = false; _error = 'Не удалось загрузить описание из Википедии. Проверьте подключение к интернету.'; });
    }
  }

  Widget _fact(String label, String value, {String? subtitle}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 7),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 13, color: Colors.black54)),
      const SizedBox(height: 2),
      Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      if (subtitle != null) Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );

  Widget _imagePanel(String title, String url, {double height = 150}) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      SizedBox(width: double.infinity, height: height, child: Image.network(url, fit: BoxFit.contain,
        loadingBuilder: (context, child, progress) => progress == null ? child : const Center(child: CircularProgressIndicator(strokeWidth: 2)),
        errorBuilder: (_, __, ___) => Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.broken_image_outlined, size: 30), const SizedBox(height: 6), const Text('Изображение недоступно'), TextButton(onPressed: () { (context as Element).markNeedsBuild(); }, child: const Text('Повторить'))])))),
    ])),
  );

  @override
  Widget build(BuildContext context) {
    const wikiUrl = 'https://ru.wikipedia.org/wiki/Австрия';
    return Scaffold(
      appBar: AppBar(title: const Text('Австрия')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Австрийская Республика', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _fact('Официальное название', 'Австрийская Республика (Republik Österreich)'),
          _fact('Столица', 'Вена'),
          _fact('Площадь страны', '83 879 км²', subtitle: '113-е место в мире по данным статьи Википедии'),
          _fact('Население', 'Около 9,2 млн человек', subtitle: 'Место в мире зависит от года оценки и источника'),
          _fact('Дата независимости', '27 июля 1955 года (Государственный договор)'),
          _fact('Официальный язык', 'Немецкий; в отдельных регионах признаны языки меньшинств'),
          _fact('Валюта', 'Евро (EUR)'),
          _fact('Интернет-домен', '.at'),
          _fact('Телефонный код', '+43'),
          _fact('Часовой пояс', 'UTC+1 зимой, UTC+2 летом'),
        ]))),
        if (_loading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
        if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(_error!, style: const TextStyle(color: Colors.deepOrange))),
        if (_summary != null) Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Описание из Википедии', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8), Text(_summary!),
        ]))),
        _imagePanel('Расположение страны в Европе', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_in_European_Union.svg?width=960', height: 190),
        _imagePanel('Флаг Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Flag_of_Austria.svg?width=600', height: 110),
        _imagePanel('Герб Австрии', 'https://commons.wikimedia.org/wiki/Special:FilePath/Austria_Bundesadler.png?width=500', height: 180),
        Card(child: ListTile(leading: const Icon(Icons.open_in_new), title: const Text('Открыть статью в Википедии'), subtitle: const Text('Подробная информация и источники'), onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => WikipediaArticlePage(url: wikiUrl))))),
        const Padding(padding: EdgeInsets.all(8), child: Text('Рейтинговые места приведены по данным статьи Википедии и могут меняться с обновлением статистики.', style: TextStyle(fontSize: 12, color: Colors.black54))),
      ]),
    );
  }
}

class WikipediaArticlePage extends StatefulWidget {
  final String url;
  const WikipediaArticlePage({super.key, required this.url});
  @override
  State<WikipediaArticlePage> createState() => _WikipediaArticlePageState();
}
class _WikipediaArticlePageState extends State<WikipediaArticlePage> {
  late final WebViewController _controller = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..loadRequest(Uri.parse(widget.url));
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Википедия')), body: WebViewWidget(controller: _controller));
}

// uCoin is the source of catalogue entries; downloaded rows are cached locally for offline use.
// Historical Austria categories. Real catalogue rows are read from the selected
// uCoin period/type page; quantities are stored locally per period and category.
// Euro period 311 intentionally stays on the existing screens.
class AustriaHistoricalCategoryPage extends StatefulWidget {
  final _AustriaPeriod period;
  final int categoryType;
  final String categoryName;
  const AustriaHistoricalCategoryPage({super.key, required this.period, required this.categoryType, required this.categoryName});
  @override State<AustriaHistoricalCategoryPage> createState() => _AustriaHistoricalCategoryPageState();
}

class _AustriaHistoricalCategoryPageState extends State<AustriaHistoricalCategoryPage> {
  late final WebViewController _web;
  bool _loading = true;
  bool _extracting = false;
  String? _error;
  List<Map<String, String>> _coins = [];
  Map<String, int> _counts = {};
  bool _sortByYear = false;
  String get _url => Uri.https('ru.ucoin.net', '/catalog/', {'country':'austria','period':'${widget.period.ucoinId}','type':'${widget.categoryType}'}).toString();
  String get _storageKey => 'austria_historical_${widget.period.ucoinId}_${widget.categoryType}_counts_v1';
  String get _catalogCacheKey => 'austria_historical_catalog_${widget.period.ucoinId}_${widget.categoryType}_v1';

  @override void initState() {
    super.initState();
    _loadCachedCoins();
    _loadCounts();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; _error = null; }); },
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); _extractCoins(); },
        onWebResourceError: (e) { if (e.isForMainFrame == true && mounted) setState(() { _loading = false; _error = 'Не удалось загрузить uCoin. Проверьте интернет.'; }); },
      ))
      ..loadRequest(Uri.parse(_url));
  }

  Future<void> _loadCachedCoins() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_catalogCacheKey);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      final cached = decoded.whereType<Map>().map((e) => e.map((k,v) => MapEntry('$k','$v'))).toList();
      if (cached.isNotEmpty && mounted) setState(() { _coins = cached; _loading = false; _error = 'Офлайн-каталог: сохранённые данные uCoin'; });
    } catch (_) {}
  }

  Future<void> _loadCounts() async {
    final p = await SharedPreferences.getInstance(); final raw = p.getString(_storageKey); if (raw == null) return;
    try { final m = (jsonDecode(raw) as Map<String, dynamic>).map((k,v)=>MapEntry(k,(v as num).toInt())); if (mounted) setState(()=>_counts=m); } catch (_) {}
  }
  Future<void> _saveCounts() async { final p=await SharedPreferences.getInstance(); await p.setString(_storageKey,jsonEncode(_counts)); }
  Future<void> _changeCount(String id,int delta) async { setState(()=>_counts[id]=((_counts[id]??0)+delta).clamp(0,999999).toInt()); await _saveCounts(); }
  Future<void> _editCount(String id) async {
    final ctrl=TextEditingController(text:'${_counts[id]??0}');
    final value=await showDialog<int>(context:context,builder:(ctx)=>AlertDialog(title:const Text('Количество монет'),content:TextField(controller:ctrl,autofocus:true,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'У меня есть')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Отмена')),FilledButton(onPressed:()=>Navigator.pop(ctx,int.tryParse(ctrl.text)),child:const Text('Сохранить'))]));
    if(value!=null){setState(()=>_counts[id]=value.clamp(0,999999).toInt());await _saveCounts();}
  }

  Future<void> _extractCoins() async {
    if (_extracting) return; _extracting=true;
    try {
      final result=await _web.runJavaScriptReturningResult(r'''JSON.stringify((() => {
        const clean = s => (s || '').replace(/\s+/g, ' ').trim();
        const anchors = Array.from(document.querySelectorAll('a[href]')).filter(a => /\/(coin|coins)\//i.test(a.getAttribute('href') || ''));
        const out=[]; const seen=new Set();
        for (const a of anchors) {
          const card=a.closest('article,li,.coin,.coin-item,.catalog-item,.item') || a.parentElement?.parentElement || a.parentElement;
          const text=clean((card && (card.innerText || card.textContent)) || a.innerText || a.textContent);
          const href=a.href || a.getAttribute('href') || ''; if(!text || text.length<4 || seen.has(href || text)) continue; seen.add(href || text);
          const year=text.match(/\b(1[5-9]\d{2}|20\d{2}|21\d{2})\b(?:\s*[-–]\s*(\d{4}))?/);
          const denom=text.match(/\d+(?:[.,]\d+)?\s*(?:1\/2|1\/4|1\/3|1\/6|1\/8)?\s*(?:euro cents?|eurocent|euros?|schilling|groschen|kronen?|heller|gulden|florin|kreuzer|thaler|taler|ducats?|pfennig|cent|ecus?)/i);
          const cat=text.match(/\b(?:KM|UC|X|Y|C|N|H|M)\s*#?\s*[A-Z0-9.\/-]+/i);
          out.push({id:href||text,title:clean(a.getAttribute('title')||a.innerText||a.textContent),year:year?year[0]:'',denomination:denom?denom[0]:'',catalog:cat?cat[0]:'',text:text.slice(0,280),url:href});
        }
        return out;
      })())''');
      var decoded=result.toString(); if(decoded.startsWith('"')&&decoded.endsWith('"')){try{decoded=jsonDecode(decoded) as String;}catch(_){}}
      final data=jsonDecode(decoded);
      if(data is List){final rows=data.whereType<Map>().map((e)=>e.map((k,v)=>MapEntry('$k','$v'))).where((e)=>(e['text']??'').isNotEmpty).toList(); if(rows.isNotEmpty){final p=await SharedPreferences.getInstance();await p.setString(_catalogCacheKey,jsonEncode(rows));} if(mounted)setState((){if(rows.isNotEmpty)_coins=rows;_error=rows.isEmpty?'uCoin загрузился, но список выпусков автоматически прочитать не удалось. Используются сохранённые данные, если они есть.':null;});}
    } catch (_) { if(mounted)setState(()=>_error='Не удалось прочитать список автоматически. Можно открыть оригинальный каталог uCoin ниже.'); }
    finally {_extracting=false;}
  }
  String _coinId(Map<String,String> c)=>c['id']??c['url']??c['text']??c['title']??'';

  @override Widget build(BuildContext context) {
    final rows=List<Map<String,String>>.from(_coins);
    rows.sort((a,b){if(_sortByYear){int yr(Map<String,String> c)=>int.tryParse(RegExp(r'\d{4}').firstMatch(c['year']??'')?.group(0)??'')??0;return yr(a).compareTo(yr(b));}return (a['denomination']??'').compareTo(b['denomination']??'');});
    return Scaffold(appBar:AppBar(title:Text(widget.categoryName),actions:[IconButton(tooltip:'Обновить uCoin',onPressed:()=>_web.reload(),icon:const Icon(Icons.refresh)),IconButton(tooltip:'Открыть каталог uCoin',onPressed:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:widget.period.ucoinId,categoryType:widget.categoryType))),icon:const Icon(Icons.open_in_new))]),
      body:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(12,8,12,4),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${widget.period.name} · ${widget.period.years}',style:Theme.of(context).textTheme.titleSmall),Text('Источник данных: uCoin. Количество хранится отдельно для этого периода и категории.',style:Theme.of(context).textTheme.bodySmall),const SizedBox(height:8),Row(children:[ChoiceChip(label:const Text('По номиналу'),selected:!_sortByYear,onSelected:(_)=>setState(()=>_sortByYear=false)),const SizedBox(width:8),ChoiceChip(label:const Text('По годам'),selected:_sortByYear,onSelected:(_)=>setState(()=>_sortByYear=true)),const Spacer(),Text('${rows.length} монет')])])),
      if(_loading)const LinearProgressIndicator(),if(_error!=null)Padding(padding:const EdgeInsets.all(12),child:Text(_error!,style:const TextStyle(color:Colors.deepOrange))),
      if(_coins.isEmpty&&!_loading)Expanded(child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.public,size:42),const SizedBox(height:8),const Text('Откройте каталог uCoin, чтобы просмотреть фактические выпуски.'),const SizedBox(height:8),FilledButton.icon(onPressed:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:widget.period.ucoinId,categoryType:widget.categoryType))),icon:const Icon(Icons.open_in_new),label:const Text('Открыть список uCoin'))]))),
      if(_coins.isNotEmpty)Expanded(child:ListView.builder(padding:const EdgeInsets.only(bottom:12),itemCount:rows.length,itemBuilder:(context,index){final c=rows[index];final id=_coinId(c);final count=_counts[id]??0;final title=(c['title']??'').isEmpty?(c['text']??'Монета'):c['title']!;final meta=[if((c['denomination']??'').isNotEmpty)c['denomination'],if((c['year']??'').isNotEmpty)c['year'],if((c['catalog']??'').isNotEmpty)c['catalog']].join(' · ');return Card(child:ListTile(title:Text(title,maxLines:2,overflow:TextOverflow.ellipsis),subtitle:Text(meta.isEmpty?(c['text']??''):meta,maxLines:2,overflow:TextOverflow.ellipsis),trailing:SizedBox(width:124,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[IconButton(onPressed:count>0?()=>_changeCount(id,-1):null,icon:const Icon(Icons.remove_circle_outline)),GestureDetector(onTap:()=>_editCount(id),child:Padding(padding:const EdgeInsets.symmetric(horizontal:2),child:Text('$count',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)))),IconButton(onPressed:()=>_changeCount(id,1),icon:const Icon(Icons.add_circle_outline))])),onTap:()=>Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>UcoinCountryPage(country:'Австрия',periodId:widget.period.ucoinId,categoryType:widget.categoryType)))));})),
      SizedBox(height:1,child:Offstage(offstage:true,child:SizedBox(height:1,child:WebViewWidget(controller:_web))))]));
  }
}

class UcoinCountryPage extends StatefulWidget {
  final String country;
  final int? periodId;
  final int? categoryType;
  const UcoinCountryPage({super.key, required this.country, this.periodId, this.categoryType});

  @override
  State<UcoinCountryPage> createState() => _UcoinCountryPageState();
}

class _UcoinCountryPageState extends State<UcoinCountryPage> {
  late final WebViewController _controller;
  bool _loading = true;
  bool _failed = false;

  static const Map<String, String> _slugs = {
    'Австрия': 'austria', 'Албания': 'albania', 'Андорра': 'andorra',
    'Беларусь': 'belarus', 'Бельгия': 'belgium', 'Болгария': 'bulgaria',
    'Босния и Герцеговина': 'bosnia_and_herzegovina', 'Ватикан': 'vatican',
    'Великобритания': 'united_kingdom', 'Венгрия': 'hungary', 'Германия': 'germany',
    'Греция': 'greece', 'Дания': 'denmark', 'Ирландия': 'ireland',
    'Исландия': 'iceland', 'Испания': 'spain', 'Италия': 'italy', 'Кипр': 'cyprus',
    'Косово': 'kosovo', 'Латвия': 'latvia', 'Литва': 'lithuania',
    'Лихтенштейн': 'liechtenstein', 'Люксембург': 'luxembourg', 'Мальта': 'malta',
    'Молдова': 'moldova', 'Монако': 'monaco', 'Нидерланды': 'netherlands',
    'Норвегия': 'norway', 'Польша': 'poland', 'Португалия': 'portugal',
    'Россия': 'russia', 'Румыния': 'romania', 'Сан-Марино': 'san_marino',
    'Северная Македония': 'north_macedonia', 'Сербия': 'serbia',
    'Словакия': 'slovakia', 'Словения': 'slovenia', 'Турция': 'turkey',
    'Украина': 'ukraine', 'Финляндия': 'finland', 'Франция': 'france',
    'Хорватия': 'croatia', 'Черногория': 'montenegro', 'Чехия': 'czech_republic',
    'Швейцария': 'switzerland', 'Швеция': 'sweden', 'Эстония': 'estonia',
  };

  @override
  void initState() {
    super.initState();
    final slug = _slugs[widget.country];
    final params = <String, String>{'country': slug ?? widget.country};
    if (widget.periodId != null) params['period'] = '${widget.periodId}';
    if (widget.categoryType != null) params['type'] = '${widget.categoryType}';
    final uri = Uri.https('ru.ucoin.net', '/catalog/', params);
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { _loading = true; _failed = false; }); },
        onPageFinished: (_) { if (mounted) setState(() => _loading = false); },
        onWebResourceError: (error) {
          if (error.isForMainFrame == true && mounted) {
            setState(() { _loading = false; _failed = true; });
          }
        },
      ))
      ..loadRequest(uri);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.country),
      actions: [IconButton(tooltip: 'Обновить', icon: const Icon(Icons.refresh), onPressed: () => _controller.reload())],
    ),
    body: Stack(children: [
      WebViewWidget(controller: _controller),
      if (_loading) const LinearProgressIndicator(),
      if (_failed) Center(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off, size: 48),
          const SizedBox(height: 12),
          const Text('Не удалось загрузить каталог uCoin. Проверьте интернет и попробуйте снова.', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: () => _controller.reload(), icon: const Icon(Icons.refresh), label: const Text('Повторить')),
        ]),
      )),
    ]),
  );
}
